# Resolution of both monitor are 1366x768 pixels.
# To do: divide large movie, LED manual control in housing analysis, Ignore 1 frame nosepoke function, Take measures for USB-monitor disconnection
# To do at the 1st run: Upload "SerialConnectionWithPython7.ino" into arduino, Set path, Set panel positions
# Note: Users have to init their local variables which should be reset between sessions by themselves (Ideally within init of phase2)

# Plug-in which should be installed: OpenCV
# Tips of python: global variable can be read from function without statement, but cannot substitute (Caution: Mistaking local variable for global variable can be easily happened)
#m*: label, i*:iEntry, b*:button

import cv2  # For camera capturing
import numpy as np
import datetime  # For getting time
import time
import os  # For the checking of folder/file
import pickle  # Module for saving parameters
import smtplib  # For sending notification email
import win32api  # For get mice cursor coordinates in the desktop
import random
from email.mime.text import MIMEText
from email.utils import formatdate
from tkinter import *  # For GUI
from tkinter import filedialog
from tkinter import ttk
from tkinter import messagebox
#import tkinter.filedialog, tkinter.messagebox

import serial  # Module for the operation of arduino


#===========For email sending==============================================================================
FROM_ADDRESS = 'smarthomecage@gmail.com'
MY_PASSWORD = '6789yuio6789YUIO'
TO_ADDRESS = ''  #bekkobati@gmail.com
BCC = 'receiver2@test.net'
SUBJECT = 'Mail from python'
BODY = 'This mail was sent from python program'
#========Basical setting====================================================================================
IsHousingAnalysis=0 # If housing analysis is working, the value = 1, otherwise = 0
PortName='COM3'    # You can check this port name through device manager
CameraID=0  # This value is used for starting recording with opencv (If there is only 1 camera, substitute 0. If miniscope is connected, substitute 1)
WinApiForCamera=0   # Window API for camera capturing (0:DSHOW, 1:MSMF)
#========Basical setting2====================================================================================
MaxTaskNum = 100  # Max number of tasks
MaxPanelNum = 40
ULXofTouchWindow = 1366 # Left-up position of the touch panel window
ULYofTouchWindow = 0
CameraWindowWidth = 640
CameraWindowHeight = 480
TouchWindowWidth = 1366
TouchWindowHeight = 850
MovieWidth=320
MovieHeight=240
CharaMesX = 100
CharaMesY = 0

MainWindowCenterFrameX = 100 # The X coordinate of upper left position of the GUI frame which shows task phase control button
MainWindowCenterFrameY = 30
MainWindowCenterFrameWidth=100
MainWindowCenterFrameHeight=160

MainWindowRightFrameX = 100 # The X coordinate of upper left position of the GUI frame which shows task buttons
MainWindowRightFrameY = 30
MainWindowRightFrameWidth=1377#1230
MainWindowRightFrameHeight=160#150

NosePokeSamplingDensity=5 # Sampling density of nosepoke detection (pixel) 10
RecordFPS=5     # Recording FPS
PlayBackFPS=30  # Playback speed of captured movie
TargetFPS=30 # FPS of this software (main loop)

#===========================================================================================================

Phase = 0 # Current main phase  -99:Setting
Phase2 = 0
Task = 0 # Number of current task
Path=''
IsLightPhase=1  # This value is 1 during light phase

MxDesk=-1   # Mice coordinate in the desktop
MyDesk=-1
MxCam = -1   # Mice cursor coordinate in the camera window
MyCam = -1
PreMxCam = -1   # Mice cursor coordinate of the previous frame in the camera window
PreMyCam = -1
MxTk = -1  # Mice cursor coordinate in the touch panel window
MyTk = -1
PreMxTk = -1  # Mice cursor coordinate of the previous frame in the touch panel window
PreMyTk = -1
TouchX=-1   # Actual touched position on the monitor
TouchY=-1
PreTouchX=-1   # Actual touched position on the monitor
PreTouchY=-1
CrossFireX = 100
CrossFireY = 100
CrossFireMoveDistance = 10.0  # Move distance by one button click
PanelUsed = [[0 for i in range(MaxPanelNum)] for j in range(MaxTaskNum)]     # Whether each panel is used or not
PanelULX = [[0 for i in range(MaxPanelNum)] for j in range(MaxTaskNum)]
PanelULY = [[0 for i in range(MaxPanelNum)] for j in range(MaxTaskNum)]
PanelBRX = [[0 for i in range(MaxPanelNum)] for j in range(MaxTaskNum)]
PanelBRY = [[0 for i in range(MaxPanelNum)] for j in range(MaxTaskNum)]


TouchPanelRef = [0]*MaxPanelNum
TouchPanelRef_Test = [0]*MaxPanelNum
IsHiddenPanel = [0]*MaxPanelNum   # If 1, a correspondent panel blinks
TypeOfPanel = [0]*MaxPanelNum   # 0:Normal 1:Blinking 2:Textured
BlinkPanelNum=0  # 1 means there is more than 1 panel blinkings
OHCnt=0 # Total frame of operant house update
EndFlag = 0   # If 1, program will be quitted
TaskEndFlag = 0
SaveTrg = 0
ManualPanelOnTrg=0  # Used in the manual panel display
PickleInst = [0] * MaxTaskNum
TouchDetectionOnCnt=0 # If any mouse cursor is detected, the value > 0
TouchSymbolCnt = 0
# Nosepoke ROI
NosePokeRoiWidth=0  # Width of nosepoke ROI
NosePokeRoiHeight=0
Position = [[0 for i in range(2)] for j in range(2)]
DuringCameraReset=0 # If 1, camera is during reset (Camera capture is not executed during reset)
#CamResetDay=-1
#CamResetHour=12
#CamResetMinute=48
DebugWithoutArduinoMode=0   # If 1, serial connection is not working
AutoTaskSwitchPhase=0    # If 1, next task switch sequence is started automatically when phase backs to 0.
NextTaskID=0

Distance=0
RoiMovePhase=0
GrabbedID=0
NowPunishing = 0
NosePokeIntTh=50
NosePokeHitNum=0
NosePokeHitNumTh=0
PointedPixelInt=0    # Total light intensity of pointed pixel

LightPhaseOnsetHour=-1
LightPhaseOnsetMinute=-1
DarkPhaseOnsetHour=-1
DarkPhaseOnsetMinute=-1

ExperimentStartYear = 0
ExperimentStartMonth = 0
ExperimentStartDay = 0
ExperimentStartHour = 0
ExperimentStartMinute = 0
ExperimentStartSecond = 0.0
TaskStartedYear = 0
TaskStartedMonth = 0
TaskStartedDay = 0
TaskStartedHour = 0
TaskStartedMinute = 0
TaskStartedSecond = 0.0

TaskStartHour = [-1] * 4    # Time (hour) of starting of task in housing analysis
TaskStartMinute = [-1] * 4   # Time (minute) of starting of task in housing analysis

TimerRunning=[0]*8  # 1-3:For tasks, 4:For servo power, 5:For task time limit, 6:For temporal suspension of nosepoke detection    7:For camera reset
TimerNowTime=[0.0]*8
TimerPreTime=[0.0]*8
TimerCounter=[0]*8
TimerSec=[0.0]*8
ServoWorkTime=1.0   # Duration of power on of the servo

# Variables for arbitary water supply(AWS)
AWS_On=0    # If 1, AWS works
AWS_IndicatedDur=0  # Required nosepoke duration
AWS_Dur=0   # Nosepoke duration during AWS
AWS_PreFrameMilliSec=0  # Time of pre frame in millisec
AWS_CurrFrameMilliSec=0 # Time of current frame in millisec
AWS_Stat=0  # 1 means AWS is completed
ButtonAWS_On=0 # If 1, button activated AWS is working

Init = 0
FpsSec = 0
FpsPreSec = 0
ButtonRef = [0]*100
ButtonRef[1] = 2
FrameNum = 0
FPS = 0.0
FrameNumPerSec = 0
CurrentPanelNum = 0
TimeNow = datetime.datetime.now()
IsThereEndTaskNowButton=0

IndicatedWaterPos=0     # Indicate position of water nozzle, 0:intermediate, 1:inside, 2:outside, -1:power off the servo(for silencing)
IndicatedRoofLightPower=1   # If this value is 1, roof light is turned on. If -1, turned off. If 0, do nothing.
RoofLightPowerOn=0      # When 1, roof light is lit. When 0, light-out.
IndicatedInfraredPower=0# If this value is 1, infrared light is turned on. If -1, turned off. If 0, do nothing.
InfraredPowerOn=0       # When 1, infrared LEDs are lit. When 0, turn off.
IndicatedWaterCue=0     # If this value is 1, water cue light(Green LED) is turned on. If -1, turned off. If 0, do nothing.
WaterCueSwitchOn=0
WaterCueOn=0            # When 1, water cue is on. When 0, water cue is off.
WaterCuePower=0         # When 1, water cue is lit. When 0, water cue is out.
IsWaterCueBlink=0       # If 1, water cue blinks

IndicatedValveTtlPower=0# If this value is 1, TTL of electric valve onsets. If -1, offsets. If 0, do nothing.
ValveTtlPowerOn=0

IndicatedHoleCue=[0]*5 # If this value is 1, hole cue light is turned on. If -1, turned off. If 0, do nothing (Element numbers correspond to the hole IDs).
HoleCueOn=[0]*5
IndicatedHoleWaterCue=[0]*5 # If this value is 1, hole reward cue light is turned on. If -1, turned off. If 0, do nothing (Element numbers correspond to the hole IDs).
HoleWaterCueOn=[0]*5

WaterPos=0
WaterCue=0
NosePoking=0    # When the nosepoke is detected, this value is 1
DuringTask=0    # Only during task, this value is 1
NowRecording=0  # During recording, this value is 1
EndRecordTimerOn=0  # If 1, end record timer is functional
EndRecordTimerCnt=0 # When this counter equals 0, the recording is stopped
ManualNosePokeOn=-1    #If manual nose poke is activated, 1
NosePokeDetectionOn=1  #If 1, nose poke detection is functional
NowLickRecording=0  #
StartLickRecordingTrg=0 # If 1, recording of lick starts
EndLickRecordingTrg=0   # If 1, recording of lick ends
PreNosePoking=0
NosePokeNum=0

SendingTtl=0                # If 1, TTL output is started
TtlPower=0                  # If 1, TTL signal is sent

TtlSquareOn=0				#if this value is 1, channel 3 becomes enable
TtlITV=2000					#Frequency of TTL pulse (msec)
Ttl1stSquareDuration=1200	#Width of 1st TTL square pulse(msec)
TtlSquareDuration=1000		#Width of the following TTL square pulse(msec)
ElapsedTime=0				#Elapsed time after starting ttl pulse output (msec)
ElapsedTimePerFrame=0		#Elapsed time in the current frame(msec)
TtlPreTime=0				#in ms, For caluculation
TtlCurrTime=0				#in ms, For caluculation
TtlPreQuotient=0			#For caluculation
TtlCurrQuotient=0			#For caluculation
TtlCurrRemainder = 0		#For caluculation
TtlSquareElapsedTime=0		#For caluculation
TtlIsFirst=1				#This value is 1 until 1st long-wide pulse is output

NextShatterTime=0.0
CaptureNum=0

SerialOutPhase = 0
SerialOutType = 0
CurrentChannelID=0
Angle=1    # Angle of servo
ServoOutputBook=0   # If 1, angle of the servo in the arduino is updated through serial connection
DigitalPinOutputBook=0     # If 1, status of digital output pin in the arduino is updated through serial connection
TtlTimeStumpBook = 1        # If 1, time stum of TTL signal is registered
OutPhase=0

bStartNow=None # Prepare for the reference of button
bTimePlus=None
bTimeMinus=None
bBackToPara=None
bEndTaskNow=None
#fourcc = cv2.VideoWriter_fourcc(*'MJPG')    #Define the codec and create VideoWriter object
try:
    ser = serial.Serial(PortName, 115200,timeout=0) # Connect to arduino
    print('Arduino is detected.')
except serial.serialutil.SerialException:   # If arduino is not found
    DebugWithoutArduinoMode=1   # Run as non-arduino mode
    print('Arduino is not detected.')
'''
Trg=0
def OK():
    global Trg
    Trg=1
    #EntryPopupRoot.destroy()
    return
PortName=""
if os.path.exists('data/PortName.dat') == True: # Bottom right Y coordinate of nose poke detection ROI
    with open('data/PortName.dat', 'rb') as fp:
        PortName=pickle.load(fp)
        print(PortName)

try:
  ser = serial.Serial(PortName, 115200,timeout=0)
  while ser.read():
    print(ser.read())
    Trg=2

except serial.serialutil.SerialException:
    print('exception')
    EntryPopupRoot = Tk()
    Label(EntryPopupRoot, text='enter something').pack()
    a=StringVar(EntryPopupRoot)
    Entry(EntryPopupRoot, textvariable=a).pack()
    Button(EntryPopupRoot, text='Ok', command=lambda: OK()).pack()
    mainloop(EntryPopupRoot)
'''

#TouchedPanelID=-0   # ID of touched panel
# Make Touch window
TouchWindowRoot = Tk()
TouchWindowRoot.title("Touch window")
TouchWindowRoot.geometry(str(TouchWindowWidth)+"x"+str(TouchWindowHeight))    # Create Touch window
TouchWindowRoot.geometry('+'+str(ULXofTouchWindow)+'+'+str(ULYofTouchWindow))    # Move window
TouchWindowRoot.resizable(0,0) # Prohibit the resize of touch window
TouchWindowRoot.overrideredirect(1)
CanvasTouchWindow = Canvas(TouchWindowRoot, width = TouchWindowWidth, height = TouchWindowHeight)

CanvasTouchWindow.create_rectangle(0, 0, TouchWindowWidth+1, TouchWindowHeight+1, fill = 'black')  # Draw dark background
CanvasTouchWindow.place(x=-2, y=-2)

# Make main window
MainWindowRoot = Tk()
MainWindowRoot.title("Main window")
MainWindowRoot.geometry('+100+5')
MainWindowRoot.geometry("1230x220")
MainWindowLeftFrame = ttk.Frame(MainWindowRoot, width=1230, height=500, relief='flat', borderwidth=5)
MainWindowLeftFrame.place(x=0, y=0)
MainWindowCenterFrame = ttk.Frame(MainWindowRoot, width=MainWindowCenterFrameWidth, height=MainWindowCenterFrameHeight, relief='flat', borderwidth=5) #
MainWindowCenterFrame.place(x=MainWindowCenterFrameX, y=MainWindowCenterFrameY)
MainWindowRightFrame = ttk.Frame(MainWindowRoot, width=MainWindowRightFrameWidth, height=MainWindowRightFrameHeight, relief='flat', borderwidth=5)
MainWindowRightFrame.place(x=MainWindowRightFrameX, y=MainWindowRightFrameY, width=MainWindowRightFrameWidth, height=MainWindowRightFrameHeight) #

MailAddressVar = StringVar(MainWindowRoot) # e-mail for the receiving task finish notification
TouchX_ShiftVar = StringVar(MainWindowRoot) #
TouchY_ShiftVar = StringVar(MainWindowRoot) #
TouchX_ScaleVar = StringVar(MainWindowRoot) #
TouchY_ScaleVar = StringVar(MainWindowRoot) #
IsTouchMonitorInvertedVar=StringVar(MainWindowRoot) #
DeviceNameVar=StringVar(MainWindowRoot) #
ArduinoConnectionVar=StringVar(MainWindowRoot) #
MouseDebugModeVar=StringVar(MainWindowRoot) # If ON, mouse cursor = touched position
CameraCaptureFreqVar=StringVar(MainWindowRoot) # Capturing freqency of camera (Use larger number than 1 only when camera capturing somehow takes very long time).
CableDetectCorrValueVar=StringVar(MainWindowRoot)   # Correction value for the detection of cable color (For avoiding to detect cable as nose poke, Higher value increase detect sensitivity)
TaskStartTime1Var=StringVar(MainWindowRoot) # Time(exp:23:00) when task is started (For housing analysis)
TaskStartTime2Var=StringVar(MainWindowRoot)
TaskStartTime3Var=StringVar(MainWindowRoot)
TaskStartTime4Var=StringVar(MainWindowRoot)

LightPhaseOnsetTimeVar=StringVar(MainWindowRoot)
DarkPhaseOnsetTimeVar=StringVar(MainWindowRoot)

MovieWidthVar=StringVar(MainWindowRoot)
MovieHeightVar=StringVar(MainWindowRoot)



#Str='aaa'
PanelTexturePath = ['']*4   # Texture path of panel
#PanelTexturePath = [['' for i in range(4)] for j in range(4)]
# Make control window
ControlWindowRoot = Tk()
ControlWindowRoot.title("Control window")
ControlWindowRoot.geometry('+100+300')
ControlWindowFrame = ttk.Frame(ControlWindowRoot, width=600, height=480, relief='flat', borderwidth=5)
ControlWindowFrame.grid(row=0, column=0, sticky=(N, E, S, W))   # Make frame?

#StripesPng = [PhotoImage(file="TextureTemplate2.png"),  PhotoImage(file="TextureTemplate2.png")]
PanelTextureImage = [PhotoImage(file="TextureTemplate.png"),  PhotoImage(file="TextureTemplate.png")]
#print(type(StripesPng))




class mouseParam:   # Class for get input information of mouse (in the Open CV window)
    def __init__(self, input_img_name):
        self.mouseEvent = {"x": None, "y": None, "event": None, "flags": None}  # Parameters for input of mouse
        cv2.setMouseCallback(input_img_name, self.__CallBackFunc, None) # Setting of mouse input
    def __CallBackFunc(self, eventType, x, y, flags, userdata): # Call back
        self.mouseEvent["x"] = x
        self.mouseEvent["y"] = y
        self.mouseEvent["event"] = eventType
        self.mouseEvent["flags"] = flags
    def getData(self):  # Function for returning parameters for mouse input
        return self.mouseEvent
    def getEvent(self): # Function for returning mice eventマウスイベントを返す関数
        return self.mouseEvent["event"]
    def getFlags(self): # Function for returning flag of mosue
        return self.mouseEvent["flags"]
    def getX(self): # Returning x coordinate
        return self.mouseEvent["x"]
    def getY(self): # Returning y coordinate
        return self.mouseEvent["y"]
    def getPos(self):   # Returning x and y coordinates
        return (self.mouseEvent["x"], self.mouseEvent["y"])

def SaveGeneralParameter():
    global Path, PanelULX, PanelULY, PanelBRX, PanelBRY
    with open('data/Path.dat', 'wb') as fp:
        pickle.dump(Path, fp)
    with open('data/LightTh.dat', 'wb') as fp:
        pickle.dump(LightThVar.get(), fp)
    with open('data/DarkTh.dat', 'wb') as fp:
        pickle.dump(DarkThVar.get(), fp)
    with open('data/NumTh.dat', 'wb') as fp:
        pickle.dump(NumThVar.get(), fp)
    with open('data/InAngle.dat', 'wb') as fp:
        pickle.dump(InAngleVar.get(), fp)
    with open('data/MidAngle.dat', 'wb') as fp:
        pickle.dump(MidAngleVar.get(), fp)
    with open('data/OutAngle.dat', 'wb') as fp:
        pickle.dump(OutAngleVar.get(), fp)
    with open('data/TouchX_Shift.dat', 'wb') as fp:
        pickle.dump(TouchX_ShiftVar.get(), fp)
    with open('data/TouchY_Shift.dat', 'wb') as fp:
        pickle.dump(TouchY_ShiftVar.get(), fp)
    with open('data/TouchX_Scale.dat', 'wb') as fp:
        pickle.dump(TouchX_ScaleVar.get(), fp)
    with open('data/TouchY_Scale.dat', 'wb') as fp:
        pickle.dump(TouchY_ScaleVar.get(), fp)
    with open('data/IsTouchMonitorInverted.dat', 'wb') as fp:
        pickle.dump(IsTouchMonitorInvertedVar.get(), fp)
    with open('data/ButtonAWS_DurVar.dat', 'wb') as fp:
        pickle.dump(ButtonAWS_DurVar.get(), fp)
    with open('data/PanelUsed.dat', 'wb') as fp:
        pickle.dump(PanelUsed, fp)
    with open('data/PanelULX.dat', 'wb') as fp:
        pickle.dump(PanelULX, fp)
    with open('data/PanelULY.dat', 'wb') as fp:
        pickle.dump(PanelULY, fp)
    with open('data/PanelBRX.dat', 'wb') as fp:
        pickle.dump(PanelBRX, fp)
    with open('data/PanelBRY.dat', 'wb') as fp:
        pickle.dump(PanelBRY, fp)
    with open('data/MailAddress.dat', 'wb') as fp:
        pickle.dump(MailAddressVar.get(), fp)
    with open('data/DeviceName.dat', 'wb') as fp:
        pickle.dump(DeviceNameVar.get(), fp)
    with open('data/ArduinoConnection.dat', 'wb') as fp:
        pickle.dump(ArduinoConnectionVar.get(), fp)
    with open('data/MouseDebugMode.dat', 'wb') as fp:
        pickle.dump(MouseDebugModeVar.get(), fp)
    with open('data/CameraCaptureFreq.dat', 'wb') as fp:
        pickle.dump(CameraCaptureFreqVar.get(), fp)
    with open('data/PanelTexturePath.dat', 'wb') as fp:
        pickle.dump(PanelTexturePath, fp)
    with open('data/TaskStartTime1.dat', 'wb') as fp:
        pickle.dump(TaskStartTime1Var.get(), fp)
    with open('data/TaskStartTime2.dat', 'wb') as fp:
        pickle.dump(TaskStartTime2Var.get(), fp)
    with open('data/TaskStartTime3.dat', 'wb') as fp:
        pickle.dump(TaskStartTime3Var.get(), fp)
    with open('data/TaskStartTime4.dat', 'wb') as fp:
        pickle.dump(TaskStartTime4Var.get(), fp)
    with open('data/LightPhaseOnsetTime.dat', 'wb') as fp:
        pickle.dump(LightPhaseOnsetTimeVar.get(), fp)
    with open('data/DarkPhaseOnsetTime.dat', 'wb') as fp:
        pickle.dump(DarkPhaseOnsetTimeVar.get(), fp)
    with open('data/MovieWidth.dat', 'wb') as fp:
        pickle.dump(MovieWidthVar.get(), fp)
    with open('data/MovieHeight.dat', 'wb') as fp:
        pickle.dump(MovieHeightVar.get(), fp)
    with open('data/CableDetectCorrValue.dat', 'wb') as fp:
        pickle.dump(CableDetectCorrValueVar.get(), fp)
    return
def Start(): # Accept task parameters
    global Phase, Init, IsHousingAnalysis, SaveTrg, ExperimentStartYear, ExperimentStartMonth, ExperimentStartDay, ExperimentStartHour, ExperimentStartMinute, ExperimentStartSecond  # Global variant outside this define
    RemoveMainCenterWidget()
    RemoveMainRightWidget()
    Init = 0
    ExperimentStartYear = TimeNow.year
    ExperimentStartMonth = TimeNow.month
    ExperimentStartDay = TimeNow.day
    ExperimentStartHour = TimeNow.hour
    ExperimentStartMinute = TimeNow.minute
    ExperimentStartSecond = TimeNow.second + (TimeNow.microsecond // 1000) /1000
    SetTaskStartTime()
    SaveTrg = 1
    Phase += 1
    return
def StartNow(): # Manual task starting
    global Phase,Init, IsHousingAnalysis, TaskStartedYear, TaskStartedMonth, TaskStartedDay, TaskStartedHour, TaskStartedMinute, TaskStartedSecond, SaveTrg, bStartNow, bTimePlus, bTimeMinus, bBackToPara
    #RemoveMainRightWidget()

    #bStartNow.destroy()
    #bTimePlus.destroy()
    #bTimeMinus.destroy()
    #bBackToPara.destroy()
    RemoveMainCenterWidget()
    Init = 0
    TaskStartedYear = TimeNow.year
    TaskStartedMonth = TimeNow.month
    TaskStartedDay = TimeNow.day
    TaskStartedHour = TimeNow.hour
    TaskStartedMinute = TimeNow.minute
    TaskStartedSecond = TimeNow.second + (TimeNow.microsecond//1000)/1000
    SaveTrg=1
    Phase += 1
    return
def IsStartTime():
    global TaskStartHour, TaskStartMinute
    #print(TaskStartHour)
    ReturnValue = 0
    for i in range(4):
        if TaskStartHour[i]==TimeNow.hour and TaskStartMinute[i]==TimeNow.minute:
            ReturnValue=1
            print("Task start!")
    return ReturnValue
def SetTaskStartTime(): #
    global TaskStartHour, TaskStartMinute
    for i in range(4):
        if (i==0 and TaskStartTime1Var.get()!="") or (i==1 and TaskStartTime2Var.get()!="") or (i==2 and TaskStartTime3Var.get()!="") or (i==3 and TaskStartTime4Var.get()!=""):
            if i==0:
                String=TaskStartTime1Var.get()
            if i==1:
                String=TaskStartTime2Var.get()
            if i==2:
                String=TaskStartTime3Var.get()
            if i==3:
                String=TaskStartTime4Var.get()
            StringArray=String.split(':')
            if StringArray[0] != "":
                TaskStartHour[i] = int(StringArray[0])
            if StringArray[1] != "":
                TaskStartMinute[i] = int(StringArray[1])
    return
def SetLightCycleTime():
    global LightPhaseOnsetHour, LightPhaseOnsetMinute,  DarkPhaseOnsetHour, DarkPhaseOnsetMinute
    String = LightPhaseOnsetTimeVar.get()
    StringArray = String.split(':')
    if StringArray[0] != "":
        LightPhaseOnsetHour = int(StringArray[0])
    if StringArray[1] != "":
        LightPhaseOnsetMinute = int(StringArray[1])

    String = DarkPhaseOnsetTimeVar.get()
    StringArray = String.split(':')
    if StringArray[0] != "":
        DarkPhaseOnsetHour = int(StringArray[0])
    if StringArray[1] != "":
        DarkPhaseOnsetMinute = int(StringArray[1])
    return
def GetExperimentStartYear():
    global ExperimentStartYear
    return ExperimentStartYear
def GetExperimentStartMonth():
    global ExperimentStartMonth
    return ExperimentStartMonth
def GetExperimentStartDay():
    global ExperimentStartDay
    return ExperimentStartDay
def GetExperimentStartHour():
    global ExperimentStartHour
    return ExperimentStartHour
def GetExperimentStartMinute():
    global ExperimentStartMinute
    return ExperimentStartMinute
def GetExperimentStartSecond():
    global ExperimentStartSecond
    return ExperimentStartSecond

def GetTaskStartedYear():
    global TaskStartedYear
    return TaskStartedYear
def GetTaskStartedMonth():
    global TaskStartedMonth
    return TaskStartedMonth
def GetTaskStartedDay():
    global TaskStartedDay
    return TaskStartedDay
def GetTaskStartedHour():
    global TaskStartedHour
    return TaskStartedHour
def GetTaskStartedMinute():
    global TaskStartedMinute
    return TaskStartedMinute
def GetTaskStartedSecond():
    global TaskStartedSecond
    return TaskStartedSecond

def StartLickRecording():
    global StartLickRecordingTrg
    StartLickRecordingTrg = 1
    return
def EndLickRecording():
    global EndLickRecordingTrg
    EndLickRecordingTrg = 1
    return
def Back(): # Back to task selection
    global Phase, Init, ManualPanelOnTrg, MainWindowRightFrameX, MainWindowRightFrameY, MainWindowRightFrameWidth, MainWindowRightFrameHeight
    RemoveMainRightWidget()
    RemoveMainCenterWidget()
    MainWindowRightFrame.place(x=MainWindowRightFrameX, y=MainWindowRightFrameY, width=MainWindowRightFrameWidth, height=MainWindowRightFrameHeight)  #
    PutTaskButton()
    # Delete panel which is created by manual panel display button
    ManualPanelOnTrg = 1
    ToggleManualPanelOn()
    Init = 0
    Phase = -1
    return
def Setting():   #
    global Phase
    if Phase == 0 or Phase == -99: # If phase is task selection or setting
        RemoveMainRightWidget()
        Trg=0
        if Phase == 0:
            MainWindowRightFrame.place(x=MainWindowRightFrameX, y=MainWindowRightFrameY, width=MainWindowRightFrameWidth, height=MainWindowRightFrameHeight)  #
            PutSettingItem()
            Phase = -99   # Show setting items
            Trg=1
        if Phase == -99 and Trg==0:
            SaveGeneralParameter()
            MainWindowRightFrame.place(x=MainWindowRightFrameX , y=MainWindowRightFrameY, width=MainWindowRightFrameWidth, height=MainWindowRightFrameHeight)  #
            SetLightCycleTime()
            PutTaskButton()
            Phase = 0   # Show task selection items
    return
def DoneSetting():
    return
def SaveTrgOn():
    global SaveTrg
    SaveTrg=1
    SaveGeneralParameter()
    return

def BackToPara():   # Back to parameter input (This is not in use)
    global Phase,Init, ManualPanelOnTrg, MainWindowRightFrameX, MainWindowRightFrameY, MainWindowRightFrameWidth, MainWindowRightFrameHeight
    RemoveMainCenterWidget()
    RemoveMainRightWidget()
    MainWindowRightFrame.place(x=MainWindowRightFrameX, y=MainWindowRightFrameY, width=MainWindowRightFrameWidth, height=MainWindowRightFrameHeight)  #
    PutTaskButton()
    # Delete panel which is created by manual panel display button
    ManualPanelOnTrg = 1
    ToggleManualPanelOn()
    Phase = 0
    return

def EndTaskNow():   #
    global Phase2
    Phase2=-2   # End task WITHOUT automatic task switch
    #Phase2 = -1    # End task WITH automatic task switch
    return

def EndFlagOn():
    global EndFlag
    EndFlag = 1
    RoofLightTurnOff()
    InfraredTurnOff()
    WaterPosMiddle()  # Move water nozzle to the intermediate position
    return
def donothing():
    return
def SelectPathForSaving():  # Chose foler for saving results
    global Path,VideoWriter
    Path=filedialog.askdirectory(initialdir = dir)
    PathForSaving.set(Path)
    SaveGeneralParameter()
    return
def SelectPanel0TexPath():
    global PanelTexturePath
    FileSelectWinRoot = Tk()    # Show file select dialog
    FileSelectWinRoot.withdraw()
    fTyp = [("", "*")]
    iDir = os.path.abspath(os.path.dirname(__file__))
    PanelTexturePath[0]= filedialog.askopenfilename(filetypes=fTyp, initialdir=iDir)    # Get path of the texture
    #messagebox.showinfo('○×プログラム', PanelTexturePath[0])
    print("Texture path: " + PanelTexturePath[0])

    SaveGeneralParameter()
    return
def SelectPanel1TexPath():
    global PanelTexturePath
    FileSelectWinRoot = Tk()  # Show file select dialog
    FileSelectWinRoot.withdraw()
    fTyp = [("", "*")]
    iDir = os.path.abspath(os.path.dirname(__file__))
    PanelTexturePath[1] = filedialog.askopenfilename(filetypes=fTyp, initialdir=iDir)  # Get path of the texture
    print("Texture path: " + PanelTexturePath[1])

    SaveGeneralParameter()
    return
def SelectPanel2TexPath():
    global PanelTexturePath
    FileSelectWinRoot = Tk()  # Show file select dialog
    FileSelectWinRoot.withdraw()
    fTyp = [("", "*")]
    iDir = os.path.abspath(os.path.dirname(__file__))
    PanelTexturePath[2] = filedialog.askopenfilename(filetypes=fTyp, initialdir=iDir)  # Get path of the texture
    print("Texture path: " + PanelTexturePath[2])

    SaveGeneralParameter()
    return
def SelectPanel3TexPath():
    global PanelTexturePath
    FileSelectWinRoot = Tk()  # Show file select dialog
    FileSelectWinRoot.withdraw()
    fTyp = [("", "*")]
    iDir = os.path.abspath(os.path.dirname(__file__))
    PanelTexturePath[3] = filedialog.askopenfilename(filetypes=fTyp, initialdir=iDir)  # Get path of the texture
    print("Texture path: " + PanelTexturePath[3])

    SaveGeneralParameter()
    return
def PutTaskButton():
    ButtonWidth = 13
    bTask1 = ttk.Button(MainWindowRightFrame, text='Acclimation(1)', command=Task1, width=ButtonWidth).grid(row=0, column=0)
    bTask2 = ttk.Button(MainWindowRightFrame, text='SpatialDisc(2)', command=Task2, width=ButtonWidth).grid(row=0, column=1)
    bTask4 = ttk.Button(MainWindowRightFrame, text='SpatialDisc(4)', command=Task4, width=ButtonWidth).grid(row=0, column=2)
    bTask6 = ttk.Button(MainWindowRightFrame, text='PatternSep(6)', command=Task6, width=ButtonWidth).grid(row=0, column=3)
    bTask17 = ttk.Button(MainWindowRightFrame, text='DAT(17)', command=Task17, width=ButtonWidth).grid(row=0, column=4)
    bTask22 = ttk.Button(MainWindowRightFrame, text='DNMS(22)', command=Task22, width=ButtonWidth).grid(row=0, column=5)
    bTask23 = ttk.Button(MainWindowRightFrame, text='DNMS(23)', command=Task23, width=ButtonWidth).grid(row=0, column=6)
    bTask26 = ttk.Button(MainWindowRightFrame, text='Persev(26)', command=Task26, width=ButtonWidth).grid(row=0, column=7)
    bTask27 = ttk.Button(MainWindowRightFrame, text='PersevB1(27)', command=Task27, width=ButtonWidth).grid(row=0, column=8)
    bTask28 = ttk.Button(MainWindowRightFrame, text='Allo/Ago(28)', command=Task28, width=ButtonWidth).grid(row=0, column=9)
    bTask29 = ttk.Button(MainWindowRightFrame, text='Go/NoGo(29)', command=Task29, width=ButtonWidth).grid(row=1, column=0)
    bTask30 = ttk.Button(MainWindowRightFrame, text='Go/NoGo2(30)', command=Task30, width=ButtonWidth).grid(row=1, column=1)
    bTask31 = ttk.Button(MainWindowRightFrame, text='Timing(31)', command=Task31, width=ButtonWidth).grid(row=1, column=2)
    bTask32 = ttk.Button(MainWindowRightFrame, text='Habit(32)', command=Task32, width=ButtonWidth).grid(row=1, column=3)
    bTask33 = ttk.Button(MainWindowRightFrame, text='ProbPersev(33)', command=Task33, width=ButtonWidth).grid(row=1, column=4)

    return
def PutSettingItem():   #
    mNumOfDay = ttk.Label(MainWindowRightFrame, text='Mail address').grid(row=0, column=0)
    iMailAddress = ttk.Entry(MainWindowRightFrame, textvariable= MailAddressVar).grid(row=1, column=0)
    mDeviceName = ttk.Label(MainWindowRightFrame, text='Device name').grid(row=0, column=1, sticky=W)
    iDeviceName = ttk.Entry(MainWindowRightFrame, textvariable=DeviceNameVar).grid(row=1, column=1)
    mCameraCaptureFreq = ttk.Label(MainWindowRightFrame, text='Camera capture freq').grid(row=0, column=2, sticky=W)
    iCameraCaptureFreq = ttk.Entry(MainWindowRightFrame, textvariable=CameraCaptureFreqVar).grid(row=1, column=2)  #
    mTouchX_Shift = ttk.Label(MainWindowRightFrame, text='TouchX_Shift').grid(row=0, column=3)
    iTouchX_Shift = ttk.Entry(MainWindowRightFrame, textvariable=TouchX_ShiftVar).grid(row=1, column=3)
    mTouchY_Shift = ttk.Label(MainWindowRightFrame, text='TouchY_Shift').grid(row=0, column=4)
    iTouchY_Shift = ttk.Entry(MainWindowRightFrame, textvariable=TouchY_ShiftVar).grid(row=1, column=4)
    mTouchX_Scale = ttk.Label(MainWindowRightFrame, text='TouchX_Scale').grid(row=0, column=5)
    iTouchX_Scale = ttk.Entry(MainWindowRightFrame, textvariable=TouchX_ScaleVar).grid(row=1, column=5)
    mTouchY_Scale = ttk.Label(MainWindowRightFrame, text='TouchY_Scale').grid(row=0, column=6)
    iTouchY_Scale = ttk.Entry(MainWindowRightFrame, textvariable=TouchY_ScaleVar).grid(row=1, column=6)
    mIsTouchMonitorInverted = ttk.Label(MainWindowRightFrame, text='Touch monitor').grid(row=0, column=7, sticky=W)
    tIsTouchMonitorInverted = OptionMenu(MainWindowRightFrame, IsTouchMonitorInvertedVar, "Normal", "Inverted").grid(row=1, column=7)

    mArduinoConnection = ttk.Label(MainWindowRightFrame, text='Arduino connection').grid(row=2, column=0, sticky=W)
    tArduinoConnection = OptionMenu(MainWindowRightFrame, ArduinoConnectionVar, "ON", "OFF").grid(row=3, column=0)
    mMouseDebugMode = ttk.Label(MainWindowRightFrame, text='Mouse debug mode').grid(row=2, column=1, sticky=W)
    tMouseDebugMode = OptionMenu(MainWindowRightFrame, MouseDebugModeVar, "ON", "OFF").grid(row=3, column=1)
    mPanel0Texture = ttk.Label(MainWindowRightFrame, text='Panel0 texture').grid(row=2, column=2, sticky=W)
    bPanel0Texture = ttk.Button(MainWindowRightFrame, text='Select', command=SelectPanel0TexPath)
    bPanel0Texture.grid(row=3, column=2, sticky=W)
    mPanel1Texture = ttk.Label(MainWindowRightFrame, text='Panel1 texture').grid(row=2, column=3, sticky=W)
    bPanel1Texture = ttk.Button(MainWindowRightFrame, text='Select', command=SelectPanel1TexPath)
    bPanel1Texture.grid(row=3, column=3, sticky=W)
    mPanel2Texture = ttk.Label(MainWindowRightFrame, text='Panel2 texture').grid(row=2, column=4, sticky=W)
    bPanel2Texture = ttk.Button(MainWindowRightFrame, text='Select', command=SelectPanel2TexPath)
    bPanel2Texture.grid(row=3, column=4, sticky=W)
    mPanel3Texture = ttk.Label(MainWindowRightFrame, text='Panel3 texture').grid(row=2, column=5, sticky=W)
    bPanel3Texture = ttk.Button(MainWindowRightFrame, text='Select', command=SelectPanel3TexPath)
    bPanel3Texture.grid(row=3, column=5, sticky=W)

    mCableDetectCorrValue = ttk.Label(MainWindowRightFrame, text='CableDetectCorrValue').grid(row=2, column=6, sticky=W)
    iCableDetectCorrValue = ttk.Entry(MainWindowRightFrame, textvariable=CableDetectCorrValueVar).grid(row=3, column=6)  #

    mTaskStart1 = ttk.Label(MainWindowRightFrame, text='TaskStart1(h:m)').grid(row=4, column=0)
    iTaskStart1 = ttk.Entry(MainWindowRightFrame, textvariable=TaskStartTime1Var).grid(row=5, column=0)  #
    mTaskStart2 = ttk.Label(MainWindowRightFrame, text='TaskStart2(h:m)').grid(row=4, column=1)
    iTaskStart2 = ttk.Entry(MainWindowRightFrame, textvariable=TaskStartTime2Var).grid(row=5, column=1)  #
    mTaskStart3 = ttk.Label(MainWindowRightFrame, text='TaskStart3(h:m)').grid(row=4, column=2)
    iTaskStart3 = ttk.Entry(MainWindowRightFrame, textvariable=TaskStartTime3Var).grid(row=5, column=2)  #
    mTaskStart4 = ttk.Label(MainWindowRightFrame, text='TaskStart4(h:m)').grid(row=4, column=3)
    iTaskStart4 = ttk.Entry(MainWindowRightFrame, textvariable=TaskStartTime4Var).grid(row=5, column=3)  #
    mLightPhaseOnsetTime = ttk.Label(MainWindowRightFrame, text='Light-phase onset').grid(row=4, column=4)
    iLightPhaseOnsetTime = ttk.Entry(MainWindowRightFrame, textvariable=LightPhaseOnsetTimeVar).grid(row=5, column=4)  #
    mDarkPhaseOnsetTime = ttk.Label(MainWindowRightFrame, text='Dark-phase onset').grid(row=4, column=5)
    iDarkPhaseOnsetTime = ttk.Entry(MainWindowRightFrame, textvariable=DarkPhaseOnsetTimeVar).grid(row=5, column=5)  #

    mMovieWidth = ttk.Label(MainWindowRightFrame, text='Movie width(pixel)').grid(row=4, column=6)
    iMovieWidth = ttk.Entry(MainWindowRightFrame, textvariable=MovieWidthVar).grid(row=5, column=6)  #
    mMovieHeight = ttk.Label(MainWindowRightFrame, text='Movie height(pixel)').grid(row=4, column=7)
    iMovieHeight = ttk.Entry(MainWindowRightFrame, textvariable=MovieHeightVar).grid(row=5, column=7)  #
    return
'''
def PutAllPanel():  # Show all panels on the monitor
    for i in range(0, MaxPanelNum):
        ULX = PanelULX[Task][i]
        ULY = PanelULY[Task][i]
        BRX = PanelBRX[Task][i]
        BRY = PanelBRY[Task][i]
        if ULX!=0 or ULY!=0 or BRX!=0 or BRY!=0:
            TouchPanelRef[i] = CanvasTouchWindow.create_rectangle(ULX, ULY, BRX, BRY, fill='white')  # Draw current panel
    return
'''
def PutStartBackButton():   # Put start and back button
    global MainWindowRightFrameX, MainWindowRightFrameY, MainWindowRightFrameWidth, MainWindowRightFrameHeight
    MainWindowCenterFrame.place(x=MainWindowCenterFrameX, y=MainWindowCenterFrameY, width=MainWindowCenterFrameWidth, height=MainWindowCenterFrameHeight)  #
    MainWindowRightFrame.place(x=MainWindowRightFrameX+100, y=MainWindowRightFrameY, width=MainWindowRightFrameWidth, height=MainWindowRightFrameHeight)  #
    bStart = ttk.Button(MainWindowCenterFrame, text='Start', command=Start)
    bStart.place(x=0, y=0, width=80)
    bAdjustPanel = ttk.Button(MainWindowCenterFrame, text='AdjustPanel', command=SetPanel)
    bAdjustPanel.place(x=0, y=25, width=80)
    bBack = ttk.Button(MainWindowCenterFrame, text='Back', command=Back)
    bBack.place(x=0, y=50, width=80)
    return
def PutPreTaskButton():
    global bStartNow, bTimePlus, bTimeMinus, bBackToPara, bStartNow, bTimePlus
    bStartNow = ttk.Button(MainWindowCenterFrame, text='StartNow', command=StartNow)
    bStartNow.grid(row=0, column=0)
    #bTimePlus = ttk.Button(MainWindowRightFrame, text='+1 hour', command=Back)
    #bTimePlus.grid(row=1, column=0)
    #bTimeMinus = ttk.Button(MainWindowRightFrame, text='-1 hour', command=Back)
    #bTimeMinus.grid(row=2, column=0)
    bBackToPara = ttk.Button(MainWindowCenterFrame, text='Back', command=BackToPara)
    bBackToPara.grid(row=1, column=0)

    #bBackToPara.destroy()
    return
def PutEndTaskNowButton():
    global IsThereEndTaskNowButton, bEndTaskNow
    bEndTaskNow = ttk.Button(MainWindowCenterFrame, text='EndTask', command=EndTaskNow)
    bEndTaskNow.grid(row=0, column=0)
    IsThereEndTaskNowButton=1
    return
def RemoveEndTaskNowButton():
    global IsThereEndTaskNowButton, bEndTaskNow
    bEndTaskNow.destroy()
    IsThereEndTaskNowButton=0
    return
def RemoveMainCenterWidget(): # Destroy all task buttons
    global MainWindowCenterFrame
    ChildWidget = MainWindowCenterFrame.winfo_children()
    for ChildWidget in ChildWidget:
        ChildWidget.destroy()
    return
def RemoveMainRightWidget(): # Destroy all task buttons
    global MainWindowRightFrame
    ChildWidget = MainWindowRightFrame.winfo_children()
    for ChildWidget in ChildWidget:
        ChildWidget.destroy()
    return
def MoveCrossFireUp():  # For panel position setting
    global CrossFireY
    CanvasTouchWindow.move(HorizontalLine, 0.0, -CrossFireMoveDistance)
    #VerticalLine.place(x=10, y=10)
    #CrossFireY-=1
    return
def MoveCrossFireRight():   # For panel position setting
    global CrossFireX
    CanvasTouchWindow.move(VerticalLine, CrossFireMoveDistance, 0.0)
    #CrossFireX+=1
    return
def MoveCrossFireLeft():  # For panel position setting
    global CrossFireX
    CanvasTouchWindow.move(VerticalLine, -CrossFireMoveDistance, 0.0)
    #CrossFireX-=1
    return
def MoveCrossFireDown():  # For panel position setting
    global CrossFireY
    CanvasTouchWindow.move(HorizontalLine, 0.0, CrossFireMoveDistance)
    #CrossFireY+=1
    return
def CoarseMode():  # For panel position setting
    global CrossFireMoveDistance
    CrossFireMoveDistance += 10.0
    if CrossFireMoveDistance > 50.0:
        CrossFireMoveDistance = 50.0
    return
def FineMode():  # For panel position setting
    global CrossFireMoveDistance
    CrossFireMoveDistance -= 10.0
    if CrossFireMoveDistance < 2.0:
        CrossFireMoveDistance = 2.0
    return
def SetPanelPos(): # Go to the next panel position setting
    global Phase, Init, Task, CurrentPanelNum, PanelULX, PanelULY, VerticalLine, HorizontalLine, TouchPanelRef
    Trg=0
    if Phase == 0: # If set button is pushed during setting of upper left position of the touch panel
        WedgetPos = CanvasTouchWindow.coords(VerticalLine)  # Get position of vertical line
        PanelULX[Task][CurrentPanelNum] = WedgetPos[0]  # Get y axis value of the vertical line
        WedgetPos = CanvasTouchWindow.coords(HorizontalLine)
        PanelULY[Task][CurrentPanelNum] = WedgetPos[1]
        NextX = PanelBRX[Task][CurrentPanelNum]
        NextY = PanelBRY[Task][CurrentPanelNum]
        if  NextX==0 and NextY==0:  # If the values are default
            if CurrentPanelNum==0:
                NextX = PanelULX[Task][CurrentPanelNum]+100 # Move the crossfire toward right bottom
                NextY = PanelULY[Task][CurrentPanelNum]+250
            if CurrentPanelNum>0:
                NextX = PanelULX[Task][CurrentPanelNum]+(PanelBRX[Task][CurrentPanelNum-1]-PanelULX[Task][CurrentPanelNum-1])   # Move the crossfire to even the panel size with the previous panel
                NextY = PanelULY[Task][CurrentPanelNum]+(PanelBRY[Task][CurrentPanelNum-1]-PanelULY[Task][CurrentPanelNum-1])
        CanvasTouchWindow.coords(VerticalLine, NextX, 0, NextX, TouchWindowHeight)  # Move vertical line of the cross fire
        CanvasTouchWindow.coords(HorizontalLine, 0, NextY, TouchWindowWidth, NextY)
        SaveGeneralParameter()
        Phase += 1
        Init=0
        Trg = 1
    if Phase == 1 and Trg==0:  # If set button is pushed during setting of bottom right position of the touch panel
        WedgetPos = CanvasTouchWindow.coords(VerticalLine)
        PanelBRX[Task][CurrentPanelNum] = WedgetPos[0]
        PanelUsed[Task][CurrentPanelNum] = 1
        WedgetPos = CanvasTouchWindow.coords(HorizontalLine)
        PanelBRY[Task][CurrentPanelNum] = WedgetPos[1]
        PosULX = PanelULX[Task][CurrentPanelNum]
        PosULY = PanelULY[Task][CurrentPanelNum]
        PosBRX= PanelBRX[Task][CurrentPanelNum]
        PosBRY = PanelBRY[Task][CurrentPanelNum]
        TouchPanelRef[CurrentPanelNum] = CanvasTouchWindow.create_rectangle(PosULX, PosULY, PosBRX, PosBRY, fill='white')  # Draw current panel

        SaveGeneralParameter()
        Phase += 1
        Init = 0
        Trg = 1
    if Phase == 2 and Trg==0:  # Continue panel setting
        CurrentPanelNum+=1
        Phase=0
        Init = 0
    return
def BackPanelPos(): # Back to the previous panel position setting
    return
def EndPanelSetting():  # Finish panel position setting
    global Phase
    Phase=-1    # Make flag to finish panel position setting loop
    return

def SetPanel(): # Contain main roop during panel position setting
    global Phase, Init, CurrentPanelNum, CrossFireX, CrossFireY, VerticalLine, HorizontalLine
    VerticalLine = CanvasTouchWindow.create_line(100, 0, 100, 1200, fill='cyan', tags="Panel")  # Make vertical line of the cross fire
    HorizontalLine = CanvasTouchWindow.create_line(0, 500, 1200, 500, fill='red', tags="Panel")  # Make horizontal line of the cross fire
    Init=0
    CurrentPanelNum=0
    Phase=0
    while EndFlag == 0: # Panel adjust main loop
        OperantHouseUpdate()
        if Phase == 0 or Phase == 1:    # Move crossfire to indicate panel coordinates
            if Init == 0:
                RemoveMainRightWidget()
                MainWindowRightFrame.place(x=MainWindowRightFrameX, y=MainWindowRightFrameY, anchor="nw", width=MainWindowRightFrameWidth, height=MainWindowRightFrameHeight)
                if Phase == 0:
                    PosX = PanelULX[Task][CurrentPanelNum]
                    PosY = PanelULY[Task][CurrentPanelNum]
                    if PosX == 0 and  PosY == 0:    # If there is no data about the panel coordinate
                        if CurrentPanelNum==0:
                            PosX = 200
                            PosY = 400
                        if CurrentPanelNum>0:
                            PosX = PanelBRX[Task][CurrentPanelNum-1]
                            PosY = PanelULY[Task][CurrentPanelNum-1]
                    CanvasTouchWindow.coords(VerticalLine, PosX, 0, PosX, TouchWindowHeight)    # Move vertical line of the cross fire
                    CanvasTouchWindow.coords(HorizontalLine, 0, PosY, TouchWindowWidth, PosY)   # Move horizontal line of the cross fire
                    mCharaMessage = ttk.Label(MainWindowRightFrame, text='Set left upper coordinate of the panel #'+str(CurrentPanelNum)+'.').place(x=CharaMesX, y=CharaMesY)
                if Phase == 1:
                    mCharaMessage = ttk.Label(MainWindowRightFrame, text='Set right bottom coordinate of the panel #' + str(CurrentPanelNum) + '.').place(x=CharaMesX, y=CharaMesY)
                mCoordinatesVar = StringVar(MainWindowRoot)
                mCoordinates = ttk.Label(MainWindowRightFrame, textvariable=mCoordinatesVar).place(x=43, y=30)
                bMoveUp = ttk.Button(MainWindowRightFrame, text='Up', command=MoveCrossFireUp).place(x=43, y=50)
                bMoveLeft = ttk.Button(MainWindowRightFrame, text='Left', command=MoveCrossFireLeft).place(x=0, y=75)
                bMoveRight = ttk.Button(MainWindowRightFrame, text='Right', command=MoveCrossFireRight).place(x=86, y=75)
                bMoveDown = ttk.Button(MainWindowRightFrame, text='Down', command=MoveCrossFireDown).place(x=43, y=100)
                bCoarseMode = ttk.Button(MainWindowRightFrame, text='Coarse', command=CoarseMode).place(x=200, y=50)
                bFineMode = ttk.Button(MainWindowRightFrame, text='FineMode', command=FineMode).place(x=200, y=75)
                bSet = ttk.Button(MainWindowRightFrame, text='Set', command=SetPanelPos).place(x=200, y=100)

                Init=1
            WedgetPos = CanvasTouchWindow.coords(VerticalLine)  # Get position of vertical line
            PosX = WedgetPos[0]  # Get y axis value of the vertical line
            WedgetPos = CanvasTouchWindow.coords(HorizontalLine)
            PosY = WedgetPos[1]
            mCoordinatesVar.set('X:'+str(PosX)+'  Y:'+str(PosY))
        if Phase == 2:  # Chose whether adjust next panel
            if Init == 0:
                RemoveMainRightWidget()
                mCharaMessage = ttk.Label(MainWindowRightFrame, text='Do you want to set the coordinates of the next panel?').place(x=CharaMesX, y=CharaMesY)
                bSetNextPanelYes = ttk.Button(MainWindowRightFrame, text='Yes', command=SetPanelPos).place(x=0, y=60)
                bSetNextPanelNo = ttk.Button(MainWindowRightFrame, text='No', command=EndPanelSetting).place(x=86, y=60)
                Init = 1
        if Phase == -1: # Panel adjust finish process
            RemoveMainRightWidget()
            CanvasTouchWindow.delete(VerticalLine)
            CanvasTouchWindow.delete(HorizontalLine)

            for i in range(0, MaxPanelNum):
                if TouchPanelRef[i]:
                    CanvasTouchWindow.delete(TouchPanelRef[i])
                if i > CurrentPanelNum:
                    PanelUsed[Task][i] = 0
                    PanelULX[Task][i] = 0
                    PanelULY[Task][i] = 0
                    PanelBRX[Task][i] = 0
                    PanelBRY[Task][i] = 0
            SaveGeneralParameter()
            PutTaskButton()
            Phase = 0
            break
    return

def WaterPosInside():
    global IndicatedWaterPos, ServoWorkTime, ServoOutputBook, Angle
    IndicatedWaterPos=1
    if InAngleVar.get()!="":
        Angle = int(InAngleVar.get())
    ServoWorkTime=2 # Turn on the power of servo for 2 sec
    Timer_Start(4)  # Timer for servo power
    ServoOutputBook = 1  # Book output of servo angle through serial connection
    return
def WaterPosMiddle():
    global IndicatedWaterPos, ServoWorkTime, ServoOutputBook, Angle
    IndicatedWaterPos=0
    if MidAngleVar.get()!="":
        Angle = int(MidAngleVar.get())
    ServoWorkTime = 2
    Timer_Start(4)
    ServoOutputBook = 1  # Book output of servo angle through serial connection
    return
def WaterPosOutside():
    global IndicatedWaterPos, ServoWorkTime, ServoOutputBook, Angle
    IndicatedWaterPos=2
    if OutAngleVar.get()!="":
        Angle = int(OutAngleVar.get())
    ServoWorkTime = 2
    Timer_Start(4)
    ServoOutputBook = 1  # Book output of servo angle through serial connection
    return

def RoofLightTurnOn():
    global IndicatedRoofLightPower, DigitalPinOutputBook
    IndicatedRoofLightPower=1
    DigitalPinOutputBook=1 # Book output of digital pin status through serial connection

    return
def RoofLightTurnOff():
    global IndicatedRoofLightPower, DigitalPinOutputBook
    IndicatedRoofLightPower=-1
    DigitalPinOutputBook = 1  # Book output of digital pin status through serial connection
    NosePokeDetectionTempOff()
    return
def InfraredTurnOn():
    global IndicatedInfraredPower, DigitalPinOutputBook
    IndicatedInfraredPower=1
    DigitalPinOutputBook = 1  # Book output of digital pin status through serial connection
    return
def InfraredTurnOff():
    global IndicatedInfraredPower, DigitalPinOutputBook
    IndicatedInfraredPower=-1
    DigitalPinOutputBook = 1  # Book output of digital pin status through serial connection
    return
def WaterCueTurnOn():
    global IndicatedWaterCue, DigitalPinOutputBook
    IndicatedWaterCue=1
    DigitalPinOutputBook = 1  # Book output of digital pin status through serial connection
    return
def WaterCueTurnOff():
    global IndicatedWaterCue, DigitalPinOutputBook
    IndicatedWaterCue=-1
    DigitalPinOutputBook = 1  # Book output of digital pin status through serial connection
    return
def ValveTtlTurnOn():
    global IndicatedValveTtlPower, DigitalPinOutputBook
    IndicatedValveTtlPower=1
    DigitalPinOutputBook = 1  # Book output of digital pin status through serial connection
    return
def ValveTtlTurnOff():
    global IndicatedValveTtlPower, DigitalPinOutputBook
    IndicatedValveTtlPower=-1
    DigitalPinOutputBook = 1  # Book output of digital pin status through serial connection
    return
def HoleCueTurnOn(Num):
    global IndicatedHoleCue, DigitalPinOutputBook
    IndicatedHoleCue[Num]=1
    DigitalPinOutputBook = 1  # Book output of digital pin status through serial connection
    return
def HoleCueTurnOff(Num):
    global IndicatedHoleCue, DigitalPinOutputBook
    IndicatedHoleCue[Num]=-1
    DigitalPinOutputBook = 1  # Book output of digital pin status through serial connection
    return
def HoleWaterCueTurnOn(Num):
    global IndicatedHoleWaterCue, DigitalPinOutputBook
    IndicatedHoleWaterCue[Num]=1
    DigitalPinOutputBook = 1  # Book output of digital pin status through serial connection
    return
def HoleWaterCueTurnOff(Num):
    global IndicatedHoleWaterCue, DigitalPinOutputBook
    IndicatedHoleWaterCue[Num]=-1
    DigitalPinOutputBook = 1  # Book output of digital pin status through serial connection
    return
def ShowTouchSymbol(Num): # Show symbol on the camera window for a certain time
    global TouchSymbolCnt
    TouchSymbolCnt = Num
    return
def NosePokeDetectionTempOff():
    global NosePokeDetectionOn
    NosePokeDetectionOn=0
    Timer_Start(6)
    return
def CreateNormalPanel(id):
    global Task, TouchPanelRef, PanelULX, PanelULY, PanelBRX, PanelBRY, MaxPanelNum, IsHiddenPanel, TypeOfPanel
    TouchPanelRef[id] = CanvasTouchWindow.create_rectangle(PanelULX[Task][id], PanelULY[Task][id], PanelBRX[Task][id], PanelBRY[Task][id], fill='white')  # Create panel
    TypeOfPanel[id] = 0
    CanvasTouchWindow.itemconfigure(TouchPanelRef[id], state='hidden')  # Hide created panel
    IsHiddenPanel[id] = 1
    print('Normal panel is created')
    return
def CreateNormalPanel_All():
    global Task, TouchPanelRef, PanelULX, PanelULY, PanelBRX, PanelBRY, MaxPanelNum, IsHiddenPanel, TypeOfPanel
    for i in range(0, MaxPanelNum):
        if PanelUsed[Task][i] == 1:
            TouchPanelRef[i] = CanvasTouchWindow.create_rectangle(PanelULX[Task][i], PanelULY[Task][i], PanelBRX[Task][i], PanelBRY[Task][i], fill='white')  # Create panel
            TypeOfPanel[i] = 0
            CanvasTouchWindow.itemconfigure(TouchPanelRef[i], state='hidden')  # Hide created panel
            IsHiddenPanel[i] = 1
            print('Normal panel is created')
        if PanelUsed[Task][i] == 0:
            break
    return
def CreateBlinkPanel(id):
    global Task, TouchPanelRef, PanelULX, PanelULY, PanelBRX, PanelBRY, MaxPanelNum, IsHiddenPanel, TypeOfPanel, BlinkPanelNum
    TouchPanelRef[id] = CanvasTouchWindow.create_rectangle(PanelULX[Task][id], PanelULY[Task][id], PanelBRX[Task][id], PanelBRY[Task][id], fill='white')  # Create panel
    TypeOfPanel[id] = 1   # Make this panel blinks
    CanvasTouchWindow.itemconfigure(TouchPanelRef[id], state='hidden')  # Hide created panel
    IsHiddenPanel[id] = 1
    BlinkPanelNum+=1
    print('Blink panel is created')
    return
def CreateBlinkPanel_All():
    global Task, TouchPanelRef, PanelULX, PanelULY, PanelBRX, PanelBRY, MaxPanelNum, IsHiddenPanel, TypeOfPanel, BlinkPanelNum
    for i in range(0, MaxPanelNum):
        if PanelUsed[Task][i] == 1:
            TouchPanelRef[i] = CanvasTouchWindow.create_rectangle(PanelULX[Task][i], PanelULY[Task][i], PanelBRX[Task][i], PanelBRY[Task][i], fill='white')  # Create panel
            TypeOfPanel[i] = 1   # Make this panel blinks
            CanvasTouchWindow.itemconfigure(TouchPanelRef[i], state='hidden')  # Hide created panel
            IsHiddenPanel[i] = 1
            BlinkPanelNum+=1
            print('Blink panel is created')
        if PanelUsed[Task][i] == 0:
            break
    return
def CreateTexturedPanel(id):  # Replace normal panel with textured panel
    global TypeOfPanel,TouchPanelRef, Task, IsHiddenPanel, PanelULX, PanelULY, PanelTexturePath, PanelTextureImage
    PanelTextureImage[id] = PhotoImage(file=PanelTexturePath[id])  # Load texture file
    TouchPanelRef[id] = CanvasTouchWindow.create_image(PanelULX[Task][id], PanelULY[Task][id], image=PanelTextureImage[id], anchor=NW)   # Create new textured panel
    CanvasTouchWindow.itemconfigure(TouchPanelRef[id], state='hidden')  # Hide created panel
    IsHiddenPanel[id] = 1
    TypeOfPanel[id]=2   # Make this panel blinks
    print('Textured panel is created')
    return

def CreateTexturedPanel_All():  # Replace normal panel with textured panel
    global TypeOfPanel,TouchPanelRef, Task, IsHiddenPanel, PanelULX, PanelULY, PanelTexturePath, PanelTextureImage, MaxPanelNum
    for i in range(0, MaxPanelNum):
        if PanelUsed[Task][i] == 1:
            PanelTextureImage[i] = PhotoImage(file=PanelTexturePath[i])  # Load texture file
            TouchPanelRef[i] = CanvasTouchWindow.create_image(PanelULX[Task][i], PanelULY[Task][i], image=PanelTextureImage[i], anchor=NW)   # Create new textured panel
            CanvasTouchWindow.itemconfigure(TouchPanelRef[i], state='hidden')  # Hide created panel
            IsHiddenPanel[i] = 1
            TypeOfPanel[i]=2   # Make this panel blinks
            print('Textured panel is created')
        if PanelUsed[Task][i] == 0:
            break
    return

def ShowPanel(id):    # Show particular panel for the current task
    global TouchPanelRef, IsHiddenPanel
    CanvasTouchWindow.itemconfigure(TouchPanelRef[id], state='normal')  # Show created panel
    IsHiddenPanel[id] = 0
    return
def ShowAllPanel():    # Show particular panel for the current task
    global TouchPanelRef, IsHiddenPanel, Task
    for i in range(0, MaxPanelNum):
        if PanelUsed[Task][i]==1:
            CanvasTouchWindow.itemconfigure(TouchPanelRef[id], state='normal')  # Show created panel
            IsHiddenPanel[id] = 0
        if PanelUsed[Task][i] == 0:
            break
    return
def HidePanel(id):    # Hide particular panel for the current task
    global TouchPanelRef, IsHiddenPanel
    CanvasTouchWindow.itemconfigure(TouchPanelRef[id], state='hidden')  # Hide created panel
    IsHiddenPanel[id]=1
    return
def HideAllPanel(): #
    global TouchPanelRef, IsHiddenPanel, MaxPanelNum, Task
    for i in range(0, MaxPanelNum):
        if PanelUsed[Task][i]==1:
            CanvasTouchWindow.itemconfigure(TouchPanelRef[i], state='hidden')  # Hide created panel
            IsHiddenPanel[i] = 1
        if PanelUsed[Task][i] == 0:
            break
    return
def DeletePanel(id):
    global TouchPanelRef, TypeOfPanel, BlinkPanelNum
    CanvasTouchWindow.delete(TouchPanelRef[id])  # Delete panels
    if TypeOfPanel[i] == 1: # If this is blink panel
        BlinkPanelNum -= 1
    return
def ClearPanel():   # Delete panels
    global TouchPanelRef, BlinkPanelNum, IsHiddenPanel, TypeOfPanel
    for i in range(0, MaxPanelNum):
        if TouchPanelRef[i]:
            CanvasTouchWindow.delete(TouchPanelRef[i])  # Delete panels
            IsHiddenPanel[i] = 0
            TypeOfPanel[i] = 0
    BlinkPanelNum = 0
    return



def MakeWaterCueBlink():
    global IsWaterCueBlink
    IsWaterCueBlink=1
    return
def MakeWaterCueNonBlink():
    global IsWaterCueBlink
    IsWaterCueBlink=0
    return
def StartArbitaryWaterSupply(millisec):  #
    global AWS_On, AWS_IndicatedDur, AWS_Dur, AWS_PreFrameMilliSec, AWS_CurrFrameMilliSec, AWS_Stat
    AWS_On=1
    AWS_IndicatedDur=millisec
    AWS_Dur = 0
    AWS_PreFrameMilliSec=(TimeNow.hour*60*60*1000) + (TimeNow.minute*60*1000) + (TimeNow.second*1000) + TimeNow.microsecond//1000
    AWS_CurrFrameMilliSec =AWS_PreFrameMilliSec
    AWS_Stat=0
    WaterPosInside()
    WaterCueTurnOn()
    return
def GetArbitaryWaterSupplyStat():
    global AWS_Stat
    return AWS_Stat
def SwitchTask(id): #
    global  AutoTaskSwitchPhase, NextTaskID
    AutoTaskSwitchPhase = 1
    NextTaskID = id
    return

def Task1():
    global Phase, Phase2, Init, Task, SaveTrg, LoadTrg, NosePoking, DuringTask, NowRecording, RecordFPS
    Task = 1
    Phase0_Init = 0
    Phase1_Init = 0
    Phase2_Init = 0

    while EndFlag == 0:
        OperantHouseUpdate()
        if Phase == -1:  # Back to the task select phase
            Phase = 0
            Task = 0
            break
        if Phase == 0:  # Parameter inputs
            if Phase0_Init == 0:
                LoadTrg = 1
                # Make GUI for the setting of the parameters for this task
                RemoveMainRightWidget()  # Remove task buttons
                PutStartBackButton()  # Put start/back buttons

                EntryWidth = 128  # Width of entry field
                GridX = 0  # Upper left X coordination of grids
                GridY = 0  # Upper left Y coordination of grids
                GridWidth = 128  # Width of grids
                GridHeight = 25  # Height of grids

                Row = 0  # Current row of grid
                Line = 0  # Current line of grid

                mTimeLimit = ttk.Label(MainWindowRightFrame, text='TimeLimit(min)')
                mTimeLimit.place(x=GridX + Row * GridWidth, y=GridY + Line * GridHeight, width=EntryWidth)  # Put label
                TimeLimitVar = IntVar(MainWindowRoot)
                iTimeLimit = ttk.Entry(MainWindowRightFrame, textvariable=TimeLimitVar)
                iTimeLimit.place(x=GridX + Row * GridWidth, y=GridY + (Line + 1) * GridHeight - 3, width=EntryWidth)  # Place entry field
                Row += 1  # Shift row

                mNumOfDay = ttk.Label(MainWindowRightFrame, text='NumOfDay')
                mNumOfDay.place(x=GridX + Row * GridWidth, y=GridY + Line * GridHeight, width=EntryWidth)  # Put label
                NumOfDayVar = IntVar(MainWindowRoot)
                iNumOfDay = ttk.Entry(MainWindowRightFrame, textvariable=NumOfDayVar)
                iNumOfDay.place(x=GridX + Row * GridWidth, y=GridY + (Line + 1) * GridHeight - 3, width=EntryWidth)  # Place entry field
                Row += 1  # Shift row

                mNextTask = ttk.Label(MainWindowRightFrame, text='NextTask#')
                mNextTask.place(x=GridX + Row * GridWidth, y=GridY + Line * GridHeight, width=EntryWidth)  # Put label
                NextTaskVar = IntVar(MainWindowRoot)
                iNextTask = ttk.Entry(MainWindowRightFrame, textvariable=NextTaskVar)
                iNextTask.place(x=GridX + Row * GridWidth, y=GridY + (Line + 1) * GridHeight - 3, width=EntryWidth)  # Place entry field
                Row += 1  # Shift row
                mWaterCueType = ttk.Label(MainWindowRightFrame, text='WaterCueType')
                mWaterCueType.place(x=GridX + Row * GridWidth, y=GridY + Line * GridHeight, width=EntryWidth)  # Put label
                WaterCueTypeVar = StringVar(MainWindowRightFrame)
                tWaterCueType = OptionMenu(MainWindowRightFrame, WaterCueTypeVar, "Normal", "Blink")
                tWaterCueType.place(x=GridX + Row * GridWidth, y=GridY + (Line + 1) * GridHeight - 3, width=EntryWidth)  # Place entry field
                Row += 1  # Shift row

                Phase0_Init = 1

        if LoadTrg == 1:  # If load trigger is on
            Str = "ParametersForTask" + str(Task)

            if os.path.exists(Str + '/TimeLimit.dat') == True:  # If save file exists
                with open(Str + '/TimeLimit.dat', 'rb') as PickleInst[Task]:
                    TimeLimitVar.set(pickle.load(PickleInst[Task]))  # Load
            else:
                TimeLimitVar.set(360)  # Default value

            if os.path.exists(Str + '/NumOfDay.dat') == True:  # If save file exists
                with open(Str + '/NumOfDay.dat', 'rb') as PickleInst[Task]:
                    NumOfDayVar.set(pickle.load(PickleInst[Task]))  # Load
            else:
                NumOfDayVar.set(1)  # Default value

            if os.path.exists(Str + '/NextTask.dat') == True:  # If save file exists
                with open(Str + '/NextTask.dat', 'rb') as PickleInst[Task]:
                    NextTaskVar.set(pickle.load(PickleInst[Task]))  # Load
            else:
                NextTaskVar.set(2)  # Default value
            if os.path.exists(Str + '/WaterCueType.dat') == True:  # If save file exists
                with open(Str + '/WaterCueType.dat', 'rb') as PickleInst[Task]:
                    WaterCueTypeVar.set(pickle.load(PickleInst[Task]))  # Load
            else:
                WaterCueTypeVar.set('Normal')  # Default value

            LoadTrg = 0

        if SaveTrg == 1:  # If save trigger is on
            # Parameters of each task are saved into different folder
            Str = "ParametersForTask" + str(Task)  # Path to the folder for saving of parameters
            if os.path.exists(Str) == False:  # If folder for saving parameters is not exist
                os.mkdir(Str)  # Make folder for saving
            with open(Str + '/TimeLimit.dat', 'wb') as PickleInst[Task]:
                pickle.dump(TimeLimitVar.get(), PickleInst[Task])  # Save
            with open(Str + '/NumOfDay.dat', 'wb') as PickleInst[Task]:
                pickle.dump(NumOfDayVar.get(), PickleInst[Task])  # Save
            with open(Str + '/NextTask.dat', 'wb') as PickleInst[Task]:
                pickle.dump(NextTaskVar.get(), PickleInst[Task])  # Save
            with open(Str + '/WaterCueType.dat', 'wb') as PickleInst[Task]:
                pickle.dump(WaterCueTypeVar.get(), PickleInst[Task])  # Save
            SaveTrg = 0

        if Phase == 1:  # Wait for starting of task
            if Phase1_Init == 0:
                PutPreTaskButton()
                mStatusVar = StringVar(MainWindowRoot)
                mStatus = ttk.Label(MainWindowRightFrame, textvariable=mStatusVar)
                mStatus.place(x=10, y=0)
                mOngoingResultVar = StringVar(MainWindowRoot)
                Phase1_Init = 1
                CurrDay = 0
            mStatusVar.set('Acclimation (' + str(Task) + ')    Waiting...')
            if IsStartTime() == 1:
                StartNow()
        if Phase == 2:  # During task
            if Phase2_Init == 0:  # Initialization of the task
                PutEndTaskNowButton()
                mStatusVar.set('Acclimation (' + str(Task) + ')    Start time ' + str(TaskStartedMonth) + '/' + str(TaskStartedDay) + ' ' + str(TaskStartedHour) + ':' + str(
                    TaskStartedMinute) + '    Running')
                mOngoingResult = ttk.Label(MainWindowRightFrame, textvariable=mOngoingResultVar)
                mOngoingResult.place(x=10, y=18)

                # Convert StringVars of parameters into integer or normal string to use in the following
                TimeLimit = int(TimeLimitVar.get())
                NumOfDay = int(NumOfDayVar.get())
                NextTask = int(NextTaskVar.get())
                WaterCueType = WaterCueTypeVar.get()

                StartLickRecording()
                RoofLightTurnOff()
                InfraredTurnOn()
                WaterCueTurnOn()
                WaterPosInside()
                if WaterCueType == 'Blink':
                    MakeWaterCueBlink()  # Make water cue blink

                # Declar local variables for this task
                DuringTask = 1
                StartRecording()  # Start camera capturing and sending of TTL

                TtlStart()
                Timer_Start(5)  # Task time limit timer start
                WaterPosInside()
                Writer_TouchEventTxt = open(
                    Path + "/" + str(TimeNow.year) + "_" + str(TimeNow.month) + "_" + str(TimeNow.day) + " " + str(TimeNow.hour) + "h" + str(TimeNow.minute) + "m Task" + str(Task) + " Touch.txt",
                    'w')  # Initialize the text exporter
                Writer_TouchEventCsv = open(
                    Path + "/" + str(TimeNow.year) + "_" + str(TimeNow.month) + "_" + str(TimeNow.day) + " " + str(TimeNow.hour) + "h" + str(TimeNow.minute) + "m Task" + str(Task) + " Touch.csv",
                    'w')  # Initialize the text exporter
                Phase2 = 0
                Phase2_Init = 1
                print("Task #" + str(Task) + " is started at " + str(GetTaskStartedMonth()) + '/' + str(GetTaskStartedDay()) + ' ' + str(GetTaskStartedHour()) + ':' + str(
                    GetTaskStartedMinute()) + ':' + str(GetTaskStartedSecond()))

            if Phase2 == 0:  # Initiation of new trial
                if GetTimerSec(5) >= TimeLimit * 60:  # If time limit is exceeded
                    Timer_End(5)
                    Phase2 = -1

            if Phase2 == -1 or Phase2 == -2:  # Task finish phase
                DuringTask = 0
                WaterPosMiddle()
                ClearPanel()
                MakeWaterCueNonBlink()
                InfraredTurnOff()
                if NowRecording == 1:
                    SetEndRecordingTimer(60)
                Writer_TouchEventTxt.write('TaskStartTime: ' + str(GetTaskStartedMonth()) + '/' + str(GetTaskStartedDay()) + ' ' + str(GetTaskStartedHour()) + ':' + str(GetTaskStartedMinute()) + ':' + str(GetTaskStartedSecond()) + "\n")
                Writer_TouchEventTxt.write('TaskEndTime: ' + str(TimeNow.month) + '/' + str(TimeNow.day) + ' ' + str(TimeNow.hour) + ':' + str(TimeNow.minute) + ':' + str(TimeNow.second + (TimeNow.microsecond // 1000) / 1000) + "\n")
                Writer_TouchEventTxt.write('CurrDay: ' + str(CurrDay) + "\n")
                Writer_TouchEventTxt.write('TimeLimit: ' + str(TimeLimit) + "\n")
                Writer_TouchEventTxt.write('NumOfDay: ' + str(NumOfDay) + "\n")
                Writer_TouchEventTxt.write('NextTask: ' + str(NextTask) + "\n")
                Writer_TouchEventTxt.write('WaterCueType: ' + str(WaterCueType) + "\n")
                Writer_TouchEventTxt.write('RecordFPS: ' + str(RecordFPS) + "\n")
                Writer_TouchEventTxt.close()
                Writer_TouchEventCsv.close()
                EndLickRecording()

                SendMail(DeviceNameVar.get() + ' finished task ' + str(Task) + '% Dur:' + str(round(GetTimerSec(5) / 60, 1)) + ' min', 'The task is finished.')
                TtlDelayStop()

                if IsHousingAnalysis == 1 and Phase2 == -1:  # If it is housing analysis
                    CurrDay += 1
                    if CurrDay >= NumOfDay:  # If the score exceed the criteria to switch the next task
                        SwitchTask(NextTask)  # Onset task switch trigger
                        print("Task is switched to task#" + str(NextTask) + "  " + str(GetTaskStartedMonth()) + '/' + str(GetTaskStartedDay()) + ' ' + str(GetTaskStartedHour()) + ':' + str(GetTaskStartedMinute()) + ':' + str(GetTaskStartedSecond()))

                if IsHousingAnalysis == 0:
                    RoofLightTurnOn()
                Phase = 1  # Go back to the task-waiting phase
                Phase2 = 0
                Phase2_Init = 0
    return

def Task2():   # Touch lit panel task
    global Phase, Phase2, Init, Task, SaveTrg, LoadTrg, NosePoking, DuringTask, NowRecording, RecordFPS
    Task = 2
    Phase0_Init=0
    Phase1_Init=0
    Phase2_Init=0
    while EndFlag==0:
        OperantHouseUpdate()
        if Phase == -1:  # Back to the task select phase
            Phase = 0
            Task = 0
            break
        if Phase == 0:  # Parameter inputs
            if Phase0_Init == 0:
                LoadTrg = 1
                # Make GUI for the setting of the parameters for this task
                RemoveMainRightWidget() # Remove task buttons
                PutStartBackButton()    # Put start/back buttons

                EntryWidth = 128  # Width of entry field
                GridX = 0  # Upper left X coordination of grids
                GridY = 0  # Upper left Y coordination of grids
                GridWidth = 128  # Width of grids
                GridHeight = 25  # Height of grids

                Row = 0  # Current row of grid
                Line = 0  # Current line of grid
                mMaxCorrectNum = ttk.Label(MainWindowRightFrame, text='MaxCorrectNum')    # Put label
                mMaxCorrectNum.place(x=GridX + Row * GridWidth, y=GridY + Line * GridHeight, width=EntryWidth)  # Put label
                MaxCorrectNumVar = IntVar(MainWindowRoot)  # Declare variable receiving value from the entry field
                iMaxCorrectNum = ttk.Entry(MainWindowRightFrame, textvariable=MaxCorrectNumVar) # Place entry field
                iMaxCorrectNum.place(x=GridX + Row * GridWidth, y=GridY + (Line + 1) * GridHeight - 3, width=EntryWidth)  # Place entry field
                Row += 1  # Shift row
                mMaxTrialNum = ttk.Label(MainWindowRightFrame, text='MaxTrialNum')
                mMaxTrialNum.place(x=GridX + Row * GridWidth, y=GridY + Line * GridHeight, width=EntryWidth)  # Put label
                MaxTrialNumVar = IntVar(MainWindowRoot)
                iMaxTrialNum = ttk.Entry(MainWindowRightFrame, textvariable=MaxTrialNumVar)
                iMaxTrialNum.place(x=GridX + Row * GridWidth, y=GridY + (Line + 1) * GridHeight - 3, width=EntryWidth)  # Place entry field
                Row += 1  # Shift row
                mTimeLimit = ttk.Label(MainWindowRightFrame, text='TimeLimit(min)')
                mTimeLimit.place(x=GridX + Row * GridWidth, y=GridY + Line * GridHeight, width=EntryWidth)  # Put label
                TimeLimitVar = IntVar(MainWindowRoot)
                iTimeLimit = ttk.Entry(MainWindowRightFrame, textvariable=TimeLimitVar)
                iTimeLimit.place(x=GridX + Row * GridWidth, y=GridY + (Line + 1) * GridHeight - 3, width=EntryWidth)  # Place entry field
                Row += 1  # Shift row
                mPunishDur = ttk.Label(MainWindowRightFrame, text='PunishDur(s)')
                mPunishDur.place(x=GridX + Row * GridWidth, y=GridY + Line * GridHeight, width=EntryWidth)  # Put label
                PunishDurVar = IntVar(MainWindowRoot)
                iPunishDur = ttk.Entry(MainWindowRightFrame, textvariable=PunishDurVar)
                iPunishDur.place(x=GridX + Row * GridWidth, y=GridY + (Line + 1) * GridHeight - 3, width=EntryWidth)  # Place entry field
                Row += 1  # Shift row
                mIti = ttk.Label(MainWindowRightFrame, text='ITI(s)')
                mIti.place(x=GridX + Row * GridWidth, y=GridY + Line * GridHeight, width=EntryWidth)  # Put label
                ItiVar = IntVar(MainWindowRoot)
                iIti = ttk.Entry(MainWindowRightFrame, textvariable=ItiVar)
                iIti.place(x=GridX + Row * GridWidth, y=GridY + (Line + 1) * GridHeight - 3, width=EntryWidth)  # Place entry field
                Row += 1  # Shift row
                mLickDur = ttk.Label(MainWindowRightFrame, text='LickDur(s)')
                mLickDur.place(x=GridX + Row * GridWidth, y=GridY + Line * GridHeight, width=EntryWidth)  # Put label
                LickDurVar = IntVar(MainWindowRoot)
                iLickDur = ttk.Entry(MainWindowRightFrame, textvariable=LickDurVar)
                iLickDur.place(x=GridX + Row * GridWidth, y=GridY + (Line + 1) * GridHeight - 3, width=EntryWidth)  # Place entry field
                Row += 1  # Shift row
                mAutoRewardLatency = ttk.Label(MainWindowRightFrame, text='AutoRewardLat(s)')
                mAutoRewardLatency.place(x=GridX + Row * GridWidth, y=GridY + Line * GridHeight, width=EntryWidth)  # Put label
                AutoRewardLatencyVar = IntVar(MainWindowRoot)
                iAutoRewardLatency = ttk.Entry(MainWindowRightFrame, textvariable=AutoRewardLatencyVar)
                iAutoRewardLatency.place(x=GridX + Row * GridWidth, y=GridY + (Line + 1) * GridHeight - 3, width=EntryWidth)  # Place entry field
                Row += 1  # Shift row
                mMaxAutoRewardNum = ttk.Label(MainWindowRightFrame, text='MaxAutoRewardNum')
                mMaxAutoRewardNum.place(x=GridX + Row * GridWidth, y=GridY + Line * GridHeight, width=EntryWidth)  # Put label
                MaxAutoRewardNumVar = IntVar(MainWindowRoot)
                iMaxAutoRewardNum = ttk.Entry(MainWindowRightFrame, textvariable=MaxAutoRewardNumVar)
                iMaxAutoRewardNum.place(x=GridX + Row * GridWidth, y=GridY + (Line + 1) * GridHeight - 3, width=EntryWidth)  # Place entry field

                Row = 0  # Shift row
                Line += 2  # Shift line
                mNextTaskTh = ttk.Label(MainWindowRightFrame, text='NextTaskTh(%)')
                mNextTaskTh.place(x=GridX + Row * GridWidth, y=GridY + Line * GridHeight, width=EntryWidth)  # Put label
                NextTaskThVar = IntVar(MainWindowRoot)
                iNextTaskTh = ttk.Entry(MainWindowRightFrame, textvariable=NextTaskThVar)
                iNextTaskTh.place(x=GridX + Row * GridWidth, y=GridY + (Line + 1) * GridHeight - 3, width=EntryWidth)  # Place entry field
                Row += 1  # Shift row
                mNextTask = ttk.Label(MainWindowRightFrame, text='NextTask#')
                mNextTask.place(x=GridX + Row * GridWidth, y=GridY + Line * GridHeight, width=EntryWidth)  # Put label
                NextTaskVar = IntVar(MainWindowRoot)
                iNextTask = ttk.Entry(MainWindowRightFrame, textvariable=NextTaskVar)
                iNextTask.place(x=GridX + Row * GridWidth, y=GridY + (Line + 1) * GridHeight - 3, width=EntryWidth)  # Place entry field
                Row += 1  # Shift row
                mPanelType = ttk.Label(MainWindowRightFrame, text='PanelType')
                mPanelType.place(x=GridX + Row * GridWidth, y=GridY + Line * GridHeight, width=EntryWidth)  # Put label
                PanelTypeVar = StringVar(MainWindowRightFrame)
                tPanelType = OptionMenu(MainWindowRightFrame, PanelTypeVar, "Normal", "Blink", "Textured")
                tPanelType.place(x=GridX + Row * GridWidth, y=GridY + (Line + 1) * GridHeight - 3, width=EntryWidth)  # Place entry field
                Row += 1  # Shift row
                mWaterCueType = ttk.Label(MainWindowRightFrame, text='WaterCueType')
                mWaterCueType.place(x=GridX + Row * GridWidth, y=GridY + Line * GridHeight, width=EntryWidth)  # Put label
                WaterCueTypeVar = StringVar(MainWindowRightFrame)
                tWaterCueType = OptionMenu(MainWindowRightFrame, WaterCueTypeVar, "Normal", "Blink")
                tWaterCueType.place(x=GridX + Row * GridWidth, y=GridY + (Line + 1) * GridHeight - 3, width=EntryWidth)  # Place entry field
                Row += 1  # Shift row
                mPunishWithLight = ttk.Label(MainWindowRightFrame, text='PunishWithLight')
                mPunishWithLight.place(x=GridX + Row * GridWidth, y=GridY + Line * GridHeight, width=EntryWidth)  # Put label
                PunishWithLightVar = StringVar(MainWindowRightFrame)
                tPunishWithLight = OptionMenu(MainWindowRightFrame, PunishWithLightVar, "ON", "OFF")
                tPunishWithLight.place(x=GridX + Row * GridWidth, y=GridY + (Line + 1) * GridHeight - 3, width=EntryWidth)  # Place entry field
                Row += 1  # Shift row
                mInverse = ttk.Label(MainWindowRightFrame, text='Inverse')
                mInverse.place(x=GridX + Row * GridWidth, y=GridY + Line * GridHeight, width=EntryWidth)  # Put label
                InverseVar = StringVar(MainWindowRoot)
                tInverse = OptionMenu(MainWindowRightFrame, InverseVar, "Normal", "Inverse")
                tInverse.place(x=GridX + Row * GridWidth, y=GridY + (Line + 1) * GridHeight - 3, width=EntryWidth)  # Place entry field
                Row += 1  # Shift row
                mAwsOn = ttk.Label(MainWindowRightFrame, text='AWS')
                mAwsOn.place(x=GridX + Row * GridWidth, y=GridY + Line * GridHeight, width=EntryWidth)  # Put label
                AwsOnVar = StringVar(MainWindowRightFrame)
                tAwsOn = OptionMenu(MainWindowRightFrame, AwsOnVar, "ON", "OFF")
                tAwsOn.place(x=GridX + Row * GridWidth, y=GridY + (Line + 1) * GridHeight - 3, width=EntryWidth)  # Place entry field

                Phase0_Init = 1

        if LoadTrg == 1:  # If load trigger is on

            Str = "ParametersForTask" + str(Task)
            if os.path.exists(Str+'/MaxCorrectNum.dat') == True:  # If save file exists
                with open(Str+'/MaxCorrectNum.dat', 'rb') as PickleInst[Task]:
                    MaxCorrectNumVar.set(pickle.load(PickleInst[Task]))  # Load
            else:
                MaxCorrectNumVar.set(80)     # Default value

            if os.path.exists(Str+'/MaxTrialNum.dat') == True:  # If save file exists
                with open(Str+'/MaxTrialNum.dat', 'rb') as PickleInst[Task]:
                    MaxTrialNumVar.set(pickle.load(PickleInst[Task]))  # Load
            else:
                MaxTrialNumVar.set(110)     # Default value

            if os.path.exists(Str+'/TimeLimit.dat') == True:  # If save file exists
                with open(Str+'/TimeLimit.dat', 'rb') as PickleInst[Task]:
                    TimeLimitVar.set(pickle.load(PickleInst[Task]))  # Load
            else:
                TimeLimitVar.set(360)     # Default value

            if os.path.exists(Str+'/PunishDur.dat') == True:  # If save file exists
                with open(Str+'/PunishDur.dat', 'rb') as PickleInst[Task]:
                    PunishDurVar.set(pickle.load(PickleInst[Task]))  # Load
            else:
                PunishDurVar.set(10)     # Default value

            if os.path.exists(Str+'/Iti.dat') == True:  # If save file exists
                with open(Str+'/Iti.dat', 'rb') as PickleInst[Task]:
                    ItiVar.set(pickle.load(PickleInst[Task]))  # Load
            else:
                ItiVar.set(1)     # Default value
            if os.path.exists(Str+'/LickDur.dat') == True:  # If save file exists
                with open(Str+'/LickDur.dat', 'rb') as PickleInst[Task]:
                    LickDurVar.set(pickle.load(PickleInst[Task]))  # Load
            else:
                LickDurVar.set(2)     # Default value

            if os.path.exists(Str+'/AutoRewardLatency.dat') == True:  # If save file exists
                with open(Str+'/AutoRewardLatency.dat', 'rb') as PickleInst[Task]:
                    AutoRewardLatencyVar.set(pickle.load(PickleInst[Task]))  # Load
            else:
                AutoRewardLatencyVar.set(360)     # Default value

            if os.path.exists(Str+'/MaxAutoRewardNum.dat') == True:  # If save file exists
                with open(Str+'/MaxAutoRewardNum.dat', 'rb') as PickleInst[Task]:
                    MaxAutoRewardNumVar.set(pickle.load(PickleInst[Task]))  # Load
            else:
                MaxAutoRewardNumVar.set(5)     # Default value


            if os.path.exists(Str+'/NextTaskTh.dat') == True:  # If save file exists
                with open(Str+'/NextTaskTh.dat', 'rb') as PickleInst[Task]:
                    NextTaskThVar.set(pickle.load(PickleInst[Task]))  # Load
            else:
                NextTaskThVar.set(50)     # Default value
            if os.path.exists(Str+'/NextTask.dat') == True:  # If save file exists
                with open(Str+'/NextTask.dat', 'rb') as PickleInst[Task]:
                    NextTaskVar.set(pickle.load(PickleInst[Task]))  # Load
            else:
                NextTaskVar.set(17)     # Default value

            if os.path.exists(Str+'/PanelType.dat') == True:  # If save file exists
                with open(Str+'/PanelType.dat', 'rb') as PickleInst[Task]:
                    PanelTypeVar.set(pickle.load(PickleInst[Task]))  # Load
            else:
                PanelTypeVar.set('Normal')     # Default value

            if os.path.exists(Str+'/WaterCueType.dat') == True:  # If save file exists
                with open(Str+'/WaterCueType.dat', 'rb') as PickleInst[Task]:
                    WaterCueTypeVar.set(pickle.load(PickleInst[Task]))  # Load
            else:
                WaterCueTypeVar.set('Blink')     # Default value

            if os.path.exists(Str+'/PunishWithLight.dat') == True:  # If save file exists
                with open(Str+'/PunishWithLight.dat', 'rb') as PickleInst[Task]:
                    PunishWithLightVar.set(pickle.load(PickleInst[Task]))  # Load
            else:
                PunishWithLightVar.set('ON')     # Default value
            if os.path.exists(Str+'/Inverse.dat') == True:  # If save file exists
                with open(Str+'/Inverse.dat', 'rb') as PickleInst[Task]:
                    InverseVar.set(pickle.load(PickleInst[Task]))  # Load
            else:
                InverseVar.set('Normal')     # Default value
            if os.path.exists(Str+'/AwsOn.dat') == True:  # If save file exists
                with open(Str+'/AwsOn.dat', 'rb') as PickleInst[Task]:
                    AwsOnVar.set(pickle.load(PickleInst[Task]))  # Load
            else:
                AwsOnVar.set('OFF')     # Default value
            LoadTrg = 0

        if SaveTrg == 1:    # If save trigger is on
            # Parameters of each task are saved into different folder
            Str="ParametersForTask"+str(Task)   # Path to the folder for saving of parameters
            if os.path.exists(Str) == False:    # If folder for saving parameters is not exist
                os.mkdir(Str)   # Make folder for saving
            with open(Str+'/MaxCorrectNum.dat', 'wb') as PickleInst[Task]:
                pickle.dump(MaxCorrectNumVar.get(),PickleInst[Task])     # Save
            with open(Str+'/MaxTrialNum.dat', 'wb') as PickleInst[Task]:
                pickle.dump(MaxTrialNumVar.get(),PickleInst[Task])     # Save
            with open(Str + '/TimeLimit.dat', 'wb') as PickleInst[Task]:
                pickle.dump(TimeLimitVar.get(), PickleInst[Task])  # Save
            with open(Str+'/PunishDur.dat', 'wb') as PickleInst[Task]:
                pickle.dump(PunishDurVar.get(), PickleInst[Task])     # Save
            with open(Str+'/Iti.dat', 'wb') as PickleInst[Task]:
                pickle.dump(ItiVar.get(), PickleInst[Task])     # Save
            with open(Str+'/LickDur.dat', 'wb') as PickleInst[Task]:
                pickle.dump(LickDurVar.get(), PickleInst[Task])     # Save

            with open(Str+'/AutoRewardLatency.dat', 'wb') as PickleInst[Task]:
                pickle.dump(AutoRewardLatencyVar.get(), PickleInst[Task])     # Save
            with open(Str+'/MaxAutoRewardNum.dat', 'wb') as PickleInst[Task]:
                pickle.dump(MaxAutoRewardNumVar.get(), PickleInst[Task])     # Save

            with open(Str + '/NextTask.dat', 'wb') as PickleInst[Task]:
                pickle.dump(NextTaskVar.get(), PickleInst[Task])  # Save
            with open(Str+'/NextTaskTh.dat', 'wb') as PickleInst[Task]:
                pickle.dump(NextTaskThVar.get(), PickleInst[Task])     # Save
            with open(Str+'/PanelType.dat', 'wb') as PickleInst[Task]:
                pickle.dump(PanelTypeVar.get(), PickleInst[Task])     # Save
            with open(Str+'/WaterCueType.dat', 'wb') as PickleInst[Task]:
                pickle.dump(WaterCueTypeVar.get(), PickleInst[Task])     # Save
            with open(Str+'/PunishWithLight.dat', 'wb') as PickleInst[Task]:
                pickle.dump(PunishWithLightVar.get(), PickleInst[Task])     # Save
            with open(Str+'/Inverse.dat', 'wb') as PickleInst[Task]:
                pickle.dump(InverseVar.get(), PickleInst[Task])     # Save
            with open(Str+'/AwsOn.dat', 'wb') as PickleInst[Task]:
                pickle.dump(AwsOnVar.get(), PickleInst[Task])     # Save
            SaveTrg = 0

        if Phase == 1:  # Wait for starting of task
            if Phase1_Init == 0:
                PutPreTaskButton()
                mStatusVar = StringVar(MainWindowRoot)
                mStatus = ttk.Label(MainWindowRightFrame, textvariable=mStatusVar)
                mStatus.place(x=10, y=0)
                mOngoingResultVar = StringVar(MainWindowRoot)
                Phase1_Init = 1
            mStatusVar.set('Touch lit panel task (' + str(Task) + ')    Waiting...')
            if IsStartTime() == 1:
                StartNow()
        if Phase == 2:  # During task
            if Phase2_Init == 0: # Initialization of the task
                PutEndTaskNowButton()
                mStatusVar.set('Touch lit panel task (' + str(Task) + ')    Start time ' + str(TaskStartedMonth) + '/' + str(TaskStartedDay) + ' ' + str(TaskStartedHour) + ':' + str(TaskStartedMinute) + '    Running')
                mOngoingResult = ttk.Label(MainWindowRightFrame, textvariable=mOngoingResultVar)
                mOngoingResult.place(x=10, y=18)

                # Convert StringVars of parameters into integer or normal string to use in the following
                MaxCorrectNum=int(MaxCorrectNumVar.get())
                MaxTrialNum = int(MaxTrialNumVar.get())
                TimeLimit = int(TimeLimitVar.get())
                PunishDur = int(PunishDurVar.get())
                Iti = int(ItiVar.get())
                LickDur = int(LickDurVar.get())
                AutoRewardLatency = int(AutoRewardLatencyVar.get())
                MaxAutoRewardNum = int(MaxAutoRewardNumVar.get())
                NextTask = int(NextTaskVar.get())
                NextTaskTh = int(NextTaskThVar.get())
                PanelType = PanelTypeVar.get()
                WaterCueType =WaterCueTypeVar.get()
                PunishWithLight = PunishWithLightVar.get()
                Inverse = InverseVar.get()
                AwsOn = AwsOnVar.get()

                StartLickRecording()
                RoofLightTurnOff()
                InfraredTurnOn()
                WaterCueTurnOn()
                WaterPosInside()
                if PanelType=='Normal':
                    CreateNormalPanel_All() #
                if PanelType=='Blink':
                    CreateBlinkPanel_All()
                if PanelType=='Textured':
                    CreateTexturedPanel_All()
                if WaterCueType == 'Blink':
                    MakeWaterCueBlink() # Make water cue blink

                # Declar local variables for this task
                TotalTouchNum = 0
                CorrectNum = 0
                IncorrectNum = 0
                CorrectRate = 0
                AutoRewardNum = 0
                RewardNum = 0 # Total number of reward

                AWS_Latency = 20
                DuringTask = 1
                NowDrinking = 0
                CorrectPanelID = 0    # ID of correct panel
                TotalPanelNum = 0     # Total number of panels in this task
                StartRecording()    # Start camera capturing and sending of TTL

                TrialNum=0
                TtlStart()
                Timer_Start(5)  # Task time limit timer start
                Phase2 = 2
                Phase2_Init = 1

                for i in range(0, MaxPanelNum): # Count total panel num in this task
                    if PanelULX[Task][i]==0:
                        TotalPanelNum=i+1
                        break

                Writer_TouchEventTxt = open(Path + "/" + str(TimeNow.year) + "_" + str(TimeNow.month) + "_" + str(TimeNow.day) + " " + str(TimeNow.hour) + "h" + str(TimeNow.minute) + "m Task" + str(Task) + " Touch.txt",'w')  # Initialize the text exporter
                Writer_TouchEventCsv = open(Path + "/" + str(TimeNow.year) + "_" + str(TimeNow.month) + "_" + str(TimeNow.day) + " " + str(TimeNow.hour) + "h" + str(TimeNow.minute) + "m Task" + str(Task) + " Touch.csv",'w')  # Initialize the text exporter
                Writer_TouchEventTxt.write('TrialNum\tResult\t\t\tyyyy/mm/dd\th:m\ts\n')  # Write item name
                print("Task #" + str(Task) + " is started at " + str(GetTaskStartedMonth()) + '/' + str(GetTaskStartedDay()) + ' ' + str(GetTaskStartedHour()) + ':' + str(GetTaskStartedMinute()) + ':' + str(GetTaskStartedSecond()))

            if Phase2 == 0:   # Initiation of new trial
                TrialNum += 1   #

                CorrectPanelID=int(random.random()*(TotalPanelNum-1))
                print('CorrectPanelID'+str(CorrectPanelID))
                ShowPanel(CorrectPanelID)
                #ShowPanel(0)
                Timer_Start(0)  # Start the latency timer
                Timer_Start(1)  # Start timer for auto reward
                Phase2 += 1
            if Phase2 == 1:   # Panel presentation
                TouchedPanelID = DetectPanelTouch() # Examine which panel is touched (return panel ID. If none of the panels touched, return -1)
                if TouchedPanelID != -1:    # If any panel is touched
                    if TouchedPanelID == int(CorrectPanelID): # If mouse touchs correct panel
                        WaterPosInside()  # Move water nozzle to the inside position
                        NowDrinking = 0
                        CorrectNum += 1  # Increase the number of correct respon
                        TotalTouchNum+=1
                        mOngoingResultVar.set('CorrectNum:'+str(CorrectNum)+'  IncorrectNum:'+str(IncorrectNum)+'  TotalNum:'+str(TotalTouchNum)+'  Correct:'+str(round(CorrectNum*100.0/TotalTouchNum, 2))+'%  AutoRewardNum:'+str(AutoRewardNum))
                        Writer_TouchEventTxt.write(str(TrialNum) + '\tPanelTouched(Correct)\t' +str(TouchedPanelID)+'\t'+ str(TimeNow.year) + "/" + str(TimeNow.month) + "/" + str(TimeNow.day) + "\t" + str(TimeNow.hour) + ":" + str(TimeNow.minute) + "\t" + str(TimeNow.second) + "." + str(TimeNow.microsecond//1000) + "\n")  # Write the response on the text file
                        Writer_TouchEventCsv.write(str(TrialNum) + ',1,' +str(TouchedPanelID)+','+ str(TimeNow.year) + "," + str(TimeNow.month) + "," + str(TimeNow.day) + "," + str(TimeNow.hour) + "," + str(TimeNow.minute) + "," + str(TimeNow.second) + "." + str(TimeNow.microsecond//1000) + "\n")  # Write the response on the csv file
                        HideAllPanel()
                        Timer_End(0)
                        WaterCueTurnOn()
                        Phase2 = 2  # Start reward phase
                    if TouchedPanelID != int(CorrectPanelID): # If mouse touchs wrong panel
                        WaterPosOutside()
                        if PunishWithLight == 'ON':
                            RoofLightTurnOn()  # Turn on roof light
                        IncorrectNum += 1
                        TotalTouchNum += 1
                        mOngoingResultVar.set('CorrectNum:' + str(CorrectNum) + '  IncorrectNum:' + str(IncorrectNum) + '  TotalNum:' + str(TotalTouchNum) + '  Correct:' + str(round(CorrectNum * 100.0 / TotalTouchNum, 2))+'%  AutoRewardNum:'+str(AutoRewardNum))
                        Writer_TouchEventTxt.write(str(TrialNum) + '\tPanelTouched(Wrong)\t' +str(TouchedPanelID)+'\t'+ str(TimeNow.year) + "/" + str(TimeNow.month) + "/" + str(TimeNow.day) + "\t" + str(TimeNow.hour) + ":" + str(TimeNow.minute) + "\t" + str(TimeNow.second) + "." + str(TimeNow.microsecond//1000) + "\n")  # Write the response on the text file
                        Writer_TouchEventCsv.write(str(TrialNum) + ',0,' +str(TouchedPanelID)+','+ str(TimeNow.year) + "," + str(TimeNow.month) + "," + str(TimeNow.day) + "," + str(TimeNow.hour) + "," + str(TimeNow.minute) + "," + str(TimeNow.second) + "." + str(TimeNow.microsecond//1000) + "\n")  # Write the response on the csv file
                        HideAllPanel()
                        Timer_End(0)  # End timer1
                        Timer_Start(0)  # Start punish timer
                        Phase2 = 5  # Start punishment phase
                if AutoRewardNum < MaxAutoRewardNum:
                    if GetTimerSec(1) >= AutoRewardLatency:   # If time limit is auto reward latency
                        Timer_End(1)
                        WaterPosInside()  # Move water nozzle to the inside position
                        WaterCueTurnOn()
                        NowDrinking = 0
                        AutoRewardNum += 1  # Increase the number of auto reward num
                        if TotalTouchNum > 0:
                            mOngoingResultVar.set('CorrectNum:' + str(CorrectNum) + '  IncorrectNum:' + str(IncorrectNum) + '  TotalNum:' + str(TotalTouchNum) + '  Correct:' + str(round(CorrectNum * 100.0 / TotalTouchNum, 2)) + '%  AutoRewardNum:'+str(AutoRewardNum))
                        Writer_TouchEventTxt.write(str(TrialNum) + '\tAutoRewardSupply\t\t' + str(TimeNow.year) + "/" + str(TimeNow.month) + "/" + str(TimeNow.day) + "\t" + str(TimeNow.hour) + ":" + str(TimeNow.minute) + "\t" + str(TimeNow.second) + "." + str(TimeNow.microsecond // 1000) + "\n")  # Write the response on the text file
                        Writer_TouchEventCsv.write(str(TrialNum) + ',2,,' + str(TimeNow.year) + "," + str(TimeNow.month) + "," + str(TimeNow.day) + "," + str(TimeNow.hour) + "," + str(TimeNow.minute) + "," + str(TimeNow.second) + "." + str(TimeNow.microsecond // 1000) + "\n")  # Write the response on the csv file
                        HideAllPanel()
                        Phase2 = 2
                if GetTimerSec(5) >= TimeLimit * 60:   # If time limit is exceeded
                    Timer_End(5)
                    Phase2 = 6
            if Phase2 == 2:  # Reward phase
                if NosePoking == 1 and NowDrinking == 0:    # If the mouse initiates nose poke
                    NowDrinking = 1
                    Timer_Start(0)  # Start lick timer
                if NowDrinking == 1:
                    if GetTimerSec(0) >= LickDur:   # If lick time exceed the designated time
                        Timer_End(0) # End lick timer
                        WaterPosMiddle()    # Move water nozzle to the intermediate position
                        WaterCueTurnOff()
                        NowDrinking = 0
                        Timer_Start(0)  # Start ITI timer
                        Phase2 = 3

            if Phase2 == 3:   # ITI
                RewardNum = CorrectNum + AutoRewardNum
                if GetTimerSec(0) >= Iti:  # If ITI is passed
                    Timer_End(0)
                    Phase2 = 0  # Go to the next trial
                if RewardNum >= MaxCorrectNum or TotalTouchNum >= MaxTrialNum: # If mouse achieved criteria of finishing the task
                    Timer_End(5)
                    WaterPosMiddle()
                    WaterCueTurnOff()
                    Timer_Start(0)  # Timer for interval between task and arbitary water supply is started
                    Phase2 = 6  # Go to the AWS
            if Phase2 == 5:   # Punishment phase
                if GetTimerSec(0) >= PunishDur:    # If punishment time is passed
                    RoofLightTurnOff()
                    WaterPosMiddle()    # Move water nozzle to the intermediate position
                    Timer_End(0)  # End punishment timer1
                    Timer_Start(0)  # Start ITI timer
                    Phase2 = 3
            if Phase2==6:
                HideAllPanel()
                if CorrectNum < MaxCorrectNum and AwsOn=='ON':  # If mouse didn't achieved the max correct response
                    Timer_Start(0)
                    Phase2 = 7
                if CorrectNum == MaxCorrectNum or AwsOn=='OFF':  # If mouse achieved the max correct response
                    Phase2 = -1
            if Phase2==7:   # Wait until arbitary water suuply is started
                if GetTimerSec(0) >= AWS_Latency:   # If the interval is past 60
                    Timer_End(0)
                    ArbitaryWaterSupplyDur=(MaxCorrectNum - CorrectNum) * LickDur * 1000    # Caliculate duration of complement water supply
                    StartArbitaryWaterSupply(ArbitaryWaterSupplyDur) # Start complement water supply
                    print("AWSstart")
                    Phase2=8
            if Phase2==8:
                if GetArbitaryWaterSupplyStat()==1: # If complement water supply is finished
                    Phase2 = -1

            if Phase2 == -1 or Phase2 == -2:  # Task finish phase
                DuringTask = 0
                WaterPosMiddle()
                ClearPanel()
                MakeWaterCueNonBlink()
                InfraredTurnOff()
                if NowRecording == 1:
                    SetEndRecordingTimer(60)
                if CorrectNum > 0 or IncorrectNum > 0:
                    CorrectRate = int(CorrectNum * 100.0 / TotalTouchNum)
                    Writer_TouchEventTxt.write('TotalNum:'+str(TotalTouchNum)+'  Correct num:'+str(CorrectNum)+'  Incorrect num:'+str(IncorrectNum)+'  Correct rate:'+str(CorrectRate)+'%  Auto reward num:'+str(AutoRewardNum)+'\n')	#結果テキストの一番最後に成績のまとめを記入
                Writer_TouchEventTxt.write('TaskStartTime: ' + str(GetTaskStartedMonth()) + '/' + str(GetTaskStartedDay()) + ' ' + str(GetTaskStartedHour()) + ':' + str(GetTaskStartedMinute()) + ':' + str(
                    GetTaskStartedSecond()) + "\n")
                Writer_TouchEventTxt.write('TaskEndTime: ' + str(TimeNow.month) + '/' + str(TimeNow.day) + ' ' + str(TimeNow.hour) + ':' + str(TimeNow.minute) + ':' + str(
                    TimeNow.second + (TimeNow.microsecond // 1000) / 1000) + "\n")
                Writer_TouchEventTxt.write('MaxCorrectNum: '+str(MaxCorrectNum)+"\n")
                Writer_TouchEventTxt.write('MaxTrialNum: ' + str(MaxTrialNum) + "\n")
                Writer_TouchEventTxt.write('TimeLimit: ' + str(TimeLimit) + "\n")
                Writer_TouchEventTxt.write('PunishDur: ' + str(PunishDur) + "\n")
                Writer_TouchEventTxt.write('Iti: ' + str(Iti) + "\n")
                Writer_TouchEventTxt.write('LickDur: ' + str(LickDur) + "\n")
                Writer_TouchEventTxt.write('AutoRewardLatency: ' + str(AutoRewardLatency) + "\n")
                Writer_TouchEventTxt.write('MaxAutoRewardNum: ' + str(AutoRewardNum) + "\n")
                Writer_TouchEventTxt.write('NextTask: ' + str(NextTask) + "\n")
                Writer_TouchEventTxt.write('NextTaskTh: ' + str(NextTaskTh)+"\n")
                Writer_TouchEventTxt.write('PanelType: ' + str(PanelType) + "\n")
                Writer_TouchEventTxt.write('WaterCueType: ' + str(WaterCueType) + "\n")
                Writer_TouchEventTxt.write('PunishWithLight: ' + str(PunishWithLight)+"\n")
                Writer_TouchEventTxt.write('Inverse: ' + str(Inverse) + "\n")
                Writer_TouchEventTxt.write('RecordFPS: ' + str(RecordFPS) + "\n")
                Writer_TouchEventTxt.write('AWS: ' + AwsOn + "\n")
                Writer_TouchEventTxt.write('AWS_Latency: ' + str(AWS_Latency) + "\n")
                Writer_TouchEventTxt.close()
                Writer_TouchEventCsv.close()
                EndLickRecording()

                SendMail(DeviceNameVar.get() + ' finished task '+str(Task)+'. Correct:' + str(CorrectNum) + ' Incorrect:' + str(IncorrectNum) + ' Correct:'+str(CorrectRate)+'% Dur:' + str(round(GetTimerSec(5) / 60,1)) + ' min', 'The task is finished.')
                TtlDelayStop()

                if IsHousingAnalysis == 1 and Phase2 == -1:  # If it is housing analysis
                    if CorrectRate >= NextTaskTh:   # If the score exceed the criteria to switch the next task
                        SwitchTask(NextTask) # Onset task switch trigger
                        print("Task is switched to task#"+str(NextTask)+"  "+str(GetTaskStartedMonth()) + '/' + str(GetTaskStartedDay()) + ' ' + str(GetTaskStartedHour()) + ':' + str(GetTaskStartedMinute()) + ':' + str(GetTaskStartedSecond()))

                if IsHousingAnalysis == 0:
                    RoofLightTurnOn()
                Phase = 1  # Go back to the task-waiting phase
                Phase2 = 0
                Phase2_Init = 0
    return

def Task4():
    global Phase, Phase2, Init, Task, SaveTrg, LoadTrg, NosePoking, DuringTask, NowRecording, RecordFPS
    Task = 4
    Phase0_Init = 0
    Phase1_Init = 0
    Phase2_Init = 0
    while EndFlag == 0:
        OperantHouseUpdate()
        if Phase == -1:  # Back to the task select phase
            Phase = 0
            Task = 0
            break
        if Phase == 0:  # Parameter inputs
            if Phase0_Init == 0:
                LoadTrg = 1
                # Make GUI for the setting of the parameters for this task
                RemoveMainRightWidget()  # Remove task buttons
                PutStartBackButton()  # Put start/back buttons

                EntryWidth = 128  # Width of entry field
                GridX = 0  # Upper left X coordination of grids
                GridY = 0  # Upper left Y coordination of grids
                GridWidth = 128  # Width of grids
                GridHeight = 25  # Height of grids

                Row = 0  # Current row of grid
                Line = 0  # Current line of grid
                mMaxCorrectNum = ttk.Label(MainWindowRightFrame, text='MaxCorrectNum')  # Put label
                mMaxCorrectNum.place(x=GridX + Row * GridWidth, y=GridY + Line * GridHeight, width=EntryWidth)  # Put label
                MaxCorrectNumVar = IntVar(MainWindowRoot)  # Declare variable receiving value from the entry field
                iMaxCorrectNum = ttk.Entry(MainWindowRightFrame, textvariable=MaxCorrectNumVar)  # Place entry field
                iMaxCorrectNum.place(x=GridX + Row * GridWidth, y=GridY + (Line + 1) * GridHeight - 3, width=EntryWidth)  # Place entry field
                Row += 1  # Shift row
                mMaxTrialNum = ttk.Label(MainWindowRightFrame, text='MaxTrialNum')
                mMaxTrialNum.place(x=GridX + Row * GridWidth, y=GridY + Line * GridHeight, width=EntryWidth)  # Put label
                MaxTrialNumVar = IntVar(MainWindowRoot)
                iMaxTrialNum = ttk.Entry(MainWindowRightFrame, textvariable=MaxTrialNumVar)
                iMaxTrialNum.place(x=GridX + Row * GridWidth, y=GridY + (Line + 1) * GridHeight - 3, width=EntryWidth)  # Place entry field
                Row += 1  # Shift row
                mTimeLimit = ttk.Label(MainWindowRightFrame, text='TimeLimit(min)')
                mTimeLimit.place(x=GridX + Row * GridWidth, y=GridY + Line * GridHeight, width=EntryWidth)  # Put label
                TimeLimitVar = IntVar(MainWindowRoot)
                iTimeLimit = ttk.Entry(MainWindowRightFrame, textvariable=TimeLimitVar)
                iTimeLimit.place(x=GridX + Row * GridWidth, y=GridY + (Line + 1) * GridHeight - 3, width=EntryWidth)  # Place entry field
                Row += 1  # Shift row
                mPunishDur = ttk.Label(MainWindowRightFrame, text='PunishDur(s)')
                mPunishDur.place(x=GridX + Row * GridWidth, y=GridY + Line * GridHeight, width=EntryWidth)  # Put label
                PunishDurVar = IntVar(MainWindowRoot)
                iPunishDur = ttk.Entry(MainWindowRightFrame, textvariable=PunishDurVar)
                iPunishDur.place(x=GridX + Row * GridWidth, y=GridY + (Line + 1) * GridHeight - 3, width=EntryWidth)  # Place entry field
                Row += 1  # Shift row
                mIti = ttk.Label(MainWindowRightFrame, text='ITI(s)')
                mIti.place(x=GridX + Row * GridWidth, y=GridY + Line * GridHeight, width=EntryWidth)  # Put label
                ItiVar = IntVar(MainWindowRoot)
                iIti = ttk.Entry(MainWindowRightFrame, textvariable=ItiVar)
                iIti.place(x=GridX + Row * GridWidth, y=GridY + (Line + 1) * GridHeight - 3, width=EntryWidth)  # Place entry field
                Row += 1  # Shift row
                mLickDur = ttk.Label(MainWindowRightFrame, text='LickDur(s)')
                mLickDur.place(x=GridX + Row * GridWidth, y=GridY + Line * GridHeight, width=EntryWidth)  # Put label
                LickDurVar = IntVar(MainWindowRoot)
                iLickDur = ttk.Entry(MainWindowRightFrame, textvariable=LickDurVar)
                iLickDur.place(x=GridX + Row * GridWidth, y=GridY + (Line + 1) * GridHeight - 3, width=EntryWidth)  # Place entry field
                Row += 1  # Shift row
                mAutoRewardLatency = ttk.Label(MainWindowRightFrame, text='AutoRewardLat(s)')
                mAutoRewardLatency.place(x=GridX + Row * GridWidth, y=GridY + Line * GridHeight, width=EntryWidth)  # Put label
                AutoRewardLatencyVar = IntVar(MainWindowRoot)
                iAutoRewardLatency = ttk.Entry(MainWindowRightFrame, textvariable=AutoRewardLatencyVar)
                iAutoRewardLatency.place(x=GridX + Row * GridWidth, y=GridY + (Line + 1) * GridHeight - 3, width=EntryWidth)  # Place entry field
                Row += 1  # Shift row
                mMaxAutoRewardNum = ttk.Label(MainWindowRightFrame, text='MaxAutoRewardNum')
                mMaxAutoRewardNum.place(x=GridX + Row * GridWidth, y=GridY + Line * GridHeight, width=EntryWidth)  # Put label
                MaxAutoRewardNumVar = IntVar(MainWindowRoot)
                iMaxAutoRewardNum = ttk.Entry(MainWindowRightFrame, textvariable=MaxAutoRewardNumVar)
                iMaxAutoRewardNum.place(x=GridX + Row * GridWidth, y=GridY + (Line + 1) * GridHeight - 3, width=EntryWidth)  # Place entry field

                Row = 0  # Shift row
                Line += 2  # Shift line
                mNextTaskTh = ttk.Label(MainWindowRightFrame, text='NextTaskTh(%)')
                mNextTaskTh.place(x=GridX + Row * GridWidth, y=GridY + Line * GridHeight, width=EntryWidth)  # Put label
                NextTaskThVar = IntVar(MainWindowRoot)
                iNextTaskTh = ttk.Entry(MainWindowRightFrame, textvariable=NextTaskThVar)
                iNextTaskTh.place(x=GridX + Row * GridWidth, y=GridY + (Line + 1) * GridHeight - 3, width=EntryWidth)  # Place entry field
                Row += 1  # Shift row
                mNextTask = ttk.Label(MainWindowRightFrame, text='NextTask#')
                mNextTask.place(x=GridX + Row * GridWidth, y=GridY + Line * GridHeight, width=EntryWidth)  # Put label
                NextTaskVar = IntVar(MainWindowRoot)
                iNextTask = ttk.Entry(MainWindowRightFrame, textvariable=NextTaskVar)
                iNextTask.place(x=GridX + Row * GridWidth, y=GridY + (Line + 1) * GridHeight - 3, width=EntryWidth)  # Place entry field
                Row += 1  # Shift row
                mPanelType = ttk.Label(MainWindowRightFrame, text='PanelType')
                mPanelType.place(x=GridX + Row * GridWidth, y=GridY + Line * GridHeight, width=EntryWidth)  # Put label
                PanelTypeVar = StringVar(MainWindowRightFrame)
                tPanelType = OptionMenu(MainWindowRightFrame, PanelTypeVar, "Normal", "Blink", "Textured")
                tPanelType.place(x=GridX + Row * GridWidth, y=GridY + (Line + 1) * GridHeight - 3, width=EntryWidth)  # Place entry field
                Row += 1  # Shift row
                mWaterCueType = ttk.Label(MainWindowRightFrame, text='WaterCueType')
                mWaterCueType.place(x=GridX + Row * GridWidth, y=GridY + Line * GridHeight, width=EntryWidth)  # Put label
                WaterCueTypeVar = StringVar(MainWindowRightFrame)
                tWaterCueType = OptionMenu(MainWindowRightFrame, WaterCueTypeVar, "Normal", "Blink")
                tWaterCueType.place(x=GridX + Row * GridWidth, y=GridY + (Line + 1) * GridHeight - 3, width=EntryWidth)  # Place entry field
                Row += 1  # Shift row
                mPunishWithLight = ttk.Label(MainWindowRightFrame, text='PunishWithLight')
                mPunishWithLight.place(x=GridX + Row * GridWidth, y=GridY + Line * GridHeight, width=EntryWidth)  # Put label
                PunishWithLightVar = StringVar(MainWindowRightFrame)
                tPunishWithLight = OptionMenu(MainWindowRightFrame, PunishWithLightVar, "ON", "OFF")
                tPunishWithLight.place(x=GridX + Row * GridWidth, y=GridY + (Line + 1) * GridHeight - 3, width=EntryWidth)  # Place entry field
                Row += 1  # Shift row
                mInverse = ttk.Label(MainWindowRightFrame, text='Inverse')
                mInverse.place(x=GridX + Row * GridWidth, y=GridY + Line * GridHeight, width=EntryWidth)  # Put label
                InverseVar = StringVar(MainWindowRoot)
                tInverse = OptionMenu(MainWindowRightFrame, InverseVar, "Normal", "Inverse")
                tInverse.place(x=GridX + Row * GridWidth, y=GridY + (Line + 1) * GridHeight - 3, width=EntryWidth)  # Place entry field
                Row += 1  # Shift row
                mAwsOn = ttk.Label(MainWindowRightFrame, text='AWS')
                mAwsOn.place(x=GridX + Row * GridWidth, y=GridY + Line * GridHeight, width=EntryWidth)  # Put label
                AwsOnVar = StringVar(MainWindowRoot)
                tAwsOn = OptionMenu(MainWindowRightFrame, AwsOnVar, "ON", "OFF")
                tAwsOn.place(x=GridX + Row * GridWidth, y=GridY + (Line + 1) * GridHeight - 3, width=EntryWidth)  # Place entry field
                Phase0_Init = 1

        if LoadTrg == 1:  # If load trigger is on

            Str = "ParametersForTask" + str(Task)
            if os.path.exists(Str + '/MaxCorrectNum.dat') == True:  # If save file exists
                with open(Str + '/MaxCorrectNum.dat', 'rb') as PickleInst[Task]:
                    MaxCorrectNumVar.set(pickle.load(PickleInst[Task]))  # Load
            else:
                MaxCorrectNumVar.set(80)  # Default value

            if os.path.exists(Str + '/MaxTrialNum.dat') == True:  # If save file exists
                with open(Str + '/MaxTrialNum.dat', 'rb') as PickleInst[Task]:
                    MaxTrialNumVar.set(pickle.load(PickleInst[Task]))  # Load
            else:
                MaxTrialNumVar.set(110)  # Default value

            if os.path.exists(Str + '/TimeLimit.dat') == True:  # If save file exists
                with open(Str + '/TimeLimit.dat', 'rb') as PickleInst[Task]:
                    TimeLimitVar.set(pickle.load(PickleInst[Task]))  # Load
            else:
                TimeLimitVar.set(360)  # Default value

            if os.path.exists(Str + '/PunishDur.dat') == True:  # If save file exists
                with open(Str + '/PunishDur.dat', 'rb') as PickleInst[Task]:
                    PunishDurVar.set(pickle.load(PickleInst[Task]))  # Load
            else:
                PunishDurVar.set(10)  # Default value

            if os.path.exists(Str + '/Iti.dat') == True:  # If save file exists
                with open(Str + '/Iti.dat', 'rb') as PickleInst[Task]:
                    ItiVar.set(pickle.load(PickleInst[Task]))  # Load
            else:
                ItiVar.set(1)  # Default value
            if os.path.exists(Str + '/LickDur.dat') == True:  # If save file exists
                with open(Str + '/LickDur.dat', 'rb') as PickleInst[Task]:
                    LickDurVar.set(pickle.load(PickleInst[Task]))  # Load
            else:
                LickDurVar.set(2)  # Default value

            if os.path.exists(Str + '/AutoRewardLatency.dat') == True:  # If save file exists
                with open(Str + '/AutoRewardLatency.dat', 'rb') as PickleInst[Task]:
                    AutoRewardLatencyVar.set(pickle.load(PickleInst[Task]))  # Load
            else:
                AutoRewardLatencyVar.set(360)  # Default value

            if os.path.exists(Str + '/MaxAutoRewardNum.dat') == True:  # If save file exists
                with open(Str + '/MaxAutoRewardNum.dat', 'rb') as PickleInst[Task]:
                    MaxAutoRewardNumVar.set(pickle.load(PickleInst[Task]))  # Load
            else:
                MaxAutoRewardNumVar.set(5)  # Default value

            if os.path.exists(Str + '/NextTaskTh.dat') == True:  # If save file exists
                with open(Str + '/NextTaskTh.dat', 'rb') as PickleInst[Task]:
                    NextTaskThVar.set(pickle.load(PickleInst[Task]))  # Load
            else:
                NextTaskThVar.set(50)  # Default value
            if os.path.exists(Str + '/NextTask.dat') == True:  # If save file exists
                with open(Str + '/NextTask.dat', 'rb') as PickleInst[Task]:
                    NextTaskVar.set(pickle.load(PickleInst[Task]))  # Load
            else:
                NextTaskVar.set(17)  # Default value

            if os.path.exists(Str + '/PanelType.dat') == True:  # If save file exists
                with open(Str + '/PanelType.dat', 'rb') as PickleInst[Task]:
                    PanelTypeVar.set(pickle.load(PickleInst[Task]))  # Load
            else:
                PanelTypeVar.set('Normal')  # Default value

            if os.path.exists(Str + '/WaterCueType.dat') == True:  # If save file exists
                with open(Str + '/WaterCueType.dat', 'rb') as PickleInst[Task]:
                    WaterCueTypeVar.set(pickle.load(PickleInst[Task]))  # Load
            else:
                WaterCueTypeVar.set('Blink')  # Default value

            if os.path.exists(Str + '/PunishWithLight.dat') == True:  # If save file exists
                with open(Str + '/PunishWithLight.dat', 'rb') as PickleInst[Task]:
                    PunishWithLightVar.set(pickle.load(PickleInst[Task]))  # Load
            else:
                PunishWithLightVar.set('ON')  # Default value
            if os.path.exists(Str + '/Inverse.dat') == True:  # If save file exists
                with open(Str + '/Inverse.dat', 'rb') as PickleInst[Task]:
                    InverseVar.set(pickle.load(PickleInst[Task]))  # Load
            else:
                InverseVar.set('Normal')  # Default value
            if os.path.exists(Str + '/AwsOn.dat') == True:  # If save file exists
                with open(Str + '/AwsOn.dat', 'rb') as PickleInst[Task]:
                    AwsOnVar.set(pickle.load(PickleInst[Task]))  # Load
            else:
                AwsOnVar.set('OFF')  # Default value
            LoadTrg = 0

        if SaveTrg == 1:  # If save trigger is on
            # Parameters of each task are saved into different folder
            Str = "ParametersForTask" + str(Task)  # Path to the folder for saving of parameters
            if os.path.exists(Str) == False:  # If folder for saving parameters is not exist
                os.mkdir(Str)  # Make folder for saving
            with open(Str + '/MaxCorrectNum.dat', 'wb') as PickleInst[Task]:
                pickle.dump(MaxCorrectNumVar.get(), PickleInst[Task])  # Save
            with open(Str + '/MaxTrialNum.dat', 'wb') as PickleInst[Task]:
                pickle.dump(MaxTrialNumVar.get(), PickleInst[Task])  # Save
            with open(Str + '/TimeLimit.dat', 'wb') as PickleInst[Task]:
                pickle.dump(TimeLimitVar.get(), PickleInst[Task])  # Save
            with open(Str + '/PunishDur.dat', 'wb') as PickleInst[Task]:
                pickle.dump(PunishDurVar.get(), PickleInst[Task])  # Save
            with open(Str + '/Iti.dat', 'wb') as PickleInst[Task]:
                pickle.dump(ItiVar.get(), PickleInst[Task])  # Save
            with open(Str + '/LickDur.dat', 'wb') as PickleInst[Task]:
                pickle.dump(LickDurVar.get(), PickleInst[Task])  # Save

            with open(Str + '/AutoRewardLatency.dat', 'wb') as PickleInst[Task]:
                pickle.dump(AutoRewardLatencyVar.get(), PickleInst[Task])  # Save
            with open(Str + '/MaxAutoRewardNum.dat', 'wb') as PickleInst[Task]:
                pickle.dump(MaxAutoRewardNumVar.get(), PickleInst[Task])  # Save

            with open(Str + '/NextTask.dat', 'wb') as PickleInst[Task]:
                pickle.dump(NextTaskVar.get(), PickleInst[Task])  # Save
            with open(Str + '/NextTaskTh.dat', 'wb') as PickleInst[Task]:
                pickle.dump(NextTaskThVar.get(), PickleInst[Task])  # Save
            with open(Str + '/PanelType.dat', 'wb') as PickleInst[Task]:
                pickle.dump(PanelTypeVar.get(), PickleInst[Task])  # Save
            with open(Str + '/WaterCueType.dat', 'wb') as PickleInst[Task]:
                pickle.dump(WaterCueTypeVar.get(), PickleInst[Task])  # Save
            with open(Str + '/PunishWithLight.dat', 'wb') as PickleInst[Task]:
                pickle.dump(PunishWithLightVar.get(), PickleInst[Task])  # Save
            with open(Str + '/Inverse.dat', 'wb') as PickleInst[Task]:
                pickle.dump(InverseVar.get(), PickleInst[Task])  # Save
            with open(Str + '/AwsOn.dat', 'wb') as PickleInst[Task]:
                pickle.dump(AwsOnVar.get(), PickleInst[Task])  # Save
            SaveTrg = 0

        if Phase == 1:  # Wait for starting of task
            if Phase1_Init == 0:
                PutPreTaskButton()
                mStatusVar = StringVar(MainWindowRoot)
                mStatus = ttk.Label(MainWindowRightFrame, textvariable=mStatusVar)
                mStatus.place(x=10, y=0)
                mOngoingResultVar = StringVar(MainWindowRoot)
                Phase1_Init = 1
            mStatusVar.set('Touch lit panel task (' + str(Task) + ')    Waiting...')
            if IsStartTime() == 1:
                StartNow()
        if Phase == 2:  # During task
            if Phase2_Init == 0:  # Initialization of the task
                PutEndTaskNowButton()
                mStatusVar.set('Touch lit panel task (' + str(Task) + ')    Start time ' + str(TaskStartedMonth) + '/' + str(TaskStartedDay) + ' ' + str(TaskStartedHour) + ':' + str(TaskStartedMinute) + '    Running')
                mOngoingResult = ttk.Label(MainWindowRightFrame, textvariable=mOngoingResultVar)
                mOngoingResult.place(x=10, y=18)

                # Convert StringVars of parameters into integer or normal string to use in the following
                MaxCorrectNum = int(MaxCorrectNumVar.get())
                MaxTrialNum = int(MaxTrialNumVar.get())
                TimeLimit = int(TimeLimitVar.get())
                PunishDur = int(PunishDurVar.get())
                Iti = int(ItiVar.get())
                LickDur = int(LickDurVar.get())
                AutoRewardLatency = int(AutoRewardLatencyVar.get())
                MaxAutoRewardNum = int(MaxAutoRewardNumVar.get())
                NextTask = int(NextTaskVar.get())
                NextTaskTh = int(NextTaskThVar.get())
                PanelType = PanelTypeVar.get()
                WaterCueType = WaterCueTypeVar.get()
                PunishWithLight = PunishWithLightVar.get()
                Inverse = InverseVar.get()
                AwsOn = AwsOnVar.get()

                StartLickRecording()
                RoofLightTurnOff()
                InfraredTurnOn()
                WaterCueTurnOn()
                WaterPosInside()
                if PanelType == 'Normal':
                    CreateNormalPanel_All()  #
                if PanelType == 'Blink':
                    CreateBlinkPanel_All()
                if PanelType == 'Textured':
                    CreateTexturedPanel_All()
                if WaterCueType == 'Blink':
                    MakeWaterCueBlink()  # Make water cue blink

                # Declar local variables for this task
                TotalTouchNum = 0
                CorrectNum = 0
                IncorrectNum = 0
                CorrectRate = 0
                AutoRewardNum = 0
                RewardNum = 0  # Total number of reward

                AWS_Latency = 20
                DuringTask = 1
                NowDrinking = 0
                CorrectPanelID = 0  # ID of correct panel
                TotalPanelNum = 0  # Total number of panels in this task
                StartRecording()  # Start camera capturing and sending of TTL

                TrialNum = 0
                TtlStart()
                Timer_Start(5)  # Task time limit timer start
                Phase2 = 2
                Phase2_Init = 1

                for i in range(0, MaxPanelNum):  # Count total panel num in this task
                    if PanelULX[Task][i] == 0:
                        TotalPanelNum = i + 1
                        break

                Writer_TouchEventTxt = open(
                    Path + "/" + str(TimeNow.year) + "_" + str(TimeNow.month) + "_" + str(TimeNow.day) + " " + str(TimeNow.hour) + "h" + str(TimeNow.minute) + "m Task" + str(Task) + " Touch.txt",
                    'w')  # Initialize the text exporter
                Writer_TouchEventCsv = open(
                    Path + "/" + str(TimeNow.year) + "_" + str(TimeNow.month) + "_" + str(TimeNow.day) + " " + str(TimeNow.hour) + "h" + str(TimeNow.minute) + "m Task" + str(Task) + " Touch.csv",
                    'w')  # Initialize the text exporter
                Writer_TouchEventTxt.write('TrialNum\tResult\t\t\tyyyy/mm/dd\th:m\ts\n')  # Write item name
                print("Task #" + str(Task) + " is started at " + str(GetTaskStartedMonth()) + '/' + str(GetTaskStartedDay()) + ' ' + str(GetTaskStartedHour()) + ':' + str(
                    GetTaskStartedMinute()) + ':' + str(GetTaskStartedSecond()))

            if Phase2 == 0:  # Initiation of new trial
                TrialNum += 1  #

                CorrectPanelID = int(random.random() * (TotalPanelNum-1))
                print('CorrectPanelID' + str(CorrectPanelID))
                ShowPanel(CorrectPanelID)
                # ShowPanel(0)
                Timer_Start(0)  # Start the latency timer
                Timer_Start(1)  # Start timer for auto reward
                Phase2 += 1
            if Phase2 == 1:  # Panel presentation
                TouchedPanelID = DetectPanelTouch()  # Examine which panel is touched (return panel ID. If none of the panels touched, return -1)
                if TouchedPanelID != -1:  # If any panel is touched
                    if TouchedPanelID == int(CorrectPanelID):  # If mouse touchs correct panel
                        WaterPosInside()  # Move water nozzle to the inside position
                        NowDrinking = 0
                        CorrectNum += 1  # Increase the number of correct respon
                        TotalTouchNum += 1
                        mOngoingResultVar.set('CorrectNum:' + str(CorrectNum) + '  IncorrectNum:' + str(IncorrectNum) + '  TotalNum:' + str(TotalTouchNum) + '  Correct:' + str(
                            round(CorrectNum * 100.0 / TotalTouchNum, 2)) + '%  AutoRewardNum:' + str(AutoRewardNum))
                        Writer_TouchEventTxt.write(
                            str(TrialNum) + '\tPanelTouched(Correct)\t' + str(TouchedPanelID) + '\t' + str(TimeNow.year) + "/" + str(TimeNow.month) + "/" + str(TimeNow.day) + "\t" + str(
                                TimeNow.hour) + ":" + str(TimeNow.minute) + "\t" + str(TimeNow.second) + "." + str(TimeNow.microsecond // 1000) + "\n")  # Write the response on the text file
                        Writer_TouchEventCsv.write(
                            str(TrialNum) + ',1,' + str(TouchedPanelID) + ',' + str(TimeNow.year) + "," + str(TimeNow.month) + "," + str(TimeNow.day) + "," + str(TimeNow.hour) + "," + str(
                                TimeNow.minute) + "," + str(TimeNow.second) + "." + str(TimeNow.microsecond // 1000) + "\n")  # Write the response on the csv file
                        HideAllPanel()
                        Timer_End(0)
                        WaterCueTurnOn()
                        Phase2 = 2  # Start reward phase
                    if TouchedPanelID != int(CorrectPanelID):  # If mouse touchs wrong panel
                        WaterPosOutside()
                        if PunishWithLight == 'ON':
                            RoofLightTurnOn()  # Turn on roof light
                        IncorrectNum += 1
                        TotalTouchNum += 1
                        mOngoingResultVar.set('CorrectNum:' + str(CorrectNum) + '  IncorrectNum:' + str(IncorrectNum) + '  TotalNum:' + str(TotalTouchNum) + '  Correct:' + str(
                            round(CorrectNum * 100.0 / TotalTouchNum, 2)) + '%  AutoRewardNum:' + str(AutoRewardNum))
                        Writer_TouchEventTxt.write(
                            str(TrialNum) + '\tPanelTouched(Wrong)\t' + str(TouchedPanelID) + '\t' + str(TimeNow.year) + "/" + str(TimeNow.month) + "/" + str(TimeNow.day) + "\t" + str(
                                TimeNow.hour) + ":" + str(TimeNow.minute) + "\t" + str(TimeNow.second) + "." + str(TimeNow.microsecond // 1000) + "\n")  # Write the response on the text file
                        Writer_TouchEventCsv.write(
                            str(TrialNum) + ',0,' + str(TouchedPanelID) + ',' + str(TimeNow.year) + "," + str(TimeNow.month) + "," + str(TimeNow.day) + "," + str(TimeNow.hour) + "," + str(
                                TimeNow.minute) + "," + str(TimeNow.second) + "." + str(TimeNow.microsecond // 1000) + "\n")  # Write the response on the csv file
                        HideAllPanel()
                        Timer_End(0)  # End timer1
                        Timer_Start(0)  # Start punish timer
                        Phase2 = 5  # Start punishment phase
                if AutoRewardNum < MaxAutoRewardNum:
                    if GetTimerSec(1) >= AutoRewardLatency:  # If time limit is auto reward latency
                        Timer_End(1)
                        WaterPosInside()  # Move water nozzle to the inside position
                        WaterCueTurnOn()
                        NowDrinking = 0
                        AutoRewardNum += 1  # Increase the number of auto reward num
                        if TotalTouchNum > 0:
                            mOngoingResultVar.set('CorrectNum:' + str(CorrectNum) + '  IncorrectNum:' + str(IncorrectNum) + '  TotalNum:' + str(TotalTouchNum) + '  Correct:' + str(
                                round(CorrectNum * 100.0 / TotalTouchNum, 2)) + '%  AutoRewardNum:' + str(AutoRewardNum))
                        Writer_TouchEventTxt.write(
                            str(TrialNum) + '\tAutoRewardSupply\t\t' + str(TimeNow.year) + "/" + str(TimeNow.month) + "/" + str(TimeNow.day) + "\t" + str(TimeNow.hour) + ":" + str(
                                TimeNow.minute) + "\t" + str(TimeNow.second) + "." + str(TimeNow.microsecond // 1000) + "\n")  # Write the response on the text file
                        Writer_TouchEventCsv.write(
                            str(TrialNum) + ',2,,' + str(TimeNow.year) + "," + str(TimeNow.month) + "," + str(TimeNow.day) + "," + str(TimeNow.hour) + "," + str(TimeNow.minute) + "," + str(
                                TimeNow.second) + "." + str(TimeNow.microsecond // 1000) + "\n")  # Write the response on the csv file
                        HideAllPanel()
                        Phase2 = 2
                if GetTimerSec(5) >= TimeLimit * 60:  # If time limit is exceeded
                    Timer_End(5)
                    Phase2 = 6
            if Phase2 == 2:  # Reward phase
                if NosePoking == 1 and NowDrinking == 0:  # If the mouse initiates nose poke
                    NowDrinking = 1
                    Timer_Start(0)  # Start lick timer
                if NowDrinking == 1:
                    if GetTimerSec(0) >= LickDur:  # If lick time exceed the designated time
                        Timer_End(0)  # End lick timer
                        WaterPosMiddle()  # Move water nozzle to the intermediate position
                        WaterCueTurnOff()
                        NowDrinking = 0
                        Timer_Start(0)  # Start ITI timer
                        Phase2 = 3

            if Phase2 == 3:  # ITI
                RewardNum = CorrectNum + AutoRewardNum
                if GetTimerSec(0) >= Iti:  # If ITI is passed
                    Timer_End(0)
                    Phase2 = 0  # Go to the next trial
                if RewardNum >= MaxCorrectNum or TotalTouchNum >= MaxTrialNum:  # If mouse achieved criteria of finishing the task
                    Timer_End(5)
                    WaterPosMiddle()
                    WaterCueTurnOff()
                    Timer_Start(0)  # Timer for interval between task and arbitary water supply is started
                    Phase2 = 6  # Go to the AWS
            if Phase2 == 5:  # Punishment phase
                if GetTimerSec(0) >= PunishDur:  # If punishment time is passed
                    RoofLightTurnOff()
                    WaterPosMiddle()  # Move water nozzle to the intermediate position
                    Timer_End(0)  # End punishment timer1
                    Timer_Start(0)  # Start ITI timer
                    Phase2 = 3
            if Phase2 == 6:
                HideAllPanel()
                if CorrectNum < MaxCorrectNum and AwsOn=='ON':  # If mouse didn't achieved the max correct response
                    Timer_Start(0)
                    Phase2 = 7
                if CorrectNum == MaxCorrectNum or AwsOn=='OFF':  # If mouse achieved the max correct response
                    Phase2 = -1
            if Phase2 == 7:  # Wait until arbitary water suuply is started
                if GetTimerSec(0) >= AWS_Latency:  # If the interval is past 60
                    Timer_End(0)
                    ArbitaryWaterSupplyDur = (MaxCorrectNum - CorrectNum) * LickDur * 1000  # Caliculate duration of complement water supply
                    StartArbitaryWaterSupply(ArbitaryWaterSupplyDur)  # Start complement water supply
                    print("AWSstart")
                    Phase2 = 8
            if Phase2 == 8:
                if GetArbitaryWaterSupplyStat() == 1:  # If complement water supply is finished
                    Phase2 = -1

            if Phase2 == -1 or Phase2 == -2:  # Task finish phase
                DuringTask = 0
                WaterPosMiddle()
                ClearPanel()
                MakeWaterCueNonBlink()
                InfraredTurnOff()
                if NowRecording == 1:
                    SetEndRecordingTimer(60)
                if CorrectNum > 0 or IncorrectNum > 0:
                    CorrectRate = int(CorrectNum * 100.0 / TotalTouchNum)
                    Writer_TouchEventTxt.write('TotalNum:' + str(TotalTouchNum) + '  Correct num:' + str(CorrectNum) + '  Incorrect num:' + str(IncorrectNum) + '  Correct rate:' + str(
                        CorrectRate) + '%  Auto reward num:' + str(AutoRewardNum) + '\n')  # 結果テキストの一番最後に成績のまとめを記入
                Writer_TouchEventTxt.write(
                    'TaskStartTime: ' + str(GetTaskStartedMonth()) + '/' + str(GetTaskStartedDay()) + ' ' + str(GetTaskStartedHour()) + ':' + str(GetTaskStartedMinute()) + ':' + str(
                        GetTaskStartedSecond()) + "\n")
                Writer_TouchEventTxt.write('TaskEndTime: ' + str(TimeNow.month) + '/' + str(TimeNow.day) + ' ' + str(TimeNow.hour) + ':' + str(TimeNow.minute) + ':' + str(
                    TimeNow.second + (TimeNow.microsecond // 1000) / 1000) + "\n")
                Writer_TouchEventTxt.write('MaxCorrectNum: ' + str(MaxCorrectNum) + "\n")
                Writer_TouchEventTxt.write('MaxTrialNum: ' + str(MaxTrialNum) + "\n")
                Writer_TouchEventTxt.write('TimeLimit: ' + str(TimeLimit) + "\n")
                Writer_TouchEventTxt.write('PunishDur: ' + str(PunishDur) + "\n")
                Writer_TouchEventTxt.write('Iti: ' + str(Iti) + "\n")
                Writer_TouchEventTxt.write('LickDur: ' + str(LickDur) + "\n")
                Writer_TouchEventTxt.write('AutoRewardLatency: ' + str(AutoRewardLatency) + "\n")
                Writer_TouchEventTxt.write('MaxAutoRewardNum: ' + str(AutoRewardNum) + "\n")
                Writer_TouchEventTxt.write('NextTask: ' + str(NextTask) + "\n")
                Writer_TouchEventTxt.write('NextTaskTh: ' + str(NextTaskTh) + "\n")
                Writer_TouchEventTxt.write('PanelType: ' + str(PanelType) + "\n")
                Writer_TouchEventTxt.write('WaterCueType: ' + str(WaterCueType) + "\n")
                Writer_TouchEventTxt.write('PunishWithLight: ' + str(PunishWithLight) + "\n")
                Writer_TouchEventTxt.write('Inverse: ' + str(Inverse) + "\n")
                Writer_TouchEventTxt.write('RecordFPS: ' + str(RecordFPS) + "\n")
                Writer_TouchEventTxt.write('AWS : ' + AwsOn + "\n")
                Writer_TouchEventTxt.write('AWS_Latency: ' + str(AWS_Latency) + "\n")
                Writer_TouchEventTxt.close()
                Writer_TouchEventCsv.close()
                EndLickRecording()

                SendMail(DeviceNameVar.get() + ' finished task ' + str(Task) + '. Correct:' + str(CorrectNum) + ' Incorrect:' + str(IncorrectNum) + ' Correct:' + str(CorrectRate) + '% Dur:' + str(round(GetTimerSec(5) / 60, 1)) + ' min', 'The task is finished.')
                TtlDelayStop()

                if IsHousingAnalysis == 1 and Phase2 == -1:  # If it is housing analysis
                    if CorrectRate >= NextTaskTh:  # If the score exceed the criteria to switch the next task
                        SwitchTask(NextTask)  # Onset task switch trigger
                        print("Task is switched to task#" + str(NextTask) + "  " + str(GetTaskStartedMonth()) + '/' + str(GetTaskStartedDay()) + ' ' + str(GetTaskStartedHour()) + ':' + str(GetTaskStartedMinute()) + ':' + str(GetTaskStartedSecond()))

                if IsHousingAnalysis == 0:
                    RoofLightTurnOn()
                Phase = 1  # Go back to the task-waiting phase
                Phase2 = 0
                Phase2_Init = 0
    return
def Task6():
    global Phase, Phase2, Init, Task, SaveTrg, LoadTrg, NosePoking, DuringTask, NowRecording, RecordFPS
    Task = 6
    Phase0_Init = 0
    Phase1_Init = 0
    Phase2_Init = 0
    while EndFlag == 0:
        OperantHouseUpdate()
        if Phase == -1:  # Back to the task select phase
            Phase = 0
            Task = 0
            break
        if Phase == 0:  # Parameter inputs
            if Phase0_Init == 0:
                LoadTrg = 1
                # Make GUI for the setting of the parameters for this task
                RemoveMainRightWidget()  # Remove task buttons

                PutStartBackButton()  # Put start/back buttons
                mSpace = ttk.Label(MainWindowRightFrame, text='').grid(row=0, column=1)  # Used just as spacer

                mMaxCorrectNum = ttk.Label(MainWindowRightFrame, text='MaxCorrectNum').grid(row=0, column=2, sticky=W)  # Put label
                MaxCorrectNumVar = IntVar(MainWindowRoot)  # Declare variable receiving value from the entry field
                iMaxCorrectNum = ttk.Entry(MainWindowRightFrame, textvariable=MaxCorrectNumVar).grid(row=1, column=2)  # Place entry field

                mMaxTrialNum = ttk.Label(MainWindowRightFrame, text='MaxTrialNum').grid(row=0, column=3, sticky=W)
                MaxTrialNumVar = IntVar(MainWindowRoot)
                iMaxTrialNum = ttk.Entry(MainWindowRightFrame, textvariable=MaxTrialNumVar).grid(row=1, column=3)

                mTimeLimit = ttk.Label(MainWindowRightFrame, text='TimeLimit(min)').grid(row=0, column=4, sticky=W)
                TimeLimitVar = IntVar(MainWindowRoot)
                iTimeLimit = ttk.Entry(MainWindowRightFrame, textvariable=TimeLimitVar).grid(row=1, column=4)

                mPunishDur = ttk.Label(MainWindowRightFrame, text='PunishDur(s)').grid(row=0, column=5, sticky=W)
                PunishDurVar = IntVar(MainWindowRoot)
                iPunishDur = ttk.Entry(MainWindowRightFrame, textvariable=PunishDurVar).grid(row=1, column=5)

                mIti = ttk.Label(MainWindowRightFrame, text='ITI(s)').grid(row=0, column=6, sticky=W)
                ItiVar = IntVar(MainWindowRoot)
                iIti = ttk.Entry(MainWindowRightFrame, textvariable=ItiVar).grid(row=1, column=6)

                mLickDur = ttk.Label(MainWindowRightFrame, text='LickDur(s)').grid(row=0, column=7, sticky=W)
                LickDurVar = IntVar(MainWindowRoot)
                iLickDur = ttk.Entry(MainWindowRightFrame, textvariable=LickDurVar).grid(row=1, column=7)

                mNextTaskTh = ttk.Label(MainWindowRightFrame, text='NextTaskTh(Correct%)').grid(row=2, column=2, sticky=W)
                NextTaskThVar = IntVar(MainWindowRoot)
                iNextTaskTh = ttk.Entry(MainWindowRightFrame, textvariable=NextTaskThVar).grid(row=3, column=2)

                mNextTask = ttk.Label(MainWindowRightFrame, text='NextTask#').grid(row=2, column=3, sticky=W)
                NextTaskVar = IntVar(MainWindowRoot)
                iNextTask = ttk.Entry(MainWindowRightFrame, textvariable=NextTaskVar).grid(row=3, column=3)

                mEvalCorrectNum = ttk.Label(MainWindowRightFrame, text='EvalCorrectNum').grid(row=2, column=4, sticky=W)
                EvalCorrectNumVar = IntVar(MainWindowRoot)
                iEvalCorrectNum = ttk.Entry(MainWindowRightFrame, textvariable=EvalCorrectNumVar).grid(row=3, column=4)

                mNecCorrectNum = ttk.Label(MainWindowRightFrame, text='NecCorrectNum').grid(row=2, column=5, sticky=W)
                NecCorrectNumVar = IntVar(MainWindowRoot)
                iNecCorrectNum = ttk.Entry(MainWindowRightFrame, textvariable=NecCorrectNumVar).grid(row=3, column=5)

                mCorrectPos = ttk.Label(MainWindowRightFrame, text='CorrectPos').grid(row=4, column=2, sticky=W)  # Put label
                CorrectPosVar = StringVar(MainWindowRightFrame)  # Declare variable receiving value from the entry field
                tCorrectPos = OptionMenu(MainWindowRightFrame, CorrectPosVar, "0", "1", "2", "3").grid(row=5, column=2)  # Place drop-down list

                mPanelType = ttk.Label(MainWindowRightFrame, text='PanelType').grid(row=4, column=3, sticky=W)
                PanelTypeVar = StringVar(MainWindowRightFrame)
                tPanelType = OptionMenu(MainWindowRightFrame, PanelTypeVar, "Normal", "Blink", "Textured").grid(row=5, column=3)

                mWaterCueType = ttk.Label(MainWindowRightFrame, text='WaterCueType').grid(row=4, column=4, sticky=W)
                WaterCueTypeVar = StringVar(MainWindowRightFrame)
                tWaterCueType = OptionMenu(MainWindowRightFrame, WaterCueTypeVar, "Normal", "Blink").grid(row=5, column=4)

                mPunishWithLight = ttk.Label(MainWindowRightFrame, text='PunishWithLight').grid(row=4, column=5, sticky=W)
                PunishWithLightVar = StringVar(MainWindowRightFrame)
                tPunishWithLight = OptionMenu(MainWindowRightFrame, PunishWithLightVar, "ON", "OFF").grid(row=5, column=5)

                mAutoDisAltMode = ttk.Label(MainWindowRightFrame, text='AutoDisAltMode').grid(row=4, column=6, sticky=W)
                AutoDisAltModeVar = StringVar(MainWindowRightFrame)
                iAutoDisAltMode = OptionMenu(MainWindowRightFrame, AutoDisAltModeVar, "ON", "OFF").grid(row=5, column=6)

                mAwsOn = ttk.Label(MainWindowRightFrame, text='AWS').grid(row=4, column=7, sticky=W)
                AwsOnVar = StringVar(MainWindowRightFrame)
                iAwsOn = OptionMenu(MainWindowRightFrame, AwsOnVar, "ON", "OFF").grid(row=5, column=7)

                #InitPanel()  #
                Phase0_Init = 1

        if LoadTrg == 1:  # If load trigger is on

            Str = "ParametersForTask" + str(Task)
            if os.path.exists(Str + '/MaxCorrectNum.dat') == True:  # If save file exists
                with open(Str + '/MaxCorrectNum.dat', 'rb') as PickleInst[Task]:
                    MaxCorrectNumVar.set(pickle.load(PickleInst[Task]))  # Load
            else:
                MaxCorrectNumVar.set(80)  # Default value

            if os.path.exists(Str + '/MaxTrialNum.dat') == True:  # If save file exists
                with open(Str + '/MaxTrialNum.dat', 'rb') as PickleInst[Task]:
                    MaxTrialNumVar.set(pickle.load(PickleInst[Task]))  # Load
            else:
                MaxTrialNumVar.set(110)  # Default value

            if os.path.exists(Str + '/TimeLimit.dat') == True:  # If save file exists
                with open(Str + '/TimeLimit.dat', 'rb') as PickleInst[Task]:
                    TimeLimitVar.set(pickle.load(PickleInst[Task]))  # Load
            else:
                TimeLimitVar.set(90)  # Default value

            if os.path.exists(Str + '/PunishDur.dat') == True:  # If save file exists
                with open(Str + '/PunishDur.dat', 'rb') as PickleInst[Task]:
                    PunishDurVar.set(pickle.load(PickleInst[Task]))  # Load
            else:
                PunishDurVar.set(15)  # Default value

            if os.path.exists(Str + '/Iti.dat') == True:  # If save file exists
                with open(Str + '/Iti.dat', 'rb') as PickleInst[Task]:
                    ItiVar.set(pickle.load(PickleInst[Task]))  # Load
            else:
                ItiVar.set(1)  # Default value
            if os.path.exists(Str + '/LickDur.dat') == True:  # If save file exists
                with open(Str + '/LickDur.dat', 'rb') as PickleInst[Task]:
                    LickDurVar.set(pickle.load(PickleInst[Task]))  # Load
            else:
                LickDurVar.set(2)  # Default value
            if os.path.exists(Str + '/NextTaskTh.dat') == True:  # If save file exists
                with open(Str + '/NextTaskTh.dat', 'rb') as PickleInst[Task]:
                    NextTaskThVar.set(pickle.load(PickleInst[Task]))  # Load
            else:
                NextTaskThVar.set(26)  # Default value
            if os.path.exists(Str + '/NextTask.dat') == True:  # If save file exists
                with open(Str + '/NextTask.dat', 'rb') as PickleInst[Task]:
                    NextTaskVar.set(pickle.load(PickleInst[Task]))  # Load
            else:
                NextTaskVar.set(26)  # Default value
            if os.path.exists(Str + '/EvalCorrectNum.dat') == True:  # If save file exists
                with open(Str + '/EvalCorrectNum.dat', 'rb') as PickleInst[Task]:
                    EvalCorrectNumVar.set(pickle.load(PickleInst[Task]))  # Load
            else:
                EvalCorrectNumVar.set(8)  # Default value
            if os.path.exists(Str + '/NecCorrectNum.dat') == True:  # If save file exists
                with open(Str + '/NecCorrectNum.dat', 'rb') as PickleInst[Task]:
                    NecCorrectNumVar.set(pickle.load(PickleInst[Task]))  # Load
            else:
                NecCorrectNumVar.set(7)  # Default value
            if os.path.exists(Str + '/CorrectPos.dat') == True:  # If save file exists
                with open(Str + '/CorrectPos.dat', 'rb') as PickleInst[Task]:
                    CorrectPosVar.set(pickle.load(PickleInst[Task]))  # Load
            else:
                CorrectPosVar.set(1)  # Default value
            if os.path.exists(Str + '/PanelType.dat') == True:  # If save file exists
                with open(Str + '/PanelType.dat', 'rb') as PickleInst[Task]:
                    PanelTypeVar.set(pickle.load(PickleInst[Task]))  # Load
            else:
                PanelTypeVar.set('Normal')  # Default value
            if os.path.exists(Str + '/WaterCueType.dat') == True:  # If save file exists
                with open(Str + '/WaterCueType.dat', 'rb') as PickleInst[Task]:
                    WaterCueTypeVar.set(pickle.load(PickleInst[Task]))  # Load
            else:
                WaterCueTypeVar.set('Blink')  # Default value
            if os.path.exists(Str + '/PunishWithLight.dat') == True:  # If save file exists
                with open(Str + '/PunishWithLight.dat', 'rb') as PickleInst[Task]:
                    PunishWithLightVar.set(pickle.load(PickleInst[Task]))  # Load
            else:
                PunishWithLightVar.set('ON')  # Default value
            if os.path.exists(Str + '/AutoDisAltMode.dat') == True:  # If save file exists
                with open(Str + '/AutoDisAltMode.dat', 'rb') as PickleInst[Task]:
                    AutoDisAltModeVar.set(pickle.load(PickleInst[Task]))  # Load
            else:
                AutoDisAltModeVar.set('ON')  # Default value
            if os.path.exists(Str + '/AwsOn.dat') == True:  # If save file exists
                with open(Str + '/AwsOn.dat', 'rb') as PickleInst[Task]:
                    AwsOnVar.set(pickle.load(PickleInst[Task]))  # Load
            else:
                AwsOnVar.set('OFF')  # Default value
            LoadTrg = 0

        if SaveTrg == 1:  # If save trigger is on
            # Parameters of each task are saved into different folder
            Str = "ParametersForTask" + str(Task)  # Path to the folder for saving of parameters
            if os.path.exists(Str) == False:  # If folder for saving parameters is not exist
                os.mkdir(Str)  # Make folder for saving
            with open(Str + '/MaxCorrectNum.dat', 'wb') as PickleInst[Task]:
                pickle.dump(MaxCorrectNumVar.get(), PickleInst[Task])  # Save
            with open(Str + '/MaxTrialNum.dat', 'wb') as PickleInst[Task]:
                pickle.dump(MaxTrialNumVar.get(), PickleInst[Task])  # Save
            with open(Str + '/TimeLimit.dat', 'wb') as PickleInst[Task]:
                pickle.dump(TimeLimitVar.get(), PickleInst[Task])  # Save
            with open(Str + '/PunishDur.dat', 'wb') as PickleInst[Task]:
                pickle.dump(PunishDurVar.get(), PickleInst[Task])  # Save
            with open(Str + '/Iti.dat', 'wb') as PickleInst[Task]:
                pickle.dump(ItiVar.get(), PickleInst[Task])  # Save
            with open(Str + '/LickDur.dat', 'wb') as PickleInst[Task]:
                pickle.dump(LickDurVar.get(), PickleInst[Task])  # Save
            with open(Str + '/NextTask.dat', 'wb') as PickleInst[Task]:
                pickle.dump(NextTaskVar.get(), PickleInst[Task])  # Save
            with open(Str + '/NextTaskTh.dat', 'wb') as PickleInst[Task]:
                pickle.dump(NextTaskThVar.get(), PickleInst[Task])  # Save
            with open(Str + '/EvalCorrectNum.dat', 'wb') as PickleInst[Task]:
                pickle.dump(EvalCorrectNumVar.get(), PickleInst[Task])  # Save
            with open(Str + '/NecCorrectNum.dat', 'wb') as PickleInst[Task]:
                pickle.dump(NecCorrectNumVar.get(), PickleInst[Task])  # Save
            with open(Str + '/CorrectPos.dat', 'wb') as PickleInst[Task]:
                pickle.dump(CorrectPosVar.get(), PickleInst[Task])  # Save
            with open(Str + '/PanelType.dat', 'wb') as PickleInst[Task]:
                pickle.dump(PanelTypeVar.get(), PickleInst[Task])  # Save
            with open(Str + '/WaterCueType.dat', 'wb') as PickleInst[Task]:
                pickle.dump(WaterCueTypeVar.get(), PickleInst[Task])  # Save
            with open(Str + '/PunishWithLight.dat', 'wb') as PickleInst[Task]:
                pickle.dump(PunishWithLightVar.get(), PickleInst[Task])  # Save
            with open(Str + '/AutoDisAltMode.dat', 'wb') as PickleInst[Task]:
                pickle.dump(AutoDisAltModeVar.get(), PickleInst[Task])  # Save
            with open(Str + '/AwsOn.dat', 'wb') as PickleInst[Task]:
                pickle.dump(AwsOnVar.get(), PickleInst[Task])  # Save
            SaveTrg = 0

        if Phase == 1:  # Wait for starting of task
            if Phase1_Init == 0:
                PutPreTaskButton()
                mStatusVar = StringVar(MainWindowRoot)
                mStatus = ttk.Label(MainWindowRightFrame, textvariable=mStatusVar)
                mStatus.place(x=10, y=0)
                mOngoingResultVar = StringVar(MainWindowRoot)
                Phase1_Init = 1
            mStatusVar.set('Pattern separation task (' + str(Task) + ')    Waiting...')
            if IsStartTime()==1:
                StartNow()
        if Phase == 2:  # During task
            if Phase2_Init == 0:  # Initialization of the task
                PutEndTaskNowButton()
                mStatusVar.set('Pattern separation task (' + str(Task) + ')    Start time ' + str(TaskStartedMonth) + '/' + str(TaskStartedDay) + ' ' + str(TaskStartedHour) + ':' + str(TaskStartedMinute) + '    Running')
                mOngoingResult = ttk.Label(MainWindowRightFrame, textvariable=mOngoingResultVar)
                mOngoingResult.place(x=10, y=18)

                # Convert StringVars of parameters into integer or normal string to use in the following
                MaxCorrectNum = int(MaxCorrectNumVar.get())
                MaxTrialNum = int(MaxTrialNumVar.get())
                TimeLimit = int(TimeLimitVar.get())
                PunishDur = int(PunishDurVar.get())
                Iti = int(ItiVar.get())
                LickDur = int(LickDurVar.get())
                NextTask = int(NextTaskVar.get())
                NextTaskTh = int(NextTaskThVar.get())
                EvalCorrectNum = int(EvalCorrectNumVar.get())
                NecCorrectNum = int(NecCorrectNumVar.get())

                CorrectPos = int(CorrectPosVar.get())
                PanelType = PanelTypeVar.get()
                WaterCueType = WaterCueTypeVar.get()
                PunishWithLight = PunishWithLightVar.get()
                AutoDisAltMode = AutoDisAltModeVar.get()
                AwsOn = AwsOnVar.get()

                StartLickRecording()
                RoofLightTurnOff()
                InfraredTurnOn()
                WaterCueTurnOn()
                WaterPosInside()
                if PanelType == 'Normal':
                    CreateNormalPanel(0)
                    CreateNormalPanel(1)
                    CreateNormalPanel(2)
                    CreateNormalPanel(3)
                if PanelType == 'Blink':
                    CreateBlinkPanel(0)
                    CreateBlinkPanel(1)
                    CreateBlinkPanel(2)
                    CreateBlinkPanel(3)
                if PanelType == 'Textured':
                    CreateTexturedPanel(0)
                    CreateTexturedPanel(1)
                    CreateTexturedPanel(2)
                    CreateTexturedPanel(3)
                if WaterCueType == 'Blink':
                    MakeWaterCueBlink()  # Make water cue blink

                # Declar local variables for this task
                TouchNum = 0
                CorrectNum = 0
                IncorrectNum = 0
                AdmittedCorrectNum = 0
                AdmittedIncorrectNum = 0
                AdmittedTouchNum = 0
                AdmittedCorrectRate= 0
                ResultLog=[0]*EvalCorrectNum
                ReversalNum=0
                TrialPerReversal=0  # Average trial number per reversal

                DuringTask = 1
                DoneCorrectResponse = 1
                NowDrinking = 0
                NowPunishing = 0
                AWS_Latency = 20
                StartRecording()  # Start camera capturing and sending of TTL

                TrialNum = 0
                TtlStart()
                Timer_Start(5)  # Task time limit timer start
                Phase2 = 2
                Phase2_Init = 1

                Writer_TouchEventTxt = open(
                    Path + "/" + str(TimeNow.year) + "_" + str(TimeNow.month) + "_" + str(TimeNow.day) + " " + str(TimeNow.hour) + "h" + str(TimeNow.minute) + "m Task" + str(Task) +  " Touch.txt",
                    'w')  # Initialize the text exporter
                Writer_TouchEventCsv = open(
                    Path + "/" + str(TimeNow.year) + "_" + str(TimeNow.month) + "_" + str(TimeNow.day) + " " + str(TimeNow.hour) + "h" + str(TimeNow.minute) + "m Task" + str(Task) +  " Touch.csv",
                    'w')  # Initialize the text exporter
                Writer_TouchEventTxt.write('TrialNum\tResult\t\t\tyyyy/mm/dd\th:m\ts\n')  # Write item name
                print("Task #" + str(Task) + " is started at " + str(GetTaskStartedMonth()) + '/' + str(GetTaskStartedDay()) + ' ' + str(GetTaskStartedHour()) + ':' + str(
                    GetTaskStartedMinute()) + ':' + str(GetTaskStartedSecond()))

            if Phase2 == 0:  # Initiation of new trial

                DoneCorrectResponse = 0
                TrialNum += 1
                if CorrectPos==0 or CorrectPos==3:
                    ShowPanel(0)
                    ShowPanel(3)
                if CorrectPos==1 or CorrectPos==2:
                    ShowPanel(1)
                    ShowPanel(2)
                Timer_Start(0)  # Start the latency timer
                Phase2 += 1
            if Phase2 == 1:  # Panel presentation
                TouchedPanelID = DetectPanelTouch()  # Examine which panel is touched (return panel ID. If none of the panels touched, return -1)
                if TouchedPanelID != -1:    # If mouse touchs any panel
                    if TouchedPanelID == int(CorrectPos):  # If mouse touches correct panel
                        DoneCorrectResponse = 1
                        WaterPosInside()  # Move water nozzle to the inside position
                        # WaterCueTurnOn()
                        NowDrinking = 0
                        CorrectNum += 1  # Increase the number of correct response
                        TouchNum += 1
                        for i in range(EvalCorrectNum-1):
                            ResultLog[EvalCorrectNum-1-i]=ResultLog[EvalCorrectNum-1-i-1]   # Push the log
                        ResultLog[0] = 1    # Input current result
                        if  AdmittedTouchNum>0:
                            AdmittedCorrectRate = round(AdmittedCorrectNum/AdmittedTouchNum*100,2)
                        if ReversalNum > 0:
                            TrialPerReversal=round(AdmittedTouchNum/ReversalNum,2)
                        mOngoingResultVar.set(
                            'TotalCorrect:' + str(CorrectNum) + '  TotalIncorrect:' + str(IncorrectNum) + '  Total:' + str(TouchNum) + ' | AdmittedCorrect:' + str(AdmittedCorrectNum) + '  AdmittedIncorrect:' + str(AdmittedIncorrectNum) + '  AdmittedTouch:' + str(AdmittedTouchNum) + '  AdmittedCorrect:' + str(AdmittedCorrectRate) +' %'+ '  Reversal:'+str(ReversalNum)+'  Touch/Reversal:'+str(TrialPerReversal))
                        Writer_TouchEventTxt.write(
                            str(TrialNum) + '\tPanelTouched(Correct)\t' +str(TouchedPanelID)+'\t'+ str(TimeNow.year) + "/" + str(TimeNow.month) + "/" + str(TimeNow.day) + "\t" + str(TimeNow.hour) + ":" + str(TimeNow.minute) + "\t" + str(TimeNow.second) + "." + str(TimeNow.microsecond // 1000) + "\n")  # Write the response on the text file
                        Writer_TouchEventCsv.write(
                            str(TrialNum) + ',1,' +str(TouchedPanelID)+','+ str(TimeNow.year) + "," + str(TimeNow.month) + "," + str(TimeNow.day) + "," + str(TimeNow.hour) + "," + str(TimeNow.minute) + "," + str(TimeNow.second) + "." + str(TimeNow.microsecond // 1000) + "\n")  # Write the response on the csv file
                        HidePanel(0)
                        HidePanel(1)
                        HidePanel(2)
                        HidePanel(3)
                        Timer_End(0)
                        WaterCueTurnOn()
                        Phase2 = 2  # Start reward phase  # print("c")
                    if TouchedPanelID != int(CorrectPos):  # If mouse touchs correct panel
                        WaterPosOutside()
                        if PunishWithLight == 'ON':
                            RoofLightTurnOn()  # Turn on roof light
                        IncorrectNum += 1
                        TouchNum += 1
                        for i in range(EvalCorrectNum-1):
                            ResultLog[EvalCorrectNum-1-i]=ResultLog[EvalCorrectNum-1-i-1]  # Push the log
                        ResultLog[0] = 0
                        if  AdmittedTouchNum>0:
                            AdmittedCorrectRate = round(AdmittedCorrectNum/AdmittedTouchNum*100,2)
                        if ReversalNum > 0:
                            TrialPerReversal=round(AdmittedTouchNum/ReversalNum, 2)
                        mOngoingResultVar.set(
                            'TotalCorrect:' + str(CorrectNum) + '  TotalIncorrect:' + str(IncorrectNum) + '  Total:' + str(TouchNum) + ' | AdmittedCorrect:' + str(AdmittedCorrectNum) + '  AdmittedIncorrect:' + str(AdmittedIncorrectNum) + '  AdmittedTouch:' + str(AdmittedTouchNum) + '  AdmittedCorrect:' + str(AdmittedCorrectRate) +' %'+ '  Reversal:'+str(ReversalNum)+'  Touch/Reversal:'+str(TrialPerReversal))
                        Writer_TouchEventTxt.write(
                            str(TrialNum) + '\tPanelTouched(Wrong)\t' +str(TouchedPanelID)+'\t'+ str(TimeNow.year) + "/" + str(TimeNow.month) + "/" + str(TimeNow.day) + "\t" + str(TimeNow.hour) + ":" + str(TimeNow.minute) + "\t" + str(TimeNow.second) + "." + str(TimeNow.microsecond // 1000) + "\n")  # Write the response on the text file
                        Writer_TouchEventCsv.write(
                            str(TrialNum) + ',0,' +str(TouchedPanelID)+','+ str(TimeNow.year) + "," + str(TimeNow.month) + "," + str(TimeNow.day) + "," + str(TimeNow.hour) + "," + str(TimeNow.minute) + "," + str(TimeNow.second) + "." + str(TimeNow.microsecond // 1000) + "\n")  # Write the response on the csv file
                        HidePanel(0)
                        HidePanel(1)
                        HidePanel(2)
                        HidePanel(3)
                        Timer_End(0)  # End timer1
                        Timer_Start(0)  # Start punish timer
                        Phase2 = 5  # Start punishment phase  # print("i")
                if GetTimerSec(5) >= TimeLimit * 60:   # If time limit is exceeded
                    Timer_End(5)
                    Phase2 = 6
            if Phase2 == 2:  # Reward phase
                if NosePoking == 1 and NowDrinking == 0:  # If the mouse initiates nose poke
                    NowDrinking = 1
                    Timer_Start(0)  # Start lick timer
                if NowDrinking == 1:
                    if DoneCorrectResponse == 1 and GetTimerSec(0) >= LickDur:  # If lick time exceed the designated time
                        Timer_End(0)  # End lick timer
                        WaterPosMiddle()  # Move water nozzle to the intermediate position
                        WaterCueTurnOff()
                        NowDrinking = 0
                        Timer_Start(0)  # Start ITI timer
                        Phase2 = 3

            if Phase2 == 3:  # ITI
                if GetTimerSec(0) >= Iti:  # If ITI is passed
                    Timer_End(0)
                    # Count recent correct num (Evaluate latest EvaCorrectNum trials)
                    RecentCorrectNum=0
                    for i in range(EvalCorrectNum):
                        if ResultLog[i]==1:
                            RecentCorrectNum+=1
                    if RecentCorrectNum >= NecCorrectNum:
                        ReversalNum += 1
                        AdmittedCorrectNum = CorrectNum
                        AdmittedIncorrectNum = IncorrectNum
                        AdmittedTouchNum = AdmittedCorrectNum + AdmittedIncorrectNum
                        if AdmittedTouchNum>0:
                            AdmittedCorrectRate = round(AdmittedCorrectNum/AdmittedTouchNum*100,2)
                        if ReversalNum > 0:
                            TrialPerReversal=round(AdmittedTouchNum/ReversalNum,2)
                        mOngoingResultVar.set('TotalCorrect:' + str(CorrectNum) + '  TotalIncorrect:' + str(IncorrectNum) + '  Total:' + str(TouchNum) + ' | AdmittedCorrect:' + str(
                            AdmittedCorrectNum) + '  AdmittedIncorrect:' + str(AdmittedIncorrectNum) + '  AdmittedTouch:' + str(AdmittedTouchNum) + '  AdmittedCorrect:' + str(
                            AdmittedCorrectRate) + ' %' + '  Reversal:' + str(ReversalNum) + '  Touch/Reversal:' + str(TrialPerReversal))
                        for i in range(EvalCorrectNum):
                            ResultLog[i] = 0
                        Trg=0
                        if CorrectPos==0:
                            CorrectPos=3
                            Trg=1
                        if CorrectPos==3 and Trg==0:
                            CorrectPos=0
                            Trg=1
                        if CorrectPos==1 and Trg==0:
                            CorrectPos=2
                            Trg=1
                        if CorrectPos==2 and Trg==0:
                            CorrectPos=1
                            Trg=1
                    Phase2 = 0  # Go to the next trial
                if CorrectNum >= MaxCorrectNum or TouchNum >= MaxTrialNum:  # If mouse achieved criteria of finishing the task
                    Timer_End(5)
                    WaterPosMiddle()
                    WaterCueTurnOff()
                    if AutoDisAltMode=='ON':    # Switch distance for the next session (For housing analysis)
                        Trg = 0
                        if CorrectPos == 0:
                            CorrectPos = 1
                            Trg = 1
                        if CorrectPos == 3 and Trg == 0:
                            CorrectPos = 2
                            Trg = 1
                        if CorrectPos == 1 and Trg == 0:
                            CorrectPos = 0
                            Trg = 1
                        if CorrectPos == 2 and Trg == 0:
                            CorrectPos = 3
                            Trg = 1
                        with open(Str + '/CorrectPos.dat', 'wb') as PickleInst[Task]:
                            pickle.dump(str(CorrectPos), PickleInst[Task])  # Save
                    Timer_Start(0)  # Timer for interval between task and arbitary water supply is started
                    Phase2 = 6  # Go to the AWS
            if Phase2 == 5:  # Punishment phase
                if GetTimerSec(0) >= PunishDur:  # If punishment time is passed
                    RoofLightTurnOff()
                    NowPunishing = 0
                    WaterPosMiddle()  # Move water nozzle to the intermediate position
                    Timer_End(0)  # End punishment timer1
                    Timer_Start(0)  # Start ITI timer
                    Phase2 = 3
            if Phase2 == 6:
                HidePanel(0)
                HidePanel(1)
                HidePanel(2)
                HidePanel(3)
                if CorrectNum < MaxCorrectNum and AwsOn=='ON':  # If mouse didn't achieved the max correct response
                    Timer_Start(0)
                    Phase2 = 7
                if CorrectNum == MaxCorrectNum or AwsOn=='OFF':  # If mouse achieved the max correct response
                    Phase2 = -1
            if Phase2 == 7:  # Wait until arbitary water suuply is started
                if GetTimerSec(0) >= AWS_Latency:  # If the interval is past 60
                    Timer_End(0)
                    ArbitaryWaterSupplyDur = (MaxCorrectNum - CorrectNum) * LickDur * 1000  # Caliculate duration of complement water supply
                    StartArbitaryWaterSupply(ArbitaryWaterSupplyDur)  # Start complement water supply
                    #print("AWSstart")
                    Phase2 = 8
            if Phase2 == 8:
                if GetArbitaryWaterSupplyStat() == 1:  # If complement water supply is finished
                    Phase2 = -1

            if Phase2 == -1 or Phase2 == -2:  # Task finish phase
                DuringTask = 0
                WaterPosMiddle()
                # if Panel!=null:
                ClearPanel()
                MakeWaterCueNonBlink()
                InfraredTurnOff()
                NowPunishing = 0
                if NowRecording == 1:
                    SetEndRecordingTimer(60)
                if CorrectNum > 0 or IncorrectNum > 0:
                    Writer_TouchEventTxt.write('Correct num:' + str(CorrectNum) + '  Incorrect num:' + str(IncorrectNum) +'  TouchNum:' + str(TouchNum) +  '  AdmittedCorrect num:' + str(AdmittedCorrectNum) + '  AdmittedIncorrect num:' + str(AdmittedIncorrectNum) +'  AdmittedTouchNum:' + str(AdmittedTouchNum) + '  Correct rate' + str(
                        AdmittedCorrectRate) + '%  Reversal:'+str(ReversalNum)+'  Touch/Reversal:'+str(TrialPerReversal) + "\n")  # Summary of result
                Writer_TouchEventTxt.write('TaskStartTime: ' +str(GetTaskStartedMonth())+'/'+ str(GetTaskStartedDay()) +' '+str(GetTaskStartedHour())+':'+str(GetTaskStartedMinute())+':'+str(GetTaskStartedSecond())+ "\n")
                Writer_TouchEventTxt.write('TaskEndTime: ' +str(TimeNow.month)+'/'+ str(TimeNow.day) +' '+str(TimeNow.hour)+':'+str(TimeNow.minute)+':'+str(TimeNow.second+(TimeNow.microsecond//1000)/1000)+ "\n")
                Writer_TouchEventTxt.write('MaxCorrectNum: ' + str(MaxCorrectNum) + "\n")
                Writer_TouchEventTxt.write('MaxTrialNum: ' + str(MaxTrialNum) + "\n")
                Writer_TouchEventTxt.write('TimeLimit: ' + str(TimeLimit) + "\n")
                Writer_TouchEventTxt.write('PunishDur: ' + str(PunishDur) + "\n")
                Writer_TouchEventTxt.write('Iti: ' + str(Iti) + "\n")
                Writer_TouchEventTxt.write('LickDur: ' + str(LickDur) + "\n")
                Writer_TouchEventTxt.write('NextTask: ' + str(NextTask) + "\n")
                Writer_TouchEventTxt.write('NextTaskTh: ' + str(NextTaskTh) + "\n")
                Writer_TouchEventTxt.write('EvalCorrectNum: ' + str(EvalCorrectNum) + "\n")
                Writer_TouchEventTxt.write('NecCorrectNum: ' + str(NecCorrectNum) + "\n")
                Writer_TouchEventTxt.write('CorrectPos: ' + str(CorrectPosVar.get()) + "\n")
                Writer_TouchEventTxt.write('PanelType: ' + str(PanelType) + "\n")
                Writer_TouchEventTxt.write('WaterCueType: ' + str(WaterCueType) + "\n")
                Writer_TouchEventTxt.write('PunishWithLight: ' + str(PunishWithLight) + "\n")
                Writer_TouchEventTxt.write('AutoDisAltMode: ' + str(AutoDisAltMode) + "\n")
                Writer_TouchEventTxt.write('AWS: ' + AwsOn + "\n")
                Writer_TouchEventTxt.write('AWS_Latency : ' + str(AWS_Latency) + "\n")
                Writer_TouchEventTxt.write('RecordFPS: ' + str(RecordFPS) + "\n")
                Writer_TouchEventTxt.close()
                Writer_TouchEventCsv.close()
                EndLickRecording()
                if AdmittedCorrectRate >= NextTaskTh:
                    Task = NextTask
                SendMail(DeviceNameVar.get() + ' finished task ' + str(Task) + '. Correct:' + str(CorrectNum) + ' Incorrect:' + str(IncorrectNum) + ' Touch/Reversal:' + str(TrialPerReversal) + '% Dur:' + str(round(GetTimerSec(5) / 60,1)) + ' min', 'The task is finished')
                TtlDelayStop()

                if IsHousingAnalysis == 1 and Phase2 == -1:  # If it is housing analysis
                    if CorrectRate >= NextTaskTh:  # If the score exceed the criteria to switch the next task
                        SwitchTask(NextTask)  # Onset task switch trigger
                        print("Task is switched to task#" + str(NextTask) + "  " + str(GetTaskStartedMonth()) + '/' + str(GetTaskStartedDay()) + ' ' + str(GetTaskStartedHour()) + ':' + str(GetTaskStartedMinute()) + ':' + str(GetTaskStartedSecond()))

                if IsHousingAnalysis == 0:
                    RoofLightTurnOn()
                Phase = 1  # Go back to the task-waiting phase
                Phase2 = 0
                Phase2_Init = 0
    return

def Task17():   # Delayed alteration task
    global Phase, Phase2, Init, Task, SaveTrg, LoadTrg, NosePoking, DuringTask, NowRecording, RecordFPS
    Task = 17
    Phase0_Init=0
    Phase1_Init=0
    Phase2_Init=0
    while EndFlag==0:
        OperantHouseUpdate()
        if Phase == -1:  # Back to the task select phase
            Phase = 0
            Task = 0
            break
        if Phase == 0:  # Parameter inputs
            if Phase0_Init == 0:
                LoadTrg = 1
                # Make GUI for the setting of the parameters for this task
                RemoveMainRightWidget() # Remove task buttons

                PutStartBackButton()    # Put start/back buttons

                EntryWidth=80   # Width of entry field
                GridX = 0  # Upper left X coordination of grids
                GridY = 0   # Upper left Y coordination of grids
                GridWidth=100   # Width of grids
                GridHeight=25   # Height of grids

                Row = 0 # Current row of grid
                Line = 0 # Current line of grid
                mMaxCorrectNum = ttk.Label(MainWindowRightFrame, text='MaxCorrect') # Make label
                mMaxCorrectNum.place(x=GridX + Row * GridWidth, y=GridY + Line * GridHeight, width=EntryWidth)    # Put label
                MaxCorrectNumVar = IntVar(MainWindowRoot)  # Declare variable receiving value from the entry field
                iMaxCorrectNum = ttk.Entry(MainWindowRightFrame, textvariable=MaxCorrectNumVar) # Make entry field
                iMaxCorrectNum.place(x=GridX + Row * GridWidth, y=GridY + (Line+1) * GridHeight-3, width=EntryWidth)  # Place entry field
                Row+=1  # Shift row
                mMaxTrialNum = ttk.Label(MainWindowRightFrame, text='MaxTrial')
                mMaxTrialNum.place(x=GridX + Row * GridWidth, y=GridY + Line * GridHeight, width=EntryWidth)  # Put label
                MaxTrialNumVar = IntVar(MainWindowRoot)  # Declare variable receiving value from the entry field
                iMaxTrialNum = ttk.Entry(MainWindowRightFrame, textvariable=MaxTrialNumVar)
                iMaxTrialNum.place(x=GridX + Row * GridWidth, y=GridY + (Line + 1) * GridHeight-3, width=EntryWidth)  # Place entry field
                Row += 1  # Shift row
                mTimeLimit = ttk.Label(MainWindowRightFrame, text='TimeLimit(m)')
                mTimeLimit.place(x=GridX + Row * GridWidth, y=GridY + Line * GridHeight, width=EntryWidth)  # Put label
                TimeLimitVar = IntVar(MainWindowRoot)  # Declare variable receiving value from the entry field
                iTimeLimit = ttk.Entry(MainWindowRightFrame, textvariable=TimeLimitVar)
                iTimeLimit.place(x=GridX + Row * GridWidth, y=GridY + (Line + 1) * GridHeight-3, width=EntryWidth)  # Place entry field
                Row += 1  # Shift row
                mPunishDur = ttk.Label(MainWindowRightFrame, text='PunishDur(s)')
                mPunishDur.place(x=GridX + Row * GridWidth, y=GridY + Line * GridHeight, width=EntryWidth)  # Put label
                PunishDurVar = IntVar(MainWindowRoot)  # Declare variable receiving value from the entry field
                iPunishDur = ttk.Entry(MainWindowRightFrame, textvariable=PunishDurVar)
                iPunishDur.place(x=GridX + Row * GridWidth, y=GridY + (Line + 1) * GridHeight-3, width=EntryWidth)  # Place entry field
                Row += 1  # Shift row
                mLickDur = ttk.Label(MainWindowRightFrame, text='LickDur(s)')
                mLickDur.place(x=GridX + Row * GridWidth, y=GridY + Line * GridHeight, width=EntryWidth)  # Put label
                LickDurVar = IntVar(MainWindowRoot)  # Declare variable receiving value from the entry field
                iLickDur = ttk.Entry(MainWindowRightFrame, textvariable=LickDurVar)
                iLickDur.place(x=GridX + Row * GridWidth, y=GridY + (Line + 1) * GridHeight-3, width=EntryWidth)  # Place entry field
                Row += 1  # Shift row

                mDelayAllowFactor = ttk.Label(MainWindowRightFrame, text='ValidDelay%')
                mDelayAllowFactor.place(x=GridX + Row * GridWidth, y=GridY + Line * GridHeight, width=EntryWidth)  # Put label
                DelayAllowFactorVar = IntVar(MainWindowRoot)  # Declare variable receiving value from the entry field
                iDelayAllowFactor = ttk.Entry(MainWindowRightFrame, textvariable=DelayAllowFactorVar)
                iDelayAllowFactor.place(x=GridX + Row * GridWidth, y=GridY + (Line + 1) * GridHeight - 3, width=EntryWidth)  # Place entry field
                Row += 1  # Shift row
                mRateTh = ttk.Label(MainWindowRightFrame, text='RateTh(%)')
                mRateTh.place(x=GridX + Row * GridWidth, y=GridY + Line * GridHeight, width=EntryWidth)  # Put label
                RateThVar = IntVar(MainWindowRoot)  # Declare variable receiving value from the entry field
                iRateTh = ttk.Entry(MainWindowRightFrame, textvariable=RateThVar)
                iRateTh.place(x=GridX + Row * GridWidth, y=GridY + (Line + 1) * GridHeight-3, width=EntryWidth)  # Place entry field
                Row += 1  # Shift row
                mDayTh = ttk.Label(MainWindowRightFrame, text='DayTh(d)')
                mDayTh.place(x=GridX + Row * GridWidth, y=GridY + Line * GridHeight, width=EntryWidth)  # Put label
                DayThVar = IntVar(MainWindowRoot)  # Declare variable receiving value from the entry field
                iDayTh = ttk.Entry(MainWindowRightFrame, textvariable=DayThVar)
                iDayTh.place(x=GridX + Row * GridWidth, y=GridY + (Line + 1) * GridHeight-3, width=EntryWidth)  # Place entry field
                Row += 1  # Shift row
                mNextTask = ttk.Label(MainWindowRightFrame, text='NextTask')
                mNextTask.place(x=GridX + Row * GridWidth, y=GridY + Line * GridHeight, width=EntryWidth)  # Put label
                NextTaskVar = IntVar(MainWindowRoot)  # Declare variable receiving value from the entry field
                iNextTask = ttk.Entry(MainWindowRightFrame, textvariable=NextTaskVar)
                iNextTask.place(x=GridX + Row * GridWidth, y=GridY + (Line + 1) * GridHeight-3, width=EntryWidth)  # Place entry field

                Row =0  # Shift row
                Line+=2 # Shift line
                mCorrectPos = ttk.Label(MainWindowRightFrame, text='CorrectPos')
                mCorrectPos.place(x=GridX + Row * GridWidth, y=GridY + Line * GridHeight, width=EntryWidth)  # Put label
                CorrectPosVar = StringVar(MainWindowRoot)  # Declare variable receiving value from the entry field
                tCorrectPos = OptionMenu(MainWindowRightFrame, CorrectPosVar, "0", "1")
                tCorrectPos.place(x=GridX + Row * GridWidth, y=GridY + (Line + 1) * GridHeight-7, width=EntryWidth)  # Place dropdown list
                Row += 1  # Shift row
                mPanelType = ttk.Label(MainWindowRightFrame, text='PanelType')
                mPanelType.place(x=GridX + Row * GridWidth, y=GridY + Line * GridHeight, width=EntryWidth)  # Put label
                PanelTypeVar = StringVar(MainWindowRoot)  # Declare variable receiving value from the entry field
                tPanelType = OptionMenu(MainWindowRightFrame, PanelTypeVar, "Normal", "Blink", "Textured")
                tPanelType.place(x=GridX + Row * GridWidth, y=GridY + (Line + 1) * GridHeight-7, width=EntryWidth)  # Place dropdown list
                Row += 1  # Shift row
                mWaterCueType = ttk.Label(MainWindowRightFrame, text='WaterCueType')
                mWaterCueType.place(x=GridX + Row * GridWidth, y=GridY + Line * GridHeight, width=EntryWidth)  # Put label
                WaterCueTypeVar = StringVar(MainWindowRoot)  # Declare variable receiving value from the entry field
                tWaterCueType = OptionMenu(MainWindowRightFrame, WaterCueTypeVar, "Normal", "Blink")
                tWaterCueType.place(x=GridX + Row * GridWidth, y=GridY + (Line + 1) * GridHeight-7, width=EntryWidth)  # Place dropdown list
                Row += 1  # Shift row
                mPunishWithLight = ttk.Label(MainWindowRightFrame, text='PunishLight')
                mPunishWithLight.place(x=GridX + Row * GridWidth, y=GridY + Line * GridHeight, width=EntryWidth)  # Put label
                PunishWithLightVar = StringVar(MainWindowRoot)  # Declare variable receiving value from the entry field
                tPunishWithLight = OptionMenu(MainWindowRightFrame, PunishWithLightVar, "ON", "OFF")
                tPunishWithLight.place(x=GridX + Row * GridWidth, y=GridY + (Line + 1) * GridHeight-7, width=EntryWidth)  # Place dropdown list
                Row += 1  # Shift row
                mAwsOn = ttk.Label(MainWindowRightFrame, text='AWS')
                mAwsOn.place(x=GridX + Row * GridWidth, y=GridY + Line * GridHeight, width=EntryWidth)  # Put label
                AwsOnVar = StringVar(MainWindowRoot)  # Declare variable receiving value from the entry field
                tAwsOn = OptionMenu(MainWindowRightFrame, AwsOnVar, "ON", "OFF")
                tAwsOn.place(x=GridX + Row * GridWidth, y=GridY + (Line + 1) * GridHeight - 7, width=EntryWidth)  # Place dropdown list
                Row = 0  # Shift row
                Line += 2  # Shift line
                mDelay0 = ttk.Label(MainWindowRightFrame, text='Delay0(s)')
                mDelay0.place(x=GridX + Row * GridWidth, y=GridY + Line * GridHeight, width=EntryWidth)  # Put label
                Delay0Var = StringVar(MainWindowRoot)  # Declare variable receiving value from the entry field
                iDelay0 = ttk.Entry(MainWindowRightFrame, textvariable=Delay0Var)
                iDelay0.place(x=GridX + Row * GridWidth, y=GridY + (Line + 1) * GridHeight-3, width=EntryWidth)  # Place entry field
                Row += 1  # Shift row
                mDelay1 = ttk.Label(MainWindowRightFrame, text='Delay1(s)')
                mDelay1.place(x=GridX + Row * GridWidth, y=GridY + Line * GridHeight, width=EntryWidth)  # Put label
                Delay1Var = StringVar(MainWindowRoot)  # Declare variable receiving value from the entry field
                iDelay1 = ttk.Entry(MainWindowRightFrame, textvariable=Delay1Var)
                iDelay1.place(x=GridX + Row * GridWidth, y=GridY + (Line + 1) * GridHeight-3, width=EntryWidth)  # Place entry field
                Row += 1  # Shift row
                mDelay2 = ttk.Label(MainWindowRightFrame, text='Delay2(s)')
                mDelay2.place(x=GridX + Row * GridWidth, y=GridY + Line * GridHeight, width=EntryWidth)  # Put label
                Delay2Var = StringVar(MainWindowRoot)  # Declare variable receiving value from the entry field
                iDelay2 = ttk.Entry(MainWindowRightFrame, textvariable=Delay2Var)
                iDelay2.place(x=GridX + Row * GridWidth, y=GridY + (Line + 1) * GridHeight-3, width=EntryWidth)  # Place entry field
                Row += 1  # Shift row
                mDelay3 = ttk.Label(MainWindowRightFrame, text='Delay3(s)')
                mDelay3.place(x=GridX + Row * GridWidth, y=GridY + Line * GridHeight, width=EntryWidth)  # Put label
                Delay3Var = StringVar(MainWindowRoot)  # Declare variable receiving value from the entry field
                iDelay3 = ttk.Entry(MainWindowRightFrame, textvariable=Delay3Var)
                iDelay3.place(x=GridX + Row * GridWidth, y=GridY + (Line + 1) * GridHeight-3, width=EntryWidth)  # Place entry field
                Row += 1  # Shift row
                mDelay4 = ttk.Label(MainWindowRightFrame, text='Delay4(s)')
                mDelay4.place(x=GridX + Row * GridWidth, y=GridY + Line * GridHeight, width=EntryWidth)  # Put label
                Delay4Var = StringVar(MainWindowRoot)  # Declare variable receiving value from the entry field
                iDelay4 = ttk.Entry(MainWindowRightFrame, textvariable=Delay4Var)
                iDelay4.place(x=GridX + Row * GridWidth, y=GridY + (Line + 1) * GridHeight-3, width=EntryWidth)  # Place entry field
                Row += 1  # Shift row
                mDelay5 = ttk.Label(MainWindowRightFrame, text='Delay5(s)')
                mDelay5.place(x=GridX + Row * GridWidth, y=GridY + Line * GridHeight, width=EntryWidth)  # Put label
                Delay5Var = StringVar(MainWindowRoot)  # Declare variable receiving value from the entry field
                iDelay5 = ttk.Entry(MainWindowRightFrame, textvariable=Delay5Var)
                iDelay5.place(x=GridX + Row * GridWidth, y=GridY + (Line + 1) * GridHeight-3, width=EntryWidth)  # Place entry field
                Row += 1  # Shift row
                mDelay6 = ttk.Label(MainWindowRightFrame, text='Delay6(s)')
                mDelay6.place(x=GridX + Row * GridWidth, y=GridY + Line * GridHeight, width=EntryWidth)  # Put label
                Delay6Var = StringVar(MainWindowRoot)  # Declare variable receiving value from the entry field
                iDelay6 = ttk.Entry(MainWindowRightFrame, textvariable=Delay6Var)
                iDelay6.place(x=GridX + Row * GridWidth, y=GridY + (Line + 1) * GridHeight-3, width=EntryWidth)  # Place entry field
                Row += 1  # Shift row
                mDelay7 = ttk.Label(MainWindowRightFrame, text='Delay7(s)')
                mDelay7.place(x=GridX + Row * GridWidth, y=GridY + Line * GridHeight, width=EntryWidth)  # Put label
                Delay7Var = StringVar(MainWindowRoot)  # Declare variable receiving value from the entry field
                iDelay7 = ttk.Entry(MainWindowRightFrame, textvariable=Delay7Var)
                iDelay7.place(x=GridX + Row * GridWidth, y=GridY + (Line + 1) * GridHeight-3, width=EntryWidth)  # Place entry field
                Row += 1  # Shift row
                mDelay8 = ttk.Label(MainWindowRightFrame, text='Delay8(s)')
                mDelay8.place(x=GridX + Row * GridWidth, y=GridY + Line * GridHeight, width=EntryWidth)  # Put label
                Delay8Var = StringVar(MainWindowRoot)  # Declare variable receiving value from the entry field
                iDelay8 = ttk.Entry(MainWindowRightFrame, textvariable=Delay8Var)
                iDelay8.place(x=GridX + Row * GridWidth, y=GridY + (Line + 1) * GridHeight-3, width=EntryWidth)  # Place entry field
                Row += 1  # Shift row
                mDelay9 = ttk.Label(MainWindowRightFrame, text='Delay9(s)')
                mDelay9.place(x=GridX + Row * GridWidth, y=GridY + Line * GridHeight, width=EntryWidth)  # Put label
                Delay9Var = StringVar(MainWindowRoot)  # Declare variable receiving value from the entry field
                iDelay9 = ttk.Entry(MainWindowRightFrame, textvariable=Delay9Var)
                iDelay9.place(x=GridX + Row * GridWidth, y=GridY + (Line + 1) * GridHeight-3, width=EntryWidth)  # Place entry field

                Phase0_Init = 1

        if LoadTrg == 1:  # If load trigger is on

            Str = "ParametersForTask" + str(Task)
            if os.path.exists(Str+'/MaxCorrectNum.dat') == True:  # If save file exists
                with open(Str+'/MaxCorrectNum.dat', 'rb') as PickleInst[Task]:
                    MaxCorrectNumVar.set(pickle.load(PickleInst[Task]))  # Load
            else:
                MaxCorrectNumVar.set(150)     # Default value

            if os.path.exists(Str+'/MaxTrialNum.dat') == True:  # If save file exists
                with open(Str+'/MaxTrialNum.dat', 'rb') as PickleInst[Task]:
                    MaxTrialNumVar.set(pickle.load(PickleInst[Task]))  # Load
            else:
                MaxTrialNumVar.set(999)     # Default value

            if os.path.exists(Str+'/TimeLimit.dat') == True:  # If save file exists
                with open(Str+'/TimeLimit.dat', 'rb') as PickleInst[Task]:
                    TimeLimitVar.set(pickle.load(PickleInst[Task]))  # Load
            else:
                TimeLimitVar.set(600)     # Default value

            if os.path.exists(Str+'/PunishDur.dat') == True:  # If save file exists
                with open(Str+'/PunishDur.dat', 'rb') as PickleInst[Task]:
                    PunishDurVar.set(pickle.load(PickleInst[Task]))  # Load
            else:
                PunishDurVar.set(10)     # Default value

            if os.path.exists(Str+'/LickDur.dat') == True:  # If save file exists
                with open(Str+'/LickDur.dat', 'rb') as PickleInst[Task]:
                    LickDurVar.set(pickle.load(PickleInst[Task]))  # Load
            else:
                LickDurVar.set(2)     # Default value



            if os.path.exists(Str+'/DelayAllowFactor.dat') == True:  # If save file exists
                with open(Str+'/DelayAllowFactor.dat', 'rb') as PickleInst[Task]:
                    DelayAllowFactorVar.set(pickle.load(PickleInst[Task]))  # Load
            else:
                DelayAllowFactorVar.set(130)     # Default value

            if os.path.exists(Str+'/RateTh.dat') == True:  # If save file exists
                with open(Str+'/RateTh.dat', 'rb') as PickleInst[Task]:
                    RateThVar.set(pickle.load(PickleInst[Task]))  # Load
            else:
                RateThVar.set(80)     # Default value

            if os.path.exists(Str+'/DayTh.dat') == True:  # If save file exists
                with open(Str+'/DayTh.dat', 'rb') as PickleInst[Task]:
                    DayThVar.set(pickle.load(PickleInst[Task]))  # Load
            else:
                DayThVar.set(2)     # Default value

            if os.path.exists(Str+'/NextTask.dat') == True:  # If save file exists
                with open(Str+'/NextTask.dat', 'rb') as PickleInst[Task]:
                    NextTaskVar.set(pickle.load(PickleInst[Task]))  # Load
            else:
                NextTaskVar.set(17)     # Default value

            if os.path.exists(Str+'/CorrectPos.dat') == True:  # If save file exists
                with open(Str+'/CorrectPos.dat', 'rb') as PickleInst[Task]:
                    CorrectPosVar.set(pickle.load(PickleInst[Task]))  # Load
            else:
                CorrectPosVar.set('0')     # Default value

            if os.path.exists(Str+'/PanelType.dat') == True:  # If save file exists
                with open(Str+'/PanelType.dat', 'rb') as PickleInst[Task]:
                    PanelTypeVar.set(pickle.load(PickleInst[Task]))  # Load
            else:
                PanelTypeVar.set('Normal')     # Default value

            if os.path.exists(Str+'/WaterCueType.dat') == True:  # If save file exists
                with open(Str+'/WaterCueType.dat', 'rb') as PickleInst[Task]:
                    WaterCueTypeVar.set(pickle.load(PickleInst[Task]))  # Load
            else:
                WaterCueTypeVar.set('Blink')     # Default value

            if os.path.exists(Str+'/PunishWithLight.dat') == True:  # If save file exists
                with open(Str+'/PunishWithLight.dat', 'rb') as PickleInst[Task]:
                    PunishWithLightVar.set(pickle.load(PickleInst[Task]))  # Load
            else:
                PunishWithLightVar.set('ON')     # Default value

            if os.path.exists(Str+'/Delay0.dat') == True:  # If save file exists
                with open(Str+'/Delay0.dat', 'rb') as PickleInst[Task]:
                    Delay0Var.set(pickle.load(PickleInst[Task]))  # Load
            else:
                Delay0Var.set('0')     # Default value
            if os.path.exists(Str+'/AwsOn.dat') == True:  # If save file exists
                with open(Str+'/AwsOn.dat', 'rb') as PickleInst[Task]:
                    AwsOnVar.set(pickle.load(PickleInst[Task]))  # Load
            else:
                AwsOnVar.set('OFF')     # Default value
            if os.path.exists(Str+'/Delay1.dat') == True:  # If save file exists
                with open(Str+'/Delay1.dat', 'rb') as PickleInst[Task]:
                    Delay1Var.set(pickle.load(PickleInst[Task]))  # Load
            else:
                Delay1Var.set('2')     # Default value
            if os.path.exists(Str+'/Delay2.dat') == True:  # If save file exists
                with open(Str+'/Delay2.dat', 'rb') as PickleInst[Task]:
                    Delay2Var.set(pickle.load(PickleInst[Task]))  # Load
            else:
                Delay2Var.set('5')     # Default value
            if os.path.exists(Str + '/Delay3.dat') == True:  # If save file exists
                with open(Str + '/Delay3.dat', 'rb') as PickleInst[Task]:
                    Delay3Var.set(pickle.load(PickleInst[Task]))  # Load
            else:
                Delay3Var.set('9')  # Default value
            if os.path.exists(Str+'/Delay4.dat') == True:  # If save file exists
                with open(Str+'/Delay4.dat', 'rb') as PickleInst[Task]:
                    Delay4Var.set(pickle.load(PickleInst[Task]))  # Load
            else:
                Delay4Var.set('14')     # Default value
            if os.path.exists(Str+'/Delay5.dat') == True:  # If save file exists
                with open(Str+'/Delay5.dat', 'rb') as PickleInst[Task]:
                    Delay5Var.set(pickle.load(PickleInst[Task]))  # Load
            else:
                Delay5Var.set('20')     # Default value
            if os.path.exists(Str+'/Delay6.dat') == True:  # If save file exists
                with open(Str+'/Delay6.dat', 'rb') as PickleInst[Task]:
                    Delay6Var.set(pickle.load(PickleInst[Task]))  # Load
            else:
                Delay6Var.set('27')     # Default value
            if os.path.exists(Str+'/Delay7.dat') == True:  # If save file exists
                with open(Str+'/Delay7.dat', 'rb') as PickleInst[Task]:
                    Delay7Var.set(pickle.load(PickleInst[Task]))  # Load
            else:
                Delay7Var.set('49')     # Default value
            if os.path.exists(Str+'/Delay8.dat') == True:  # If save file exists
                with open(Str+'/Delay8.dat', 'rb') as PickleInst[Task]:
                    Delay8Var.set(pickle.load(PickleInst[Task]))  # Load
            else:
                Delay8Var.set('87')     # Default value
            if os.path.exists(Str+'/Delay9.dat') == True:  # If save file exists
                with open(Str+'/Delay9.dat', 'rb') as PickleInst[Task]:
                    Delay9Var.set(pickle.load(PickleInst[Task]))  # Load
            else:
                Delay9Var.set('157')     # Default value

            LoadTrg = 0

        if SaveTrg == 1:    # If save trigger is on
            # Parameters of each task are saved into different folder
            Str="ParametersForTask"+str(Task)   # Path to the folder for saving of parameters
            if os.path.exists(Str) == False:    # If folder for saving parameters is not exist
                os.mkdir(Str)   # Make folder for saving
            with open(Str+'/MaxCorrectNum.dat', 'wb') as PickleInst[Task]:
                pickle.dump(MaxCorrectNumVar.get(),PickleInst[Task])     # Save
            with open(Str+'/MaxTrialNum.dat', 'wb') as PickleInst[Task]:
                pickle.dump(MaxTrialNumVar.get(),PickleInst[Task])     # Save
            with open(Str + '/TimeLimit.dat', 'wb') as PickleInst[Task]:
                pickle.dump(TimeLimitVar.get(), PickleInst[Task])  # Save
            with open(Str+'/PunishDur.dat', 'wb') as PickleInst[Task]:
                pickle.dump(PunishDurVar.get(), PickleInst[Task])     # Save
            with open(Str + '/LickDur.dat', 'wb') as PickleInst[Task]:
                pickle.dump(LickDurVar.get(), PickleInst[Task])  # Save

            with open(Str + '/DelayAllowFactor.dat', 'wb') as PickleInst[Task]:
                pickle.dump(DelayAllowFactorVar.get(), PickleInst[Task])  # Save
            with open(Str + '/RateTh.dat', 'wb') as PickleInst[Task]:
                pickle.dump(RateThVar.get(), PickleInst[Task])  # Save
            with open(Str + '/DayTh.dat', 'wb') as PickleInst[Task]:
                pickle.dump(DayThVar.get(), PickleInst[Task])  # Save
            with open(Str + '/NextTask.dat', 'wb') as PickleInst[Task]:
                pickle.dump(NextTaskVar.get(), PickleInst[Task])  # Save
            with open(Str+'/CorrectPos.dat', 'wb') as PickleInst[Task]:
                pickle.dump(CorrectPosVar.get(), PickleInst[Task])     # Save
            with open(Str+'/PanelType.dat', 'wb') as PickleInst[Task]:
                pickle.dump(PanelTypeVar.get(), PickleInst[Task])     # Save
            with open(Str+'/WaterCueType.dat', 'wb') as PickleInst[Task]:
                pickle.dump(WaterCueTypeVar.get(), PickleInst[Task])     # Save
            with open(Str+'/PunishWithLight.dat', 'wb') as PickleInst[Task]:
                pickle.dump(PunishWithLightVar.get(), PickleInst[Task])     # Save
            with open(Str + '/AwsOn.dat', 'wb') as PickleInst[Task]:
                pickle.dump(AwsOnVar.get(), PickleInst[Task])  # Save
            with open(Str+'/Delay0.dat', 'wb') as PickleInst[Task]:
                pickle.dump(Delay0Var.get(),PickleInst[Task])     # Save
            with open(Str+'/Delay1.dat', 'wb') as PickleInst[Task]:
                pickle.dump(Delay1Var.get(),PickleInst[Task])     # Save
            with open(Str+'/Delay2.dat', 'wb') as PickleInst[Task]:
                pickle.dump(Delay2Var.get(),PickleInst[Task])     # Save
            with open(Str+'/Delay3.dat', 'wb') as PickleInst[Task]:
                pickle.dump(Delay3Var.get(),PickleInst[Task])     # Save
            with open(Str+'/Delay4.dat', 'wb') as PickleInst[Task]:
                pickle.dump(Delay4Var.get(),PickleInst[Task])     # Save
            with open(Str+'/Delay5.dat', 'wb') as PickleInst[Task]:
                pickle.dump(Delay5Var.get(),PickleInst[Task])     # Save
            with open(Str+'/Delay6.dat', 'wb') as PickleInst[Task]:
                pickle.dump(Delay6Var.get(),PickleInst[Task])     # Save
            with open(Str+'/Delay7.dat', 'wb') as PickleInst[Task]:
                pickle.dump(Delay7Var.get(),PickleInst[Task])     # Save
            with open(Str+'/Delay8.dat', 'wb') as PickleInst[Task]:
                pickle.dump(Delay8Var.get(),PickleInst[Task])     # Save
            with open(Str+'/Delay9.dat', 'wb') as PickleInst[Task]:
                pickle.dump(Delay9Var.get(),PickleInst[Task])     # Save

            SaveTrg = 0

        if Phase == 1:  # Wait for starting of task
            if Phase1_Init == 0:
                PutPreTaskButton()
                mStatusVar = StringVar(MainWindowRoot)
                mStatus = ttk.Label(MainWindowRightFrame, textvariable=mStatusVar)
                mStatus.place(x=10, y=0)
                mOngoingResultVar = StringVar(MainWindowRoot)
                DatPhase = 0       # Phase of task, 0:Acquisition, 1:DelayedTask
                ThClearDay=0        # Number of stream days where criteria threshold is achieved
                CurrDelayID = 0    # Substitute current delay ID (0-9)
                NumOfDelayID=1
                for i in range(9):
                    if i==1:
                        if Delay1Var.get()!='': # If delay is designated
                            NumOfDelayID+=1
                        if Delay1Var.get() == '':   # If delay is not designated
                            break
                    if i==2:
                        if Delay2Var.get()!='': # If delay is designated
                            NumOfDelayID+=1
                        if Delay2Var.get() == '':   # If delay is not designated
                            break
                    if i==3:
                        if Delay3Var.get()!='': # If delay is designated
                            NumOfDelayID+=1
                        if Delay3Var.get() == '':   # If delay is not designated
                            break
                    if i==4:
                        if Delay4Var.get()!='': # If delay is designated
                            NumOfDelayID+=1
                        if Delay4Var.get() == '':   # If delay is not designated
                            break
                    if i==5:
                        if Delay5Var.get()!='': # If delay is designated
                            NumOfDelayID+=1
                        if Delay5Var.get() == '':   # If delay is not designated
                            break
                    if i==6:
                        if Delay6Var.get()!='': # If delay is designated
                            NumOfDelayID+=1
                        if Delay6Var.get() == '':   # If delay is not designated
                            break
                    if i==7:
                        if Delay7Var.get()!='': # If delay is designated
                            NumOfDelayID+=1
                        if Delay7Var.get() == '':   # If delay is not designated
                            break
                    if i==8:
                        if Delay8Var.get()!='': # If delay is designated
                            NumOfDelayID+=1
                        if Delay8Var.get() == '':   # If delay is not designated
                            break
                    if i==9:
                        if Delay9Var.get()!='': # If delay is designated
                            NumOfDelayID+=1
                        if Delay9Var.get() == '':   # If delay is not designated
                            break
                print('Num of delays: ' + str(NumOfDelayID))

                Phase1_Init = 1
            mStatusVar.set('Delayed alteration task (' + str(Task) + ')    Waiting...')
            if IsStartTime() == 1:  # If task start time is arrived
                StartNow()
        if Phase == 2:  # During task
            if Phase2_Init == 0: # Initialization of the task
                PutEndTaskNowButton()

                mStatusVar.set('Delayed alteration task (' + str(Task) + ')    Start time ' + str(TaskStartedMonth) + '/' + str(TaskStartedDay) + ' ' + str(TaskStartedHour) + ':' + str(TaskStartedMinute) + '    Running')
                mOngoingResult = ttk.Label(MainWindowRightFrame, textvariable=mOngoingResultVar)
                mOngoingResult.place(x=10, y=18)

                # Convert StringVars of parameters into integer or normal string to use in the following
                MaxCorrectNum=int(MaxCorrectNumVar.get())
                MaxTrialNum = int(MaxTrialNumVar.get())
                TimeLimit = int(TimeLimitVar.get())
                PunishDur = int(PunishDurVar.get())
                LickDur = int(LickDurVar.get())
                AwsOn=AwsOnVar.get()
                DelayAllowFactor = int(DelayAllowFactorVar.get())
                RateTh = int(RateThVar.get())
                DayTh = int(DayThVar.get())
                NextTask = int(NextTaskVar.get())
                CorrectPos =int(CorrectPosVar.get())
                PanelType = PanelTypeVar.get()
                WaterCueType = WaterCueTypeVar.get()
                PunishWithLight = PunishWithLightVar.get()
                if CurrDelayID==0:
                    Iti=int(Delay0Var.get())
                if CurrDelayID==1:
                    Iti=int(Delay1Var.get())
                if CurrDelayID==2:
                    Iti=int(Delay2Var.get())
                if CurrDelayID==3:
                    Iti=int(Delay3Var.get())
                if CurrDelayID==4:
                    Iti=int(Delay4Var.get())
                if CurrDelayID == 5:
                    Iti = int(Delay5Var.get())
                if CurrDelayID == 6:
                    Iti = int(Delay6Var.get())
                if CurrDelayID == 7:
                    Iti = int(Delay7Var.get())
                if CurrDelayID == 8:
                    Iti = int(Delay8Var.get())
                if CurrDelayID == 9:
                    Iti = int(Delay9Var.get())
                AllowedDelay = 10 + (Iti * DelayAllowFactor / 100)
                StartLickRecording()
                RoofLightTurnOff()
                InfraredTurnOn()
                WaterCueTurnOn()
                WaterPosInside()
                if PanelType=='Normal':
                    CreateNormalPanel(0)
                    CreateNormalPanel(1)
                if PanelType=='Blink':
                    CreateBlinkPanel(0)
                    CreateBlinkPanel(1)
                if PanelType=='Textured':
                    CreateTexturedPanel(0)
                    CreateTexturedPanel(1)
                if WaterCueType == 'Blink':
                    MakeWaterCueBlink() # Make water cue blink

                # Declar local variables for this task
                TotalTouchNum = 0
                CorrectNum = 0
                IncorrectNum = 0
                CorrectRate = 0
                ValidCorrectNum=0   # Correct touch num which have done within the designated delay
                ValidIncorrectNum = 0
                ValidTouchNum=0
                ValidCorrectRate=0  # Correct rate which have done within the designated delay
                TouchInfo=[[0 for i in range(2)] for j in range(MaxTrialNum)]   # Keep right or wrong and time of touching (For valid trial selection)
                ValidString=""

                DuringTask = 1
                DoneCorrectResponse = 1
                DuringDelay = 0
                NowDrinking = 0
                AWS_Latency = 20
                StartRecording()    # Start camera capturing and sending of TTL

                TrialNum=0
                TtlStart()
                Timer_Start(5)  # Task time limit timer start
                Phase2 = 2
                Phase2_Init = 1

                Writer_TouchEventTxt = open(Path + "/" + str(TimeNow.year) + "_" + str(TimeNow.month) + "_" + str(TimeNow.day) + " " + str(TimeNow.hour) + "h" + str(TimeNow.minute) + "m Task" + str(Task) +  " Touch.txt",'w')  # Initialize the text exporter
                Writer_TouchEventCsv = open(Path + "/" + str(TimeNow.year) + "_" + str(TimeNow.month) + "_" + str(TimeNow.day) + " " + str(TimeNow.hour) + "h" + str(TimeNow.minute) + "m Task" + str(Task) +  " Touch.csv",'w')  # Initialize the text exporter
                Writer_TouchEventTxt.write('TrialNum\tResult\t\t\tyyyy/mm/dd\th:m\ts\n')  # Write item name
                print("Task #" + str(Task) + " is started at " + str(GetTaskStartedMonth()) + '/' + str(GetTaskStartedDay()) + ' ' + str(GetTaskStartedHour()) + ':' + str(
                    GetTaskStartedMinute()) + ':' + str(GetTaskStartedSecond()))

            if Phase2 == 0:   # Initiation of new trial

                DoneCorrectResponse=0
                DuringDelay = 0
                TrialNum += 1

                ShowPanel(0)
                ShowPanel(1)

                Timer_Start(0)  # Start the latency timer
                Phase2 += 1
            if Phase2 == 1:   # Panel presentation
                TouchedPanelID = DetectPanelTouch() # Examine which panel is touched (return panel ID. If none of the panels touched, return -1)
                if TouchedPanelID != -1:
                    #ShowTouchSymbol(30)
                    if TouchedPanelID == int(CorrectPos): # If mouse touchs CORRECT panel
                        DoneCorrectResponse = 1

                        NowDrinking = 0
                        CorrectNum += 1  # Increase the number of correct respon
                        TouchInfo[TotalTouchNum][0]=1
                        TouchInfo[TotalTouchNum][1] = (TimeNow.hour*60*60)+(TimeNow.minute*60)+TimeNow.second
                        TotalTouchNum+=1
                        CorrectRate=round(CorrectNum*100.0/TotalTouchNum, 2)
                        mOngoingResultVar.set('CorrectNum:'+str(CorrectNum)+'  IncorrectNum:'+str(IncorrectNum)+'  TotalNum:'+str(TotalTouchNum)+'  Correct:'+str(CorrectRate)+'%'+ValidString)
                        Writer_TouchEventTxt.write(str(TrialNum) + '\tPanelTouched(Correct)\t' +str(TouchedPanelID)+'\t'+ str(TimeNow.year) + "/" + str(TimeNow.month) + "/" + str(TimeNow.day) + "\t" + str(TimeNow.hour) + ":" + str(TimeNow.minute) + "\t" + str(TimeNow.second) + "." + str(TimeNow.microsecond//1000) + "\n")  # Write the response on the text file
                        Writer_TouchEventCsv.write(str(TrialNum) + ',1,' +str(TouchedPanelID)+','+ str(TimeNow.year) + "," + str(TimeNow.month) + "," + str(TimeNow.day) + "," + str(TimeNow.hour) + "," + str(TimeNow.minute) + "," + str(TimeNow.second) + "." + str(TimeNow.microsecond//1000) + "\n")  # Write the response on the csv file
                        HidePanel(0)
                        HidePanel(1)
                        Timer_End(0)
                        WaterCueTurnOn()
                        Phase2 = 2  # Start reward phase
                        DuringDelay=1
                        Timer_Start(0)
                    if TouchedPanelID != int(CorrectPos): # If mouse touchs WRONG panel
                        WaterPosOutside()
                        if PunishWithLight == 'ON':
                            RoofLightTurnOn()  # Turn on roof light
                        IncorrectNum += 1
                        TouchInfo[TotalTouchNum][0] = -1
                        TouchInfo[TotalTouchNum][1] = (TimeNow.hour * 60 * 60) + (TimeNow.minute * 60) + TimeNow.second
                        TotalTouchNum += 1
                        CorrectRate = round(CorrectNum * 100.0 / TotalTouchNum, 2)
                        mOngoingResultVar.set('CorrectNum:' + str(CorrectNum) + '  IncorrectNum:' + str(IncorrectNum) + '  TotalNum:' + str(TotalTouchNum) + '  Correct:' + str(CorrectRate)+'%'+ValidString)
                        Writer_TouchEventTxt.write(str(TrialNum) + '\tPanelTouched(Wrong)\t' +str(TouchedPanelID)+'\t'+ str(TimeNow.year) + "/" + str(TimeNow.month) + "/" + str(TimeNow.day) + "\t" + str(TimeNow.hour) + ":" + str(TimeNow.minute) + "\t" + str(TimeNow.second) + "." + str(TimeNow.microsecond//1000) + "\n")  # Write the response on the text file
                        Writer_TouchEventCsv.write(str(TrialNum) + ',0,' +str(TouchedPanelID)+','+ str(TimeNow.year) + "," + str(TimeNow.month) + "," + str(TimeNow.day) + "," + str(TimeNow.hour) + "," + str(TimeNow.minute) + "," + str(TimeNow.second) + "." + str(TimeNow.microsecond//1000) + "\n")  # Write the response on the csv file
                        HidePanel(0)
                        HidePanel(1)
                        Timer_End(0)  # End timer1
                        Timer_Start(0)  # Start punish timer
                        Phase2 = 5  # Start punishment phase
                if GetTimerSec(5) >= TimeLimit * 60:   # If time limit is exceeded
                    Timer_End(5)
                    Phase2 = 6
            if Phase2 == 2:  # Reward phase
                if DuringDelay==1:
                    if GetTimerSec(0) >= Iti:
                        WaterPosInside()  # Move water nozzle to the inside position
                        DuringDelay=0
                if DuringDelay == 0:
                    if NosePoking == 1 and NowDrinking == 0:    # If the mouse initiates nose poke
                        NowDrinking = 1
                        Timer_Start(0)  # Start lick timer
                    if NowDrinking == 1:
                        if DoneCorrectResponse == 1 and GetTimerSec(0) >= LickDur:   # If lick time exceed the designated time
                            Timer_End(0) # End lick timer
                            WaterPosMiddle()    # Move water nozzle to the intermediate position
                            WaterCueTurnOff()
                            NowDrinking = 0
                            Trg = 0
                            if CorrectPos==0:
                                CorrectPos =1
                                Trg=1
                            if CorrectPos==1 and Trg==0:
                                CorrectPos =0
                            Phase2 = 3

            if Phase2 == 3:   # ITI
                # Caliculate valid score
                ValidTouchNum=0
                ValidCorrectNum=0
                ValidIncorrectNum=0
                for i in range(TotalTouchNum):  #
                    if TouchInfo[i][0] == 0:
                        break
                    if i > 0:
                        if TouchInfo[i - 1][0] == 1:  # If previous touch is correct
                            ActualDelay = TouchInfo[i][1] - TouchInfo[i - 1][1]
                            if ActualDelay <= AllowedDelay:
                                ValidTouchNum += 1
                                if TouchInfo[i][0] == 1:
                                    ValidCorrectNum += 1
                                if TouchInfo[i][0] == -1:
                                    ValidIncorrectNum += 1
                if ValidTouchNum > 0:
                    ValidCorrectRate = round(ValidCorrectNum/ValidTouchNum*100,1)
                    ValidString='  /  ValidCorrect:'+str(ValidCorrectNum)+'  ValidWrong:'+str(ValidIncorrectNum)+'  ValidTotalNum:'+str(ValidTouchNum)+'  ValidCorrect:'+str(ValidCorrectRate)+'%'
                    mOngoingResultVar.set('CorrectNum:' + str(CorrectNum) + '  IncorrectNum:' + str(IncorrectNum) + '  TotalNum:' + str(TotalTouchNum) + '  Correct:' + str(round(CorrectNum * 100.0 / TotalTouchNum, 2)) + '%' + ValidString)

                if CorrectNum >= MaxCorrectNum or TotalTouchNum >= MaxTrialNum: # If mouse achieved criteria of finishing the task
                    Timer_End(5)
                    WaterPosMiddle()
                    WaterCueTurnOff()
                    Timer_Start(0)  # Timer for interval between task and arbitary water supply is started
                    Phase2 = 6  # Go to the AWS
                else:
                    Phase2 = 0  # Go to the next trial

            if Phase2 == 5:   # Punishment phase
                if GetTimerSec(0) >= PunishDur:    # If punishment time is passed
                    RoofLightTurnOff()
                    WaterPosMiddle()    # Move water nozzle to the intermediate position
                    Timer_End(0)  # End punishment timer1
                    Timer_Start(0)  # Start ITI timer
                    Phase2 = 3
            if Phase2==6:
                HidePanel(0)
                HidePanel(1)
                if CorrectNum < MaxCorrectNum and AwsOn == 'ON':  # If mouse didn't achieved the max correct response
                    Timer_Start(0)
                    Phase2 = 7
                if CorrectNum == MaxCorrectNum or AwsOn == 'OFF':  # If mouse achieved the max correct response
                    Phase2 = -1
            if Phase2==7:   # Wait until arbitary water suuply is started
                if GetTimerSec(0) >= 20:   # If the interval is past 60
                    Timer_End(0)
                    ArbitaryWaterSupplyDur=(MaxCorrectNum - CorrectNum) * LickDur * 1000    # Caliculate duration of complement water supply
                    StartArbitaryWaterSupply(ArbitaryWaterSupplyDur) # Start complement water supply
                    print("AWSstart")
                    Phase2=8
            if Phase2==8:
                if GetArbitaryWaterSupplyStat()==1: # If complement water supply is finished
                    Phase2 = -1

            if Phase2 == -1 or Phase2 == -2:  # Task finish phase
                DuringTask = 0
                WaterPosMiddle()
                ClearPanel()
                MakeWaterCueNonBlink()
                InfraredTurnOff()
                if NowRecording == 1:
                    SetEndRecordingTimer(60)



                if TotalTouchNum > 0:
                    CorrectRate = round(CorrectNum * 100.0 / TotalTouchNum,1)
                    Writer_TouchEventTxt.write('Correct num:'+str(CorrectNum)+'  Incorrect num:'+str(IncorrectNum)+'  TotalNum:'+str(TotalTouchNum)+'  Correct rate'+str(CorrectRate)+'%'+ValidString+"\n")	#結果テキストの一番最後に成績のまとめを記入
                Writer_TouchEventTxt.write('TaskStartTime: ' + str(GetTaskStartedMonth()) + '/' + str(GetTaskStartedDay()) + ' ' + str(GetTaskStartedHour()) + ':' + str(GetTaskStartedMinute()) + ':' + str(
                    GetTaskStartedSecond()) + "\n")
                Writer_TouchEventTxt.write('TaskEndTime: ' + str(TimeNow.month) + '/' + str(TimeNow.day) + ' ' + str(TimeNow.hour) + ':' + str(TimeNow.minute) + ':' + str(TimeNow.second + (TimeNow.microsecond // 1000) / 1000) + "\n")
                Writer_TouchEventTxt.write('Delay: ' + str(Iti) + " sec\n")
                Writer_TouchEventTxt.write('MaxCorrectNum: '+str(MaxCorrectNum)+"\n")
                Writer_TouchEventTxt.write('MaxTrialNum: ' + str(MaxTrialNum) + "\n")
                Writer_TouchEventTxt.write('TimeLimit: ' + str(TimeLimit) + " min\n")
                Writer_TouchEventTxt.write('PunishDur: ' + str(PunishDur) + " sec\n")
                Writer_TouchEventTxt.write('LickDur: ' + str(LickDur) + " sec\n")
                Writer_TouchEventTxt.write('DelayAllowFactor: ' + str(DelayAllowFactor) + " %\n")
                Writer_TouchEventTxt.write('RateTh: ' + str(RateTh) + " %\n")
                Writer_TouchEventTxt.write('DayTh: ' + str(DayTh) + " day\n")
                Writer_TouchEventTxt.write('NextTask: ' + str(NextTask) + "\n")
                Writer_TouchEventTxt.write('CorrectPos: ' + str(CorrectPos) + "\n")
                Writer_TouchEventTxt.write('PanelType: ' + str(PanelType) + "\n")
                Writer_TouchEventTxt.write('WaterCueType: ' + str(WaterCueType) + "\n")
                Writer_TouchEventTxt.write('PunishWithLight: ' + str(PunishWithLight) + "\n")
                Writer_TouchEventTxt.write('RecordFPS: ' + str(RecordFPS) + "\n")
                Writer_TouchEventTxt.write('AWS: ' + AwsOn + "\n")
                Writer_TouchEventTxt.write('AWS_Latency: ' + str(AWS_Latency) + "\n")

                Writer_TouchEventTxt.close()
                Writer_TouchEventCsv.close()
                EndLickRecording()

                SendMail(DeviceNameVar.get() + ' finished task '+str(Task)+'. Correct:' + str(CorrectNum) + ' Incorrect:' + str(IncorrectNum) + ' Correct:'+str(CorrectRate)+'% Dur:' + str(round(GetTimerSec(5) / 60,1)) + ' min', 'The task is finished.')
                TtlDelayStop()

                if IsHousingAnalysis == 1:  #
                    # Update condition of experiment
                    if DatPhase == 0:   # If it is acquisition phase
                        if CorrectRate >= RateTh:   # If correct rate excceeded the criteria
                            ThClearDay+=1   # Increase the criteria counter
                            print("Current cleared stream days:" + str(ThClearDay))
                            if ThClearDay >= DayTh: # If acquisition is completed
                                DatPhase = 1    # Go to the delayed phase
                                print("Delayed phase is started")
                        if CorrectRate < RateTh:  # If correct rate belowed the criteria
                            ThClearDay =0   # Reset the criteria counter
                    if DatPhase == 1:   # If it is delayed phase
                        CurrDelayID += 1 # Change delay
                        if CurrDelayID==1:
                            print("Next delay is "+Delay1Var.get()+" sec")
                        if CurrDelayID==2:
                            print("Next delay is "+Delay2Var.get()+" sec")
                        if CurrDelayID==3:
                            print("Next delay is "+Delay3Var.get()+" sec")
                        if CurrDelayID==4:
                            print("Next delay is "+Delay4Var.get()+" sec")
                        if CurrDelayID==5:
                            print("Next delay is "+Delay5Var.get()+" sec")
                        if CurrDelayID==6:
                            print("Next delay is "+Delay6Var.get()+" sec")
                        if CurrDelayID==7:
                            print("Next delay is "+Delay7Var.get()+" sec")
                        if CurrDelayID==8:
                            print("Next delay is "+Delay8Var.get()+" sec")
                        if CurrDelayID==9:
                            print("Next delay is "+Delay9Var.get()+" sec")
                        if Phase2 == -1:
                            if CurrDelayID > NumOfDelayID-1:    # If the last delayed session is finished (This task is completed)
                                SwitchTask(NextTask)  # Onset task switch trigger
                                print("Task is switched to task#" + str(NextTask) + "  " + str(GetTaskStartedMonth()) + '/' + str(GetTaskStartedDay()) + ' ' + str(GetTaskStartedHour()) + ':' + str(GetTaskStartedMinute()) + ':' + str(GetTaskStartedSecond()))

                if IsHousingAnalysis == 0:
                    RoofLightTurnOn()

                Phase = 1  # Go back to the task-waiting phase
                Phase2 = 0
                Phase2_Init = 0
    return

def Task22():
    global Phase, Phase2, Init, Task, SaveTrg, LoadTrg, NosePoking, DuringTask, NowRecording, RecordFPS
    Task = 22
    Phase0_Init = 0
    Phase1_Init = 0
    Phase2_Init = 0
    while EndFlag == 0:
        OperantHouseUpdate()
        if Phase == -1:  # Back to the task select phase
            Phase = 0
            Task = 0
            break
        if Phase == 0:  # Parameter inputs
            if Phase0_Init == 0:
                LoadTrg = 1
                # Make GUI for the setting of the parameters for this task
                RemoveMainRightWidget()  # Remove task buttons

                PutStartBackButton()  # Put start/back buttons

                EntryWidth = 80  # Width of entry field
                GridX = 0  # Upper left X coordination of grids
                GridY = 0  # Upper left Y coordination of grids
                GridWidth = 100  # Width of grids
                GridHeight = 25  # Height of grids

                Row = 0  # Current row of grid
                Line = 0  # Current line of grid
                mMaxCorrectNum = ttk.Label(MainWindowRightFrame, text='MaxCorrect')  # Make label
                mMaxCorrectNum.place(x=GridX + Row * GridWidth, y=GridY + Line * GridHeight, width=EntryWidth)  # Put label
                MaxCorrectNumVar = IntVar(MainWindowRoot)  # Declare variable receiving value from the entry field
                iMaxCorrectNum = ttk.Entry(MainWindowRightFrame, textvariable=MaxCorrectNumVar)  # Make entry field
                iMaxCorrectNum.place(x=GridX + Row * GridWidth, y=GridY + (Line + 1) * GridHeight - 3, width=EntryWidth)  # Place entry field
                Row += 1  # Shift row
                mMaxTrialNum = ttk.Label(MainWindowRightFrame, text='MaxTrial')
                mMaxTrialNum.place(x=GridX + Row * GridWidth, y=GridY + Line * GridHeight, width=EntryWidth)  # Put label
                MaxTrialNumVar = IntVar(MainWindowRoot)  # Declare variable receiving value from the entry field
                iMaxTrialNum = ttk.Entry(MainWindowRightFrame, textvariable=MaxTrialNumVar)
                iMaxTrialNum.place(x=GridX + Row * GridWidth, y=GridY + (Line + 1) * GridHeight - 3, width=EntryWidth)  # Place entry field
                Row += 1  # Shift row
                mTimeLimit = ttk.Label(MainWindowRightFrame, text='TimeLimit(m)')
                mTimeLimit.place(x=GridX + Row * GridWidth, y=GridY + Line * GridHeight, width=EntryWidth)  # Put label
                TimeLimitVar = IntVar(MainWindowRoot)  # Declare variable receiving value from the entry field
                iTimeLimit = ttk.Entry(MainWindowRightFrame, textvariable=TimeLimitVar)
                iTimeLimit.place(x=GridX + Row * GridWidth, y=GridY + (Line + 1) * GridHeight - 3, width=EntryWidth)  # Place entry field
                Row += 1  # Shift row
                mPunishDur = ttk.Label(MainWindowRightFrame, text='PunishDur(s)')
                mPunishDur.place(x=GridX + Row * GridWidth, y=GridY + Line * GridHeight, width=EntryWidth)  # Put label
                PunishDurVar = IntVar(MainWindowRoot)  # Declare variable receiving value from the entry field
                iPunishDur = ttk.Entry(MainWindowRightFrame, textvariable=PunishDurVar)
                iPunishDur.place(x=GridX + Row * GridWidth, y=GridY + (Line + 1) * GridHeight - 3, width=EntryWidth)  # Place entry field
                Row += 1  # Shift row
                mLickDur = ttk.Label(MainWindowRightFrame, text='LickDur(s)')
                mLickDur.place(x=GridX + Row * GridWidth, y=GridY + Line * GridHeight, width=EntryWidth)  # Put label
                LickDurVar = IntVar(MainWindowRoot)  # Declare variable receiving value from the entry field
                iLickDur = ttk.Entry(MainWindowRightFrame, textvariable=LickDurVar)
                iLickDur.place(x=GridX + Row * GridWidth, y=GridY + (Line + 1) * GridHeight - 3, width=EntryWidth)  # Place entry field
                Row += 1  # Shift row
                mIti = ttk.Label(MainWindowRightFrame, text='ITI(s)')
                mIti.place(x=GridX + Row * GridWidth, y=GridY + Line * GridHeight, width=EntryWidth)  # Put label
                ItiVar = IntVar(MainWindowRoot)  # Declare variable receiving value from the entry field
                iIti = ttk.Entry(MainWindowRightFrame, textvariable=ItiVar)
                iIti.place(x=GridX + Row * GridWidth, y=GridY + (Line + 1) * GridHeight - 3, width=EntryWidth)  # Place entry field
                Row += 1  # Shift row
                mDelayAllowFactor = ttk.Label(MainWindowRightFrame, text='ValidDelay%')
                mDelayAllowFactor.place(x=GridX + Row * GridWidth, y=GridY + Line * GridHeight, width=EntryWidth)  # Put label
                DelayAllowFactorVar = IntVar(MainWindowRoot)  # Declare variable receiving value from the entry field
                iDelayAllowFactor = ttk.Entry(MainWindowRightFrame, textvariable=DelayAllowFactorVar)
                iDelayAllowFactor.place(x=GridX + Row * GridWidth, y=GridY + (Line + 1) * GridHeight - 3, width=EntryWidth)  # Place entry field
                Row += 1  # Shift row
                mRateTh = ttk.Label(MainWindowRightFrame, text='RateTh(%)')
                mRateTh.place(x=GridX + Row * GridWidth, y=GridY + Line * GridHeight, width=EntryWidth)  # Put label
                RateThVar = IntVar(MainWindowRoot)  # Declare variable receiving value from the entry field
                iRateTh = ttk.Entry(MainWindowRightFrame, textvariable=RateThVar)
                iRateTh.place(x=GridX + Row * GridWidth, y=GridY + (Line + 1) * GridHeight - 3, width=EntryWidth)  # Place entry field
                Row += 1  # Shift row
                mDayTh = ttk.Label(MainWindowRightFrame, text='DayTh(d)')
                mDayTh.place(x=GridX + Row * GridWidth, y=GridY + Line * GridHeight, width=EntryWidth)  # Put label
                DayThVar = IntVar(MainWindowRoot)  # Declare variable receiving value from the entry field
                iDayTh = ttk.Entry(MainWindowRightFrame, textvariable=DayThVar)
                iDayTh.place(x=GridX + Row * GridWidth, y=GridY + (Line + 1) * GridHeight - 3, width=EntryWidth)  # Place entry field
                Row += 1  # Shift row
                mStartSession = ttk.Label(MainWindowRightFrame, text='StartSession')
                mStartSession.place(x=GridX + Row * GridWidth, y=GridY + Line * GridHeight, width=EntryWidth)  # Put label
                StartSessionVar = IntVar(MainWindowRoot)  # Declare variable receiving value from the entry field
                iStartSession = ttk.Entry(MainWindowRightFrame, textvariable=StartSessionVar)
                iStartSession.place(x=GridX + Row * GridWidth, y=GridY + (Line + 1) * GridHeight - 3, width=EntryWidth)  # Place entry field

                Row = 0  # Shift row
                Line += 2  # Shift line

                mSeed = ttk.Label(MainWindowRightFrame, text='Seed')
                mSeed.place(x=GridX + Row * GridWidth, y=GridY + Line * GridHeight, width=EntryWidth)  # Put label
                SeedVar = IntVar(MainWindowRoot)  # Declare variable receiving value from the entry field
                iSeed = ttk.Entry(MainWindowRightFrame, textvariable=SeedVar)
                iSeed.place(x=GridX + Row * GridWidth, y=GridY + (Line + 1) * GridHeight - 3, width=EntryWidth)  # Place entry field
                Row += 1  # Shift row
                mNextTask = ttk.Label(MainWindowRightFrame, text='NextTask')
                mNextTask.place(x=GridX + Row * GridWidth, y=GridY + Line * GridHeight, width=EntryWidth)  # Put label
                NextTaskVar = IntVar(MainWindowRoot)  # Declare variable receiving value from the entry field
                iNextTask = ttk.Entry(MainWindowRightFrame, textvariable=NextTaskVar)
                iNextTask.place(x=GridX + Row * GridWidth, y=GridY + (Line + 1) * GridHeight - 3, width=EntryWidth)  # Place entry field
                Row += 1  # Shift row
                mTaskType = ttk.Label(MainWindowRightFrame, text='TaskType')
                mTaskType.place(x=GridX + Row * GridWidth, y=GridY + Line * GridHeight, width=EntryWidth)  # Put label
                TaskTypeVar = StringVar(MainWindowRoot)  # Declare variable receiving value from the entry field
                tTaskType = OptionMenu(MainWindowRightFrame, TaskTypeVar, "DNMS1", "DNMS2", "DMS1", "DMS2")
                tTaskType.place(x=GridX + Row * GridWidth, y=GridY + (Line + 1) * GridHeight - 7, width=EntryWidth)  # Place dropdown list
                Row += 1  # Shift row
                mWaterCueType = ttk.Label(MainWindowRightFrame, text='WaterCueType')
                mWaterCueType.place(x=GridX + Row * GridWidth, y=GridY + Line * GridHeight, width=EntryWidth)  # Put label
                WaterCueTypeVar = StringVar(MainWindowRoot)  # Declare variable receiving value from the entry field
                tWaterCueType = OptionMenu(MainWindowRightFrame, WaterCueTypeVar, "Normal", "Blink")
                tWaterCueType.place(x=GridX + Row * GridWidth, y=GridY + (Line + 1) * GridHeight - 7, width=EntryWidth)  # Place dropdown list
                Row += 1  # Shift row
                mPunishWithLight = ttk.Label(MainWindowRightFrame, text='PunishLight')
                mPunishWithLight.place(x=GridX + Row * GridWidth, y=GridY + Line * GridHeight, width=EntryWidth)  # Put label
                PunishWithLightVar = StringVar(MainWindowRoot)  # Declare variable receiving value from the entry field
                tPunishWithLight = OptionMenu(MainWindowRightFrame, PunishWithLightVar, "ON", "OFF")
                tPunishWithLight.place(x=GridX + Row * GridWidth, y=GridY + (Line + 1) * GridHeight - 7, width=EntryWidth)  # Place dropdown list
                Row += 1  # Shift row
                mAwsOn = ttk.Label(MainWindowRightFrame, text='AWS')
                mAwsOn.place(x=GridX + Row * GridWidth, y=GridY + Line * GridHeight, width=EntryWidth)  # Put label
                AwsOnVar = StringVar(MainWindowRoot)  # Declare variable receiving value from the entry field
                tAwsOn = OptionMenu(MainWindowRightFrame, AwsOnVar, "ON", "OFF")
                tAwsOn.place(x=GridX + Row * GridWidth, y=GridY + (Line + 1) * GridHeight - 7, width=EntryWidth)  # Place dropdown list
                Row = 0  # Shift row
                Line += 2  # Shift line
                mDelay0 = ttk.Label(MainWindowRightFrame, text='Delay0(sec)')
                mDelay0.place(x=GridX + Row * GridWidth, y=GridY + Line * GridHeight, width=EntryWidth)  # Put label
                Delay0Var = StringVar(MainWindowRoot)  # Declare variable receiving value from the entry field
                iDelay0 = ttk.Entry(MainWindowRightFrame, textvariable=Delay0Var)
                iDelay0.place(x=GridX + Row * GridWidth, y=GridY + (Line + 1) * GridHeight - 3, width=EntryWidth)  # Place entry field
                Row += 1  # Shift row
                mDelay1 = ttk.Label(MainWindowRightFrame, text='Delay1(sec)')
                mDelay1.place(x=GridX + Row * GridWidth, y=GridY + Line * GridHeight, width=EntryWidth)  # Put label
                Delay1Var = StringVar(MainWindowRoot)  # Declare variable receiving value from the entry field
                iDelay1 = ttk.Entry(MainWindowRightFrame, textvariable=Delay1Var)
                iDelay1.place(x=GridX + Row * GridWidth, y=GridY + (Line + 1) * GridHeight - 3, width=EntryWidth)  # Place entry field
                Row += 1  # Shift row
                mDelay2 = ttk.Label(MainWindowRightFrame, text='Delay2(sec)')
                mDelay2.place(x=GridX + Row * GridWidth, y=GridY + Line * GridHeight, width=EntryWidth)  # Put label
                Delay2Var = StringVar(MainWindowRoot)  # Declare variable receiving value from the entry field
                iDelay2 = ttk.Entry(MainWindowRightFrame, textvariable=Delay2Var)
                iDelay2.place(x=GridX + Row * GridWidth, y=GridY + (Line + 1) * GridHeight - 3, width=EntryWidth)  # Place entry field
                Row += 1  # Shift row
                mDelay3 = ttk.Label(MainWindowRightFrame, text='Delay3(sec)')
                mDelay3.place(x=GridX + Row * GridWidth, y=GridY + Line * GridHeight, width=EntryWidth)  # Put label
                Delay3Var = StringVar(MainWindowRoot)  # Declare variable receiving value from the entry field
                iDelay3 = ttk.Entry(MainWindowRightFrame, textvariable=Delay3Var)
                iDelay3.place(x=GridX + Row * GridWidth, y=GridY + (Line + 1) * GridHeight - 3, width=EntryWidth)  # Place entry field
                Row += 1  # Shift row
                mDelay4 = ttk.Label(MainWindowRightFrame, text='Delay4(sec)')
                mDelay4.place(x=GridX + Row * GridWidth, y=GridY + Line * GridHeight, width=EntryWidth)  # Put label
                Delay4Var = StringVar(MainWindowRoot)  # Declare variable receiving value from the entry field
                iDelay4 = ttk.Entry(MainWindowRightFrame, textvariable=Delay4Var)
                iDelay4.place(x=GridX + Row * GridWidth, y=GridY + (Line + 1) * GridHeight - 3, width=EntryWidth)  # Place entry field
                Row += 1  # Shift row
                mDelay5 = ttk.Label(MainWindowRightFrame, text='Delay5(sec)')
                mDelay5.place(x=GridX + Row * GridWidth, y=GridY + Line * GridHeight, width=EntryWidth)  # Put label
                Delay5Var = StringVar(MainWindowRoot)  # Declare variable receiving value from the entry field
                iDelay5 = ttk.Entry(MainWindowRightFrame, textvariable=Delay5Var)
                iDelay5.place(x=GridX + Row * GridWidth, y=GridY + (Line + 1) * GridHeight - 3, width=EntryWidth)  # Place entry field
                Row += 1  # Shift row
                mDelay6 = ttk.Label(MainWindowRightFrame, text='Delay6(sec)')
                mDelay6.place(x=GridX + Row * GridWidth, y=GridY + Line * GridHeight, width=EntryWidth)  # Put label
                Delay6Var = StringVar(MainWindowRoot)  # Declare variable receiving value from the entry field
                iDelay6 = ttk.Entry(MainWindowRightFrame, textvariable=Delay6Var)
                iDelay6.place(x=GridX + Row * GridWidth, y=GridY + (Line + 1) * GridHeight - 3, width=EntryWidth)  # Place entry field
                Row += 1  # Shift row
                mDelay7 = ttk.Label(MainWindowRightFrame, text='Delay7(sec)')
                mDelay7.place(x=GridX + Row * GridWidth, y=GridY + Line * GridHeight, width=EntryWidth)  # Put label
                Delay7Var = StringVar(MainWindowRoot)  # Declare variable receiving value from the entry field
                iDelay7 = ttk.Entry(MainWindowRightFrame, textvariable=Delay7Var)
                iDelay7.place(x=GridX + Row * GridWidth, y=GridY + (Line + 1) * GridHeight - 3, width=EntryWidth)  # Place entry field
                Row += 1  # Shift row
                mDelay8 = ttk.Label(MainWindowRightFrame, text='Delay8(sec)')
                mDelay8.place(x=GridX + Row * GridWidth, y=GridY + Line * GridHeight, width=EntryWidth)  # Put label
                Delay8Var = StringVar(MainWindowRoot)  # Declare variable receiving value from the entry field
                iDelay8 = ttk.Entry(MainWindowRightFrame, textvariable=Delay8Var)
                iDelay8.place(x=GridX + Row * GridWidth, y=GridY + (Line + 1) * GridHeight - 3, width=EntryWidth)  # Place entry field
                Row += 1  # Shift row
                mDelay9 = ttk.Label(MainWindowRightFrame, text='Delay9(sec)')
                mDelay9.place(x=GridX + Row * GridWidth, y=GridY + Line * GridHeight, width=EntryWidth)  # Put label
                Delay9Var = StringVar(MainWindowRoot)  # Declare variable receiving value from the entry field
                iDelay9 = ttk.Entry(MainWindowRightFrame, textvariable=Delay9Var)
                iDelay9.place(x=GridX + Row * GridWidth, y=GridY + (Line + 1) * GridHeight - 3, width=EntryWidth)  # Place entry field

                Phase0_Init = 1

        if LoadTrg == 1:  # If load trigger is on

            Str = "ParametersForTask" + str(Task)
            if os.path.exists(Str + '/MaxCorrectNum.dat') == True:  # If save file exists
                with open(Str + '/MaxCorrectNum.dat', 'rb') as PickleInst[Task]:
                    MaxCorrectNumVar.set(pickle.load(PickleInst[Task]))  # Load
            else:
                MaxCorrectNumVar.set(80)  # Default value

            if os.path.exists(Str + '/MaxTrialNum.dat') == True:  # If save file exists
                with open(Str + '/MaxTrialNum.dat', 'rb') as PickleInst[Task]:
                    MaxTrialNumVar.set(pickle.load(PickleInst[Task]))  # Load
            else:
                MaxTrialNumVar.set(999)  # Default value

            if os.path.exists(Str + '/TimeLimit.dat') == True:  # If save file exists
                with open(Str + '/TimeLimit.dat', 'rb') as PickleInst[Task]:
                    TimeLimitVar.set(pickle.load(PickleInst[Task]))  # Load
            else:
                TimeLimitVar.set(600)  # Default value

            if os.path.exists(Str + '/PunishDur.dat') == True:  # If save file exists
                with open(Str + '/PunishDur.dat', 'rb') as PickleInst[Task]:
                    PunishDurVar.set(pickle.load(PickleInst[Task]))  # Load
            else:
                PunishDurVar.set(10)  # Default value

            if os.path.exists(Str + '/LickDur.dat') == True:  # If save file exists
                with open(Str + '/LickDur.dat', 'rb') as PickleInst[Task]:
                    LickDurVar.set(pickle.load(PickleInst[Task]))  # Load
            else:
                LickDurVar.set(2)  # Default value

            if os.path.exists(Str + '/Iti.dat') == True:  # If save file exists
                with open(Str + '/Iti.dat', 'rb') as PickleInst[Task]:
                    ItiVar.set(pickle.load(PickleInst[Task]))  # Load
            else:
                ItiVar.set(20)  # Default value

            if os.path.exists(Str + '/DelayAllowFactor.dat') == True:  # If save file exists
                with open(Str + '/DelayAllowFactor.dat', 'rb') as PickleInst[Task]:
                    DelayAllowFactorVar.set(pickle.load(PickleInst[Task]))  # Load
            else:
                DelayAllowFactorVar.set(130)  # Default value

            if os.path.exists(Str + '/RateTh.dat') == True:  # If save file exists
                with open(Str + '/RateTh.dat', 'rb') as PickleInst[Task]:
                    RateThVar.set(pickle.load(PickleInst[Task]))  # Load
            else:
                RateThVar.set(80)  # Default value

            if os.path.exists(Str + '/DayTh.dat') == True:  # If save file exists
                with open(Str + '/DayTh.dat', 'rb') as PickleInst[Task]:
                    DayThVar.set(pickle.load(PickleInst[Task]))  # Load
            else:
                DayThVar.set(2)  # Default value

            if os.path.exists(Str + '/StartSession.dat') == True:  # If save file exists
                with open(Str + '/StartSession.dat', 'rb') as PickleInst[Task]:
                    StartSessionVar.set(pickle.load(PickleInst[Task]))  # Load
            else:
                NextTaskVar.set(23)  # Default value

            if os.path.exists(Str + '/Seed.dat') == True:  # If save file exists
                with open(Str + '/Seed.dat', 'rb') as PickleInst[Task]:
                    SeedVar.set(pickle.load(PickleInst[Task]))  # Load
            else:
                SeedVar.set(0)  # Default value
            if os.path.exists(Str + '/NextTask.dat') == True:  # If save file exists
                with open(Str + '/NextTask.dat', 'rb') as PickleInst[Task]:
                    NextTaskVar.set(pickle.load(PickleInst[Task]))  # Load
            else:
                NextTaskVar.set(23)  # Default value
            if os.path.exists(Str + '/TaskType.dat') == True:  # If save file exists
                with open(Str + '/TaskType.dat', 'rb') as PickleInst[Task]:
                    TaskTypeVar.set(pickle.load(PickleInst[Task]))  # Load
            else:
                TaskTypeVar.set('DNMS1')  # Default value

            if os.path.exists(Str + '/WaterCueType.dat') == True:  # If save file exists
                with open(Str + '/WaterCueType.dat', 'rb') as PickleInst[Task]:
                    WaterCueTypeVar.set(pickle.load(PickleInst[Task]))  # Load
            else:
                WaterCueTypeVar.set('Normal')  # Default value

            if os.path.exists(Str + '/PunishWithLight.dat') == True:  # If save file exists
                with open(Str + '/PunishWithLight.dat', 'rb') as PickleInst[Task]:
                    PunishWithLightVar.set(pickle.load(PickleInst[Task]))  # Load
            else:
                PunishWithLightVar.set('ON')  # Default value

            if os.path.exists(Str + '/Delay0.dat') == True:  # If save file exists
                with open(Str + '/Delay0.dat', 'rb') as PickleInst[Task]:
                    Delay0Var.set(pickle.load(PickleInst[Task]))  # Load
            else:
                Delay0Var.set('1')  # Default value
            if os.path.exists(Str + '/AwsOn.dat') == True:  # If save file exists
                with open(Str + '/AwsOn.dat', 'rb') as PickleInst[Task]:
                    AwsOnVar.set(pickle.load(PickleInst[Task]))  # Load
            else:
                AwsOnVar.set('ON')  # Default value
            if os.path.exists(Str + '/Delay1.dat') == True:  # If save file exists
                with open(Str + '/Delay1.dat', 'rb') as PickleInst[Task]:
                    Delay1Var.set(pickle.load(PickleInst[Task]))  # Load
            else:
                Delay1Var.set('2')  # Default value
            if os.path.exists(Str + '/Delay2.dat') == True:  # If save file exists
                with open(Str + '/Delay2.dat', 'rb') as PickleInst[Task]:
                    Delay2Var.set(pickle.load(PickleInst[Task]))  # Load
            else:
                Delay2Var.set('3')  # Default value
            if os.path.exists(Str + '/Delay3.dat') == True:  # If save file exists
                with open(Str + '/Delay3.dat', 'rb') as PickleInst[Task]:
                    Delay3Var.set(pickle.load(PickleInst[Task]))  # Load
            else:
                Delay3Var.set('5')  # Default value
            if os.path.exists(Str + '/Delay4.dat') == True:  # If save file exists
                with open(Str + '/Delay4.dat', 'rb') as PickleInst[Task]:
                    Delay4Var.set(pickle.load(PickleInst[Task]))  # Load
            else:
                Delay4Var.set('8')  # Default value
            if os.path.exists(Str + '/Delay5.dat') == True:  # If save file exists
                with open(Str + '/Delay5.dat', 'rb') as PickleInst[Task]:
                    Delay5Var.set(pickle.load(PickleInst[Task]))  # Load
            else:
                Delay5Var.set('12')  # Default value
            if os.path.exists(Str + '/Delay6.dat') == True:  # If save file exists
                with open(Str + '/Delay6.dat', 'rb') as PickleInst[Task]:
                    Delay6Var.set(pickle.load(PickleInst[Task]))  # Load
            else:
                Delay6Var.set('16')  # Default value
            if os.path.exists(Str + '/Delay7.dat') == True:  # If save file exists
                with open(Str + '/Delay7.dat', 'rb') as PickleInst[Task]:
                    Delay7Var.set(pickle.load(PickleInst[Task]))  # Load
            else:
                Delay7Var.set('20')  # Default value
            if os.path.exists(Str + '/Delay8.dat') == True:  # If save file exists
                with open(Str + '/Delay8.dat', 'rb') as PickleInst[Task]:
                    Delay8Var.set(pickle.load(PickleInst[Task]))  # Load
            else:
                Delay8Var.set('24')  # Default value
            if os.path.exists(Str + '/Delay9.dat') == True:  # If save file exists
                with open(Str + '/Delay9.dat', 'rb') as PickleInst[Task]:
                    Delay9Var.set(pickle.load(PickleInst[Task]))  # Load
            else:
                Delay9Var.set('24')  # Default value

            LoadTrg = 0

        if SaveTrg == 1:  # If save trigger is on
            # Parameters of each task are saved into different folder
            Str = "ParametersForTask" + str(Task)  # Path to the folder for saving of parameters
            if os.path.exists(Str) == False:  # If folder for saving parameters is not exist
                os.mkdir(Str)  # Make folder for saving
            with open(Str + '/MaxCorrectNum.dat', 'wb') as PickleInst[Task]:
                pickle.dump(MaxCorrectNumVar.get(), PickleInst[Task])  # Save
            with open(Str + '/MaxTrialNum.dat', 'wb') as PickleInst[Task]:
                pickle.dump(MaxTrialNumVar.get(), PickleInst[Task])  # Save
            with open(Str + '/TimeLimit.dat', 'wb') as PickleInst[Task]:
                pickle.dump(TimeLimitVar.get(), PickleInst[Task])  # Save
            with open(Str + '/PunishDur.dat', 'wb') as PickleInst[Task]:
                pickle.dump(PunishDurVar.get(), PickleInst[Task])  # Save
            with open(Str + '/LickDur.dat', 'wb') as PickleInst[Task]:
                pickle.dump(LickDurVar.get(), PickleInst[Task])  # Save
            with open(Str + '/Iti.dat', 'wb') as PickleInst[Task]:
                pickle.dump(ItiVar.get(), PickleInst[Task])  # Save
            with open(Str + '/DelayAllowFactor.dat', 'wb') as PickleInst[Task]:
                pickle.dump(DelayAllowFactorVar.get(), PickleInst[Task])  # Save
            with open(Str + '/RateTh.dat', 'wb') as PickleInst[Task]:
                pickle.dump(RateThVar.get(), PickleInst[Task])  # Save
            with open(Str + '/DayTh.dat', 'wb') as PickleInst[Task]:
                pickle.dump(DayThVar.get(), PickleInst[Task])  # Save
            with open(Str + '/StartSession.dat', 'wb') as PickleInst[Task]:
                pickle.dump(StartSessionVar.get(), PickleInst[Task])  # Save
            with open(Str + '/Seed.dat', 'wb') as PickleInst[Task]:
                pickle.dump(SeedVar.get(), PickleInst[Task])  # Save
            with open(Str + '/NextTask.dat', 'wb') as PickleInst[Task]:
                pickle.dump(NextTaskVar.get(), PickleInst[Task])  # Save
            with open(Str + '/TaskType.dat', 'wb') as PickleInst[Task]:
                pickle.dump(TaskTypeVar.get(), PickleInst[Task])  # Save
            with open(Str + '/WaterCueType.dat', 'wb') as PickleInst[Task]:
                pickle.dump(WaterCueTypeVar.get(), PickleInst[Task])  # Save
            with open(Str + '/PunishWithLight.dat', 'wb') as PickleInst[Task]:
                pickle.dump(PunishWithLightVar.get(), PickleInst[Task])  # Save
            with open(Str + '/AwsOn.dat', 'wb') as PickleInst[Task]:
                pickle.dump(AwsOnVar.get(), PickleInst[Task])  # Save
            with open(Str + '/Delay0.dat', 'wb') as PickleInst[Task]:
                pickle.dump(Delay0Var.get(), PickleInst[Task])  # Save
            with open(Str + '/Delay1.dat', 'wb') as PickleInst[Task]:
                pickle.dump(Delay1Var.get(), PickleInst[Task])  # Save
            with open(Str + '/Delay2.dat', 'wb') as PickleInst[Task]:
                pickle.dump(Delay2Var.get(), PickleInst[Task])  # Save
            with open(Str + '/Delay3.dat', 'wb') as PickleInst[Task]:
                pickle.dump(Delay3Var.get(), PickleInst[Task])  # Save
            with open(Str + '/Delay4.dat', 'wb') as PickleInst[Task]:
                pickle.dump(Delay4Var.get(), PickleInst[Task])  # Save
            with open(Str + '/Delay5.dat', 'wb') as PickleInst[Task]:
                pickle.dump(Delay5Var.get(), PickleInst[Task])  # Save
            with open(Str + '/Delay6.dat', 'wb') as PickleInst[Task]:
                pickle.dump(Delay6Var.get(), PickleInst[Task])  # Save
            with open(Str + '/Delay7.dat', 'wb') as PickleInst[Task]:
                pickle.dump(Delay7Var.get(), PickleInst[Task])  # Save
            with open(Str + '/Delay8.dat', 'wb') as PickleInst[Task]:
                pickle.dump(Delay8Var.get(), PickleInst[Task])  # Save
            with open(Str + '/Delay9.dat', 'wb') as PickleInst[Task]:
                pickle.dump(Delay9Var.get(), PickleInst[Task])  # Save

            SaveTrg = 0

        if Phase == 1:  # Wait for starting of task
            if Phase1_Init == 0:
                PutPreTaskButton()
                mStatusVar = StringVar(MainWindowRoot)
                mStatus = ttk.Label(MainWindowRightFrame, textvariable=mStatusVar)
                mStatus.place(x=10, y=0)
                mOngoingResultVar = StringVar(MainWindowRoot)
                LearningPhase = 0  # Phase of task, 0:Acquisition, 1:DelayedTask
                SessionDelayID = int(StartSessionVar.get())  # Substitute delay ID (0-9)
                if SessionDelayID > 0:  # If session is started from middle
                    LearningPhase = 1  # Phase of task, 0:Acquisition, 1:DelayedTask
                ThClearDay = 0  # Number of stream days where criteria threshold is achieved
                NumOfDelayID = 1
                for i in range(9):
                    if i == 1:
                        if Delay1Var.get() != '':  # If delay is designated
                            NumOfDelayID += 1
                        if Delay1Var.get() == '':  # If delay is not designated
                            break
                    if i == 2:
                        if Delay2Var.get() != '':  # If delay is designated
                            NumOfDelayID += 1
                        if Delay2Var.get() == '':  # If delay is not designated
                            break
                    if i == 3:
                        if Delay3Var.get() != '':  # If delay is designated
                            NumOfDelayID += 1
                        if Delay3Var.get() == '':  # If delay is not designated
                            break
                    if i == 4:
                        if Delay4Var.get() != '':  # If delay is designated
                            NumOfDelayID += 1
                        if Delay4Var.get() == '':  # If delay is not designated
                            break
                    if i == 5:
                        if Delay5Var.get() != '':  # If delay is designated
                            NumOfDelayID += 1
                        if Delay5Var.get() == '':  # If delay is not designated
                            break
                    if i == 6:
                        if Delay6Var.get() != '':  # If delay is designated
                            NumOfDelayID += 1
                        if Delay6Var.get() == '':  # If delay is not designated
                            break
                    if i == 7:
                        if Delay7Var.get() != '':  # If delay is designated
                            NumOfDelayID += 1
                        if Delay7Var.get() == '':  # If delay is not designated
                            break
                    if i == 8:
                        if Delay8Var.get() != '':  # If delay is designated
                            NumOfDelayID += 1
                        if Delay8Var.get() == '':  # If delay is not designated
                            break
                    if i == 9:
                        if Delay9Var.get() != '':  # If delay is designated
                            NumOfDelayID += 1
                        if Delay9Var.get() == '':  # If delay is not designated
                            break
                print('Num of delays: ' + str(NumOfDelayID))

                Phase1_Init = 1
            mStatusVar.set('DNMS/DMS task (' + str(Task) + ')    Waiting...')
            if IsStartTime() == 1:  # If task start time is arrived
                StartNow()
        if Phase == 2:  # During task
            if Phase2_Init == 0:  # Initialization of the task
                PutEndTaskNowButton()

                mStatusVar.set(
                    'DNMS/DMS task (' + str(Task) + ')    Start time ' + str(TaskStartedMonth) + '/' + str(TaskStartedDay) + ' ' + str(TaskStartedHour) + ':' + str(TaskStartedMinute) + '    Running')
                mOngoingResult = ttk.Label(MainWindowRightFrame, textvariable=mOngoingResultVar)
                mOngoingResult.place(x=10, y=18)

                # Convert StringVars of parameters into integer or normal string to use in the following
                MaxCorrectNum = int(MaxCorrectNumVar.get())
                MaxTrialNum = int(MaxTrialNumVar.get())
                TimeLimit = int(TimeLimitVar.get())
                PunishDur = int(PunishDurVar.get())
                LickDur = int(LickDurVar.get())
                Iti = int(ItiVar.get())
                AwsOn = AwsOnVar.get()
                DelayAllowFactor = int(DelayAllowFactorVar.get())
                RateTh = int(RateThVar.get())
                DayTh = int(DayThVar.get())
                StartSession = int(StartSessionVar.get())
                Seed = int(SeedVar.get())
                NextTask = int(NextTaskVar.get())
                TaskType = TaskTypeVar.get()
                WaterCueType = WaterCueTypeVar.get()
                PunishWithLight = PunishWithLightVar.get()

                PresetDelay = [0 for i in range(10)]
                if Delay0Var.get() != "":
                    PresetDelay[0] = int(Delay0Var.get())
                if Delay1Var.get() != "":
                    PresetDelay[1] = int(Delay1Var.get())
                if Delay2Var.get() != "":
                    PresetDelay[2] = int(Delay2Var.get())
                if Delay3Var.get() != "":
                    PresetDelay[3] = int(Delay3Var.get())
                if Delay4Var.get() != "":
                    PresetDelay[4] = int(Delay4Var.get())
                if Delay5Var.get() != "":
                    PresetDelay[5] = int(Delay5Var.get())
                if Delay6Var.get() != "":
                    PresetDelay[6] = int(Delay6Var.get())
                if Delay7Var.get() != "":
                    PresetDelay[7] = int(Delay7Var.get())
                if Delay8Var.get() != "":
                    PresetDelay[8] = int(Delay8Var.get())
                if Delay9Var.get() != "":
                    PresetDelay[9] = int(Delay9Var.get())

                if SessionDelayID == 0:
                    DelayA = PresetDelay[SessionDelayID]
                    DelayB = PresetDelay[SessionDelayID]
                if SessionDelayID > 0:
                    DelayA = PresetDelay[SessionDelayID - 1]
                    DelayB = PresetDelay[SessionDelayID]

                StartLickRecording()
                RoofLightTurnOff()
                InfraredTurnOn()
                WaterCueTurnOn()
                WaterPosInside()
                CreateBlinkPanel(0)
                CreateBlinkPanel(1)  # tagg
                CreateNormalPanel(2)
                CreateNormalPanel(3)
                CreateNormalPanel(4)

                # MakeWaterCueBlink()  # Make water cue blink
                # MakeWaterCueNonBlink()

                # Declar local variables for this task
                CurrTrialNum = -1
                TotalCorrectNum = 0
                TrialNum = [0 for i in range(2)]
                CorrectNum = [0 for i in range(2)]
                IncorrectNum = [0 for i in range(2)]
                CorrectRate = [0 for i in range(2)]
                ValidCorrectNum = 0  # Correct touch num which have done within the designated delay
                ValidIncorrectNum = 0
                ValidTouchNum = 0
                ValidCorrectRate = 0  # Correct rate which have done within the designated delay
                TouchHistory = [[-1 for i in range(5)] for j in
                    range(MaxTrialNum)]  # Keeps history of touch results and time of touching (For valid trial selection) p0:CorrectPanelID p1:DelayStartTime p2:DelayEndTime p3:Result p4:DelayRand
                DelayHistory = [-1 for i in range(MaxTrialNum)]  # Keeps delay history
                ValidString = ['', '']

                DuringTask = 1
                DoneCorrectResponse = 1
                NowDrinking = 0
                AWS_Latency = 20
                StartRecording()  # Start camera capturing and sending of TTL
                print('Seed: ' + str(Seed))
                random.seed(Seed)
                TtlStart()
                Timer_Start(5)  # Task time limit timer start
                Phase2 = 8
                Phase2_Init = 1

                Writer_TouchEventTxt = open(
                    Path + "/" + str(TimeNow.year) + "_" + str(TimeNow.month) + "_" + str(TimeNow.day) + " " + str(TimeNow.hour) + "h" + str(TimeNow.minute) + "m Task" + str(Task) + " Touch.txt",
                    'w')  # Initialize the text exporter
                Writer_TouchEventCsv = open(
                    Path + "/" + str(TimeNow.year) + "_" + str(TimeNow.month) + "_" + str(TimeNow.day) + " " + str(TimeNow.hour) + "h" + str(TimeNow.minute) + "m Task" + str(Task) + " Touch.csv",
                    'w')  # Initialize the text exporter
                Writer_TouchEventTxt.write('TrialNum\tResult\tPanel\tyyyy/mm/dd\th:m\ts\n')  # Write item name
                print("Task #" + str(Task) + " is started at " + str(GetTaskStartedMonth()) + '/' + str(GetTaskStartedDay()) + ' ' + str(GetTaskStartedHour()) + ':' + str(
                    GetTaskStartedMinute()) + ':' + str(GetTaskStartedSecond()))

            if Phase2 == 0:  # Initiation of new trial tagg
                DoneCorrectResponse = 0
                CorrectPanelID = int(random.random() * 2)  # Determine which position is correct at random
                print('Trial: ' + str(CurrTrialNum))
                Trg = 0
                if CurrTrialNum <= 1:
                    TouchHistory[CurrTrialNum][0] = CorrectPanelID
                if CurrTrialNum > 1:
                    if CorrectPanelID == TouchHistory[CurrTrialNum - 1][0] and CorrectPanelID == TouchHistory[CurrTrialNum - 2][0]:  # If Correct position is same as previous and pre-previous position
                        if CorrectPanelID == 0:
                            CorrectPanelID = 1  # Change correct position to the opposite side
                            Trg = 1
                        if CorrectPanelID == 1 and Trg == 0:
                            CorrectPanelID = 0  # Change correct position to the opposite side
                TouchHistory[CurrTrialNum][0] = CorrectPanelID
                if CorrectPanelID == 0:
                    ShowPanel(0)
                if CorrectPanelID == 1:
                    ShowPanel(1)
                Writer_TouchEventTxt.write(
                    str(CurrTrialNum + 1) + '\tCueStart\t' + str(CorrectPanelID) + '\t' + str(TimeNow.year) + "/" + str(TimeNow.month) + "/" + str(TimeNow.day) + "\t" + str(TimeNow.hour) + ":" + str(
                        TimeNow.minute) + "\t" + str(TimeNow.second) + "." + str(TimeNow.microsecond // 1000) + "\n")  # Write the response on the text file
                Writer_TouchEventCsv.write(
                    str(CurrTrialNum + 1) + ',0,' + str(CorrectPanelID) + ',' + str(TimeNow.year) + "," + str(TimeNow.month) + "," + str(TimeNow.day) + "," + str(TimeNow.hour) + "," + str(
                        TimeNow.minute) + "," + str(TimeNow.second) + "." + str(TimeNow.microsecond // 1000) + "\n")  # Write the response on the csv file
                Timer_Start(0)  # Start the latency timer
                Phase2 = 1

            if Phase2 == 1:  # Sample panel presentation phase
                TouchedPanelID = DetectPanelTouch()  # Check which panel is touched (return panel ID. If none of the panels touched, return -1)
                if TouchedPanelID == CorrectPanelID:  # If mouse touches CORRECT panel
                    DoneCorrectResponse = 1

                    NowDrinking = 0
                    Writer_TouchEventTxt.write(
                        str(CurrTrialNum + 1) + '\tCueCorrectTouch\t' + str(CorrectPanelID) + '\t' + str(TimeNow.year) + "/" + str(TimeNow.month) + "/" + str(TimeNow.day) + "\t" + str(
                            TimeNow.hour) + ":" + str(TimeNow.minute) + "\t" + str(TimeNow.second) + "." + str(TimeNow.microsecond // 1000) + "\n")  # Write the response on the text file
                    Writer_TouchEventCsv.write(
                        str(CurrTrialNum + 1) + ',1,' + str(CorrectPanelID) + ',' + str(TimeNow.year) + "," + str(TimeNow.month) + "," + str(TimeNow.day) + "," + str(TimeNow.hour) + "," + str(
                            TimeNow.minute) + "," + str(TimeNow.second) + "." + str(TimeNow.microsecond // 1000) + "\n")  # Write the response on the csv file
                    HidePanel(0)
                    HidePanel(1)
                    Timer_End(0)

                    DelayRand = int(random.random() * 2)
                    Trg = 0
                    if CurrTrialNum > 1:
                        if DelayRand == DelayHistory[CurrTrialNum - 1] and DelayRand == DelayHistory[CurrTrialNum - 2]:  # If Correct position is same as previous and pre-previous position
                            if DelayRand == 0:
                                DelayRand = 1  # Change correct position to the opposite side
                                Trg = 1
                            if DelayRand == 1 and Trg == 0:
                                DelayRand = 0  # Change correct position to the opposite side
                    DelayHistory[CurrTrialNum] = DelayRand  # Enter to the history
                    if DelayRand == 0:
                        DelayDur = DelayA  # If this trial is DelayA
                    if DelayRand == 1:
                        DelayDur = DelayB  # If this trial is DelayB
                    AllowedDelay = 10 + (DelayDur * DelayAllowFactor / 100)  # Caliculate threshold for data selection
                    # print(AllowedDelay)
                    Phase2 = 2  # Go to interval
                    Timer_Start(0)

                if GetTimerSec(5) >= TimeLimit * 60:  # If time limit is exceeded
                    Timer_End(5)
                    Phase2 = 12

            if Phase2 == 2:  # Interval between sample touch and 1st center presentation
                # print(GetTimerSec(0))
                if GetTimerSec(0) >= 1:
                    ShowPanel(2)  # Show 1st center panel
                    Phase2 = 3

            if Phase2 == 3:  # 1st center panel presentation phase
                TouchedPanelID = DetectPanelTouch()  # Check which panel is touched (return panel ID. If none of the panels touched, return -1)
                if TouchedPanelID == 2:  # If mouse touches 1st center panel
                    DoneCorrectResponse = 1

                    NowDrinking = 0
                    TouchHistory[CurrTrialNum][1] = (TimeNow.hour * 60 * 60) + (TimeNow.minute * 60) + TimeNow.second
                    Writer_TouchEventTxt.write(
                        str(CurrTrialNum + 1) + '\t1stCenterCorrectTouch\t' + str(TouchedPanelID) + '\t' + str(TimeNow.year) + "/" + str(TimeNow.month) + "/" + str(TimeNow.day) + "\t" + str(
                            TimeNow.hour) + ":" + str(TimeNow.minute) + "\t" + str(TimeNow.second) + "." + str(TimeNow.microsecond // 1000) + "\n")  # Write the response on the text file
                    Writer_TouchEventCsv.write(
                        str(CurrTrialNum + 1) + ',2,' + str(TouchedPanelID) + ',' + str(TimeNow.year) + "," + str(TimeNow.month) + "," + str(TimeNow.day) + "," + str(TimeNow.hour) + "," + str(
                            TimeNow.minute) + "," + str(TimeNow.second) + "." + str(TimeNow.microsecond // 1000) + "\n")  # Write the response on the csv file
                    HidePanel(2)
                    Timer_End(0)
                    Phase2 = 4  # Start reward phase
                    Timer_Start(0)
                if GetTimerSec(5) >= TimeLimit * 60:  # If time limit is exceeded
                    Timer_End(5)
                    Phase2 = 12

            if Phase2 == 4:  # Interval between sample touch and 1st center presentation
                if GetTimerSec(0) >= DelayDur:
                    ShowPanel(2)  # Show 1st center panel
                    Phase2 = 5

            if Phase2 == 5:  # 2nd center panel presentation phase
                TouchedPanelID = DetectPanelTouch()  # Check which panel is touched (return panel ID. If none of the panels touched, return -1)
                if TouchedPanelID == 2:  # If mouse touches 1st center panel
                    DoneCorrectResponse = 1

                    NowDrinking = 0
                    Writer_TouchEventTxt.write(
                        str(CurrTrialNum + 1) + '\t2ndCenterCorrectTouch\t' + str(TouchedPanelID) + '\t' + str(TimeNow.year) + "/" + str(TimeNow.month) + "/" + str(TimeNow.day) + "\t" + str(
                            TimeNow.hour) + ":" + str(TimeNow.minute) + "\t" + str(TimeNow.second) + "." + str(TimeNow.microsecond // 1000) + "\t" + str(
                            DelayDur) + "\n")  # Write the response on the text file
                    Writer_TouchEventCsv.write(
                        str(CurrTrialNum + 1) + ',3,' + str(TouchedPanelID) + ',' + str(TimeNow.year) + "," + str(TimeNow.month) + "," + str(TimeNow.day) + "," + str(TimeNow.hour) + "," + str(
                            TimeNow.minute) + "," + str(TimeNow.second) + "." + str(TimeNow.microsecond // 1000) + "," + str(DelayDur) + "\n")  # Write the response on the csv file
                    HidePanel(2)
                    Timer_End(0)
                    Phase2 = 6  # Start reward phase
                    Timer_Start(0)
                if GetTimerSec(5) >= TimeLimit * 60:  # If time limit is exceeded
                    Timer_End(5)
                    Phase2 = 12

            if Phase2 == 6:  # Interval between sample touch and 1st center presentation
                if GetTimerSec(0) >= 1:
                    if CorrectPanelID == 0:
                        if TaskType == 'DNMS1':
                            ShowPanel(4)  #
                        if TaskType == 'DMS1':
                            ShowPanel(3)  #
                        if TaskType == 'DNMS2' or TaskType == 'DMS2':
                            ShowPanel(3)  #
                            ShowPanel(4)  #
                    if CorrectPanelID == 1:
                        if TaskType == 'DNMS1':
                            ShowPanel(3)  #
                        if TaskType == 'DMS1':
                            ShowPanel(4)  #
                        if TaskType == 'DNMS2' or TaskType == 'DMS2':
                            ShowPanel(3)  #
                            ShowPanel(4)  #
                    Phase2 = 7

            if Phase2 == 7:  # Choice phase
                TouchedPanelID = DetectPanelTouch()  # Check which panel is touched (return panel ID. If none of the panels touched, return -1)
                if TouchedPanelID != -1:
                    TouchResult = 0
                    if TaskType == 'DMS1' or TaskType == 'DMS2':
                        if TouchedPanelID == CorrectPanelID or TouchedPanelID == CorrectPanelID + 3:  # If mouse touches same position with the sample phase
                            TouchResult = 1  # Correct
                        if TouchedPanelID != CorrectPanelID and TouchedPanelID != CorrectPanelID + 3 and TouchedPanelID != 2:  # If mouse touches opposite position to the sample phase
                            TouchResult = -1  # Wrong
                    if TaskType == 'DNMS1' or TaskType == 'DNMS2':
                        if TouchedPanelID != CorrectPanelID and TouchedPanelID != CorrectPanelID + 3 and TouchedPanelID != 2:  # If mouse touches opposite position to the sample phase
                            TouchResult = 1  # Correct

                        if TouchedPanelID == CorrectPanelID or TouchedPanelID == CorrectPanelID + 3:  # If mouse touches same position with the sample phase
                            TouchResult = -1  # Wrong
                    if TouchResult == 1:  # If mouse touches correct panel
                        DoneCorrectResponse = 1
                        NowDrinking = 0
                        TouchHistory[CurrTrialNum][2] = (TimeNow.hour * 60 * 60) + (TimeNow.minute * 60) + TimeNow.second
                        TouchHistory[CurrTrialNum][3] = 1
                        TouchHistory[CurrTrialNum][4] = DelayRand
                        TrialNum[DelayRand] += 1
                        CorrectNum[DelayRand] += 1  # Increase the number of correct respon
                        TotalCorrectNum += 1
                        CorrectRate[DelayRand] = round(CorrectNum[DelayRand] * 100.0 / TrialNum[DelayRand], 2)
                        Writer_TouchEventTxt.write(
                            str(CurrTrialNum) + '\tTestCorrectTouch\t' + str(TouchedPanelID) + '\t' + str(TimeNow.year) + "/" + str(TimeNow.month) + "/" + str(TimeNow.day) + "\t" + str(
                                TimeNow.hour) + ":" + str(TimeNow.minute) + "\t" + str(TimeNow.second) + "." + str(TimeNow.microsecond // 1000) + "\t" + str(DelayDur) + "\t" + str(
                                DelayRand) + "\n")  # Write the response on the text file
                        Writer_TouchEventCsv.write(
                            str(CurrTrialNum) + ',4,' + str(TouchedPanelID) + ',' + str(TimeNow.year) + "," + str(TimeNow.month) + "," + str(TimeNow.day) + "," + str(TimeNow.hour) + "," + str(
                                TimeNow.minute) + "," + str(TimeNow.second) + "." + str(TimeNow.microsecond // 1000) + "," + str(DelayDur) + "," + str(
                                DelayRand) + "\n")  # Write the response on the csv file
                        HidePanel(3)
                        HidePanel(4)
                        Timer_End(0)
                        WaterCueTurnOn()
                        WaterPosInside()
                        Phase2 = 8  # Go to reward phase

                    if TouchResult == -1:  # If mouse touches wrong panel
                        DoneCorrectResponse = 0
                        NowDrinking = 0
                        TouchHistory[CurrTrialNum][2] = (TimeNow.hour * 60 * 60) + (TimeNow.minute * 60) + TimeNow.second
                        TouchHistory[CurrTrialNum][3] = 0
                        TouchHistory[CurrTrialNum][4] = DelayRand
                        TrialNum[DelayRand] += 1
                        IncorrectNum[DelayRand] += 1  # Increase the number of correct response
                        CorrectRate[DelayRand] = round(CorrectNum[DelayRand] * 100.0 / TrialNum[DelayRand], 2)
                        Writer_TouchEventTxt.write(
                            str(CurrTrialNum + 1) + '\tTestIncorrectTouch\t' + str(TouchedPanelID) + '\t' + str(TimeNow.year) + "/" + str(TimeNow.month) + "/" + str(TimeNow.day) + "\t" + str(
                                TimeNow.hour) + ":" + str(TimeNow.minute) + "\t" + str(TimeNow.second) + "." + str(TimeNow.microsecond // 1000) + "\t" + str(DelayDur) + "\t" + str(
                                DelayRand) + "\n")  # Write the response on the text file
                        Writer_TouchEventCsv.write(
                            str(CurrTrialNum + 1) + ',5,' + str(TouchedPanelID) + ',' + str(TimeNow.year) + "," + str(TimeNow.month) + "," + str(TimeNow.day) + "," + str(TimeNow.hour) + "," + str(
                                TimeNow.minute) + "," + str(TimeNow.second) + "." + str(TimeNow.microsecond // 1000) + "," + str(DelayDur) + "," + str(
                                DelayRand) + "\n")  # Write the response on the csv file
                        HidePanel(3)
                        HidePanel(4)
                        Timer_End(0)
                        if PunishWithLight == 'ON':
                            RoofLightTurnOn()  # Turn on roof light
                        WaterPosOutside()
                        Phase2 = 8  # Start reward phase
                        Timer_Start(0)

                if GetTimerSec(5) >= TimeLimit * 60:  # If time limit is exceeded
                    Timer_End(5)
                    Phase2 = 12

            if Phase2 == 8:
                for i2 in range(2):
                    # Caliculate valid score
                    ValidTouchNum = 0
                    ValidCorrectNum = 0
                    ValidIncorrectNum = 0
                    for i in range(CurrTrialNum + 1):  # Loop for trials
                        if TouchHistory[i][2] == -1:  # If this trial is not completed
                            break
                        if TouchHistory[i][4] == i2:  # If this trial is completed
                            if TouchHistory[i][2] != -1:  # If this trial is completed
                                ActualDelay = TouchHistory[i][2] - TouchHistory[i][1]
                                if ActualDelay <= AllowedDelay:
                                    ValidTouchNum += 1
                                    if TouchHistory[i][3] == 1:
                                        ValidCorrectNum += 1
                                    if TouchHistory[i][3] == 0:
                                        ValidIncorrectNum += 1
                    if ValidTouchNum > 0:
                        ValidCorrectRate = round(ValidCorrectNum / ValidTouchNum * 100, 1)
                        ValidString[i2] = '  /  ValidCorrect:' + str(ValidCorrectNum) + '  ValidWrong:' + str(ValidIncorrectNum) + '  ValidTotalNum:' + str(ValidTouchNum) + '  ValidCorrect:' + str(
                            ValidCorrectRate) + '%'
                ResultStringA = 'Delay ' + str(DelayA) + 's : CorrectNum:' + str(CorrectNum[0]) + '  IncorrectNum:' + str(IncorrectNum[0]) + '  TrialNum:' + str(TrialNum[0]) + '  Correct:' + str(
                    CorrectRate[0]) + '%' + ValidString[0]
                ResultStringB = 'Delay ' + str(DelayB) + 's : CorrectNum:' + str(CorrectNum[1]) + '  IncorrectNum:' + str(IncorrectNum[1]) + '  TrialNum:' + str(TrialNum[1]) + '  Correct:' + str(
                    CorrectRate[1]) + '%' + ValidString[1]
                mOngoingResultVar.set(ResultStringA + '\n' + ResultStringB)
                if DoneCorrectResponse == 1:
                    Phase2 = 9
                if DoneCorrectResponse == 0:
                    Phase2 = 10

            if Phase2 == 9:  # Reward phase
                if NosePoking == 1 and NowDrinking == 0:  # If the mouse initiates nose poke
                    NowDrinking = 1
                    Timer_Start(0)  # Start lick timer
                if NowDrinking == 1:
                    if DoneCorrectResponse == 1 and GetTimerSec(0) >= LickDur:  # If lick time exceed the designated time
                        Timer_End(0)  # End lick timer
                        WaterPosMiddle()  # Move water nozzle to the intermediate position
                        WaterCueTurnOff()
                        NowDrinking = 0
                        Timer_Start(0)  # Start ITI timer
                        Phase2 = 11  # Go to ITI

            if Phase2 == 10:  # Punishment phase
                if GetTimerSec(0) >= PunishDur:  # If punishment time is passed
                    RoofLightTurnOff()
                    WaterPosMiddle()  # Move water nozzle to the intermediate position
                    Timer_End(0)  # End punishment timer1
                    Timer_Start(0)  # Start ITI timer
                    Phase2 = 11  # Go to ITI

            if Phase2 == 11:  # ITI
                if GetTimerSec(0) >= Iti:  # If ITI is passed
                    if TotalCorrectNum >= MaxCorrectNum or CurrTrialNum >= MaxTrialNum - 1:  # If mouse achieved criteria of finishing the task
                        Timer_End(5)
                        WaterPosMiddle()
                        WaterCueTurnOff()
                        Timer_Start(0)  # Timer for interval between task and arbitary water supply is started
                        Phase2 = 12  # Go to the AWS
                    else:
                        CurrTrialNum += 1
                        Phase2 = 0  # Go to the next trial

            if Phase2 == 12:  # End session
                HidePanel(0)
                HidePanel(1)
                HidePanel(2)
                HidePanel(3)
                HidePanel(4)
                if TotalCorrectNum < MaxCorrectNum and AwsOn == 'ON':  # If mouse didn't achieved the max correct response
                    Timer_Start(0)
                    Phase2 = 13
                if TotalCorrectNum == MaxCorrectNum or AwsOn == 'OFF':  # If mouse achieved the max correct response
                    Phase2 = -1

            if Phase2 == 13:  # Wait until arbitary water suuply is started
                if GetTimerSec(0) >= 20:  # If the interval is past 20
                    Timer_End(0)
                    ArbitaryWaterSupplyDur = (MaxCorrectNum - TotalCorrectNum) * LickDur * 1000  # Caliculate duration of complement water supply
                    StartArbitaryWaterSupply(ArbitaryWaterSupplyDur)  # Start complement water supply
                    print("AWSstart")
                    Phase2 = 14
            if Phase2 == 14:
                if GetArbitaryWaterSupplyStat() == 1:  # If complement water supply is finished
                    Phase2 = -1

            if Phase2 == -1 or Phase2 == -2:  # Task finish phase
                DuringTask = 0
                WaterPosMiddle()
                ClearPanel()
                MakeWaterCueNonBlink()
                InfraredTurnOff()
                if NowRecording == 1:
                    SetEndRecordingTimer(60)

                if CurrTrialNum > 0:
                    Writer_TouchEventTxt.write(ResultStringA + '\n' + ResultStringB + '\n')  # Summary of results
                Writer_TouchEventTxt.write(
                    'TaskStartTime: ' + str(GetTaskStartedMonth()) + '/' + str(GetTaskStartedDay()) + ' ' + str(GetTaskStartedHour()) + ':' + str(GetTaskStartedMinute()) + ':' + str(
                        GetTaskStartedSecond()) + "\n")
                Writer_TouchEventTxt.write('TaskEndTime: ' + str(TimeNow.month) + '/' + str(TimeNow.day) + ' ' + str(TimeNow.hour) + ':' + str(TimeNow.minute) + ':' + str(
                    TimeNow.second + (TimeNow.microsecond // 1000) / 1000) + "\n")
                Writer_TouchEventTxt.write('DelayA: ' + str(DelayA) + " sec\n")
                Writer_TouchEventTxt.write('DelayB: ' + str(DelayB) + " sec\n")
                Writer_TouchEventTxt.write('MaxCorrectNum: ' + str(MaxCorrectNum) + "\n")
                Writer_TouchEventTxt.write('MaxTrialNum: ' + str(MaxTrialNum) + "\n")
                Writer_TouchEventTxt.write('TimeLimit: ' + str(TimeLimit) + " min\n")
                Writer_TouchEventTxt.write('PunishDur: ' + str(PunishDur) + " sec\n")
                Writer_TouchEventTxt.write('LickDur: ' + str(LickDur) + " sec\n")
                Writer_TouchEventTxt.write('Iti: ' + str(Iti) + " sec\n")
                Writer_TouchEventTxt.write('ValidDelay%: ' + str(DelayAllowFactor) + " %\n")
                Writer_TouchEventTxt.write('RateTh: ' + str(RateTh) + " %\n")
                Writer_TouchEventTxt.write('DayTh: ' + str(DayTh) + " day\n")
                Writer_TouchEventTxt.write('Seed: ' + str(Seed) + "\n")
                Writer_TouchEventTxt.write('NextTask: ' + str(NextTask) + "\n")
                Writer_TouchEventTxt.write('TaskType: ' + str(TaskType) + "\n")
                Writer_TouchEventTxt.write('WaterCueType: ' + str(WaterCueType) + "\n")
                Writer_TouchEventTxt.write('PunishWithLight: ' + str(PunishWithLight) + "\n")
                Writer_TouchEventTxt.write('RecordFPS: ' + str(RecordFPS) + "\n")
                Writer_TouchEventTxt.write('AWS: ' + AwsOn + "\n")
                Writer_TouchEventTxt.write('AWS_Latency: ' + str(AWS_Latency) + "\n")

                Writer_TouchEventTxt.close()
                Writer_TouchEventCsv.close()
                EndLickRecording()

                SendMail(DeviceNameVar.get() + ' finished task ' + str(Task) + '.' + ResultStringA + ';  ' + ResultStringB + ';  Dur:' + str(round(GetTimerSec(5) / 60, 1)) + ' min',
                    'Task is finished.')
                TtlDelayStop()

                if IsHousingAnalysis == 1:  #
                    SeedVar.set(Seed + 1)
                    # Update condition of experiment
                    if LearningPhase == 0:  # If it is acquisition phase
                        TotalCorrectRate = (CorrectNum[0] + CorrectNum[1]) * 100 / (TrialNum[0] + TrialNum[1])
                        if CurrTrialNum != 0:
                            if TotalCorrectRate >= RateTh:  # If correct rate excceeded the criteria
                                ThClearDay += 1  # Increase the criteria counter
                                print("Current cleared stream days:" + str(ThClearDay))
                                if ThClearDay >= DayTh:  # If acquisition is completed
                                    LearningPhase = 1  # Go to the delayed phase
                                    print("Delayed phase is started")
                        if TotalCorrectRate < RateTh:  # If correct rate belowed the criteria
                            ThClearDay = 0  # Reset the criteria counter
                    if LearningPhase == 1:  # If it is delayed phase
                        SessionDelayID += 1  # Change delay
                        if SessionDelayID == 1:
                            print("Next delay is " + Delay0Var.get() + " sec / " + Delay1Var.get() + " sec")
                        if SessionDelayID == 2:
                            print("Next delay is " + Delay1Var.get() + " sec / " + Delay2Var.get() + " sec")
                        if SessionDelayID == 3:
                            print("Next delay is " + Delay2Var.get() + " sec / " + Delay3Var.get() + " sec")
                        if SessionDelayID == 4:
                            print("Next delay is " + Delay3Var.get() + " sec / " + Delay4Var.get() + " sec")
                        if SessionDelayID == 5:
                            print("Next delay is " + Delay4Var.get() + " sec / " + Delay5Var.get() + " sec")
                        if SessionDelayID == 6:
                            print("Next delay is " + Delay5Var.get() + " sec / " + Delay6Var.get() + " sec")
                        if SessionDelayID == 7:
                            print("Next delay is " + Delay6Var.get() + " sec / " + Delay7Var.get() + " sec")
                        if SessionDelayID == 8:
                            print("Next delay is " + Delay7Var.get() + " sec / " + Delay8Var.get() + " sec")
                        if SessionDelayID == 9:
                            print("Next delay is " + Delay8Var.get() + " sec / " + Delay9Var.get() + " sec")
                        if Phase2 == -1:
                            if SessionDelayID > NumOfDelayID - 1:  # If the last delayed session is finished (This task is completed)
                                SwitchTask(NextTask)  # Onset task switch trigger
                                print("Task is switched to task#" + str(NextTask) + "  " + str(GetTaskStartedMonth()) + '/' + str(GetTaskStartedDay()) + ' ' + str(GetTaskStartedHour()) + ':' + str(
                                    GetTaskStartedMinute()) + ':' + str(GetTaskStartedSecond()))

                if IsHousingAnalysis == 0:
                    RoofLightTurnOn()

                Phase = 1  # Go back to the task-waiting phase
                Phase2 = 0
                Phase2_Init = 0
    return

def Task23():   # DNMS
    global Phase, Phase2, Init, Task, SaveTrg, LoadTrg, NosePoking, DuringTask, NowRecording, RecordFPS
    Task = 23
    Phase0_Init=0
    Phase1_Init=0
    Phase2_Init=0
    while EndFlag==0:
        OperantHouseUpdate()
        if Phase == -1:  # Back to the task select phase
            Phase = 0
            Task = 0
            break
        if Phase == 0:  # Parameter inputs
            if Phase0_Init == 0:
                LoadTrg = 1
                # Make GUI for the setting of the parameters for this task
                RemoveMainRightWidget() # Remove task buttons

                PutStartBackButton()    # Put start/back buttons

                EntryWidth=80   # Width of entry field
                GridX = 0  # Upper left X coordination of grids
                GridY = 0   # Upper left Y coordination of grids
                GridWidth=100   # Width of grids
                GridHeight=25   # Height of grids

                Row = 0 # Current row of grid
                Line = 0 # Current line of grid
                mMaxCorrectNum = ttk.Label(MainWindowRightFrame, text='MaxCorrect') # Make label
                mMaxCorrectNum.place(x=GridX + Row * GridWidth, y=GridY + Line * GridHeight, width=EntryWidth)    # Put label
                MaxCorrectNumVar = IntVar(MainWindowRoot)  # Declare variable receiving value from the entry field
                iMaxCorrectNum = ttk.Entry(MainWindowRightFrame, textvariable=MaxCorrectNumVar) # Make entry field
                iMaxCorrectNum.place(x=GridX + Row * GridWidth, y=GridY + (Line+1) * GridHeight-3, width=EntryWidth)  # Place entry field
                Row+=1  # Shift row
                mMaxTrialNum = ttk.Label(MainWindowRightFrame, text='MaxTrial')
                mMaxTrialNum.place(x=GridX + Row * GridWidth, y=GridY + Line * GridHeight, width=EntryWidth)  # Put label
                MaxTrialNumVar = IntVar(MainWindowRoot)  # Declare variable receiving value from the entry field
                iMaxTrialNum = ttk.Entry(MainWindowRightFrame, textvariable=MaxTrialNumVar)
                iMaxTrialNum.place(x=GridX + Row * GridWidth, y=GridY + (Line + 1) * GridHeight-3, width=EntryWidth)  # Place entry field
                Row += 1  # Shift row
                mTimeLimit = ttk.Label(MainWindowRightFrame, text='TimeLimit(m)')
                mTimeLimit.place(x=GridX + Row * GridWidth, y=GridY + Line * GridHeight, width=EntryWidth)  # Put label
                TimeLimitVar = IntVar(MainWindowRoot)  # Declare variable receiving value from the entry field
                iTimeLimit = ttk.Entry(MainWindowRightFrame, textvariable=TimeLimitVar)
                iTimeLimit.place(x=GridX + Row * GridWidth, y=GridY + (Line + 1) * GridHeight-3, width=EntryWidth)  # Place entry field
                Row += 1  # Shift row
                mPunishDur = ttk.Label(MainWindowRightFrame, text='PunishDur(s)')
                mPunishDur.place(x=GridX + Row * GridWidth, y=GridY + Line * GridHeight, width=EntryWidth)  # Put label
                PunishDurVar = IntVar(MainWindowRoot)  # Declare variable receiving value from the entry field
                iPunishDur = ttk.Entry(MainWindowRightFrame, textvariable=PunishDurVar)
                iPunishDur.place(x=GridX + Row * GridWidth, y=GridY + (Line + 1) * GridHeight-3, width=EntryWidth)  # Place entry field
                Row += 1  # Shift row
                mLickDur = ttk.Label(MainWindowRightFrame, text='LickDur(s)')
                mLickDur.place(x=GridX + Row * GridWidth, y=GridY + Line * GridHeight, width=EntryWidth)  # Put label
                LickDurVar = IntVar(MainWindowRoot)  # Declare variable receiving value from the entry field
                iLickDur = ttk.Entry(MainWindowRightFrame, textvariable=LickDurVar)
                iLickDur.place(x=GridX + Row * GridWidth, y=GridY + (Line + 1) * GridHeight-3, width=EntryWidth)  # Place entry field
                Row += 1  # Shift row
                mIti = ttk.Label(MainWindowRightFrame, text='ITI(s)')
                mIti.place(x=GridX + Row * GridWidth, y=GridY + Line * GridHeight, width=EntryWidth)  # Put label
                ItiVar = IntVar(MainWindowRoot)  # Declare variable receiving value from the entry field
                iIti = ttk.Entry(MainWindowRightFrame, textvariable=ItiVar)
                iIti.place(x=GridX + Row * GridWidth, y=GridY + (Line + 1) * GridHeight - 3, width=EntryWidth)  # Place entry field
                Row += 1  # Shift row
                mDelayAllowFactor = ttk.Label(MainWindowRightFrame, text='ValidDelay%')
                mDelayAllowFactor.place(x=GridX + Row * GridWidth, y=GridY + Line * GridHeight, width=EntryWidth)  # Put label
                DelayAllowFactorVar = IntVar(MainWindowRoot)  # Declare variable receiving value from the entry field
                iDelayAllowFactor = ttk.Entry(MainWindowRightFrame, textvariable=DelayAllowFactorVar)
                iDelayAllowFactor.place(x=GridX + Row * GridWidth, y=GridY + (Line + 1) * GridHeight - 3, width=EntryWidth)  # Place entry field
                Row += 1  # Shift row
                mRateTh = ttk.Label(MainWindowRightFrame, text='RateTh(%)')
                mRateTh.place(x=GridX + Row * GridWidth, y=GridY + Line * GridHeight, width=EntryWidth)  # Put label
                RateThVar = IntVar(MainWindowRoot)  # Declare variable receiving value from the entry field
                iRateTh = ttk.Entry(MainWindowRightFrame, textvariable=RateThVar)
                iRateTh.place(x=GridX + Row * GridWidth, y=GridY + (Line + 1) * GridHeight-3, width=EntryWidth)  # Place entry field
                Row += 1  # Shift row
                mDayTh = ttk.Label(MainWindowRightFrame, text='DayTh(d)')
                mDayTh.place(x=GridX + Row * GridWidth, y=GridY + Line * GridHeight, width=EntryWidth)  # Put label
                DayThVar = IntVar(MainWindowRoot)  # Declare variable receiving value from the entry field
                iDayTh = ttk.Entry(MainWindowRightFrame, textvariable=DayThVar)
                iDayTh.place(x=GridX + Row * GridWidth, y=GridY + (Line + 1) * GridHeight-3, width=EntryWidth)  # Place entry field
                Row += 1  # Shift row
                mStartSession = ttk.Label(MainWindowRightFrame, text='StartSession')
                mStartSession.place(x=GridX + Row * GridWidth, y=GridY + Line * GridHeight, width=EntryWidth)  # Put label
                StartSessionVar = IntVar(MainWindowRoot)  # Declare variable receiving value from the entry field
                iStartSession = ttk.Entry(MainWindowRightFrame, textvariable=StartSessionVar)
                iStartSession.place(x=GridX + Row * GridWidth, y=GridY + (Line + 1) * GridHeight-3, width=EntryWidth)  # Place entry field

                Row =0  # Shift row
                Line+=2 # Shift line

                mSeed = ttk.Label(MainWindowRightFrame, text='Seed')
                mSeed.place(x=GridX + Row * GridWidth, y=GridY + Line * GridHeight, width=EntryWidth)  # Put label
                SeedVar = IntVar(MainWindowRoot)  # Declare variable receiving value from the entry field
                iSeed = ttk.Entry(MainWindowRightFrame, textvariable=SeedVar)
                iSeed.place(x=GridX + Row * GridWidth, y=GridY + (Line + 1) * GridHeight - 3, width=EntryWidth)  # Place entry field
                Row += 1  # Shift row
                mNextTask = ttk.Label(MainWindowRightFrame, text='NextTask')
                mNextTask.place(x=GridX + Row * GridWidth, y=GridY + Line * GridHeight, width=EntryWidth)  # Put label
                NextTaskVar = IntVar(MainWindowRoot)  # Declare variable receiving value from the entry field
                iNextTask = ttk.Entry(MainWindowRightFrame, textvariable=NextTaskVar)
                iNextTask.place(x=GridX + Row * GridWidth, y=GridY + (Line + 1) * GridHeight - 3, width=EntryWidth)  # Place entry field
                Row += 1  # Shift row
                mTaskType = ttk.Label(MainWindowRightFrame, text='TaskType')
                mTaskType.place(x=GridX + Row * GridWidth, y=GridY + Line * GridHeight, width=EntryWidth)  # Put label
                TaskTypeVar = StringVar(MainWindowRoot)  # Declare variable receiving value from the entry field
                tTaskType = OptionMenu(MainWindowRightFrame, TaskTypeVar, "DNMS1", "DNMS2","DMS1","DMS2")
                tTaskType.place(x=GridX + Row * GridWidth, y=GridY + (Line + 1) * GridHeight - 7, width=EntryWidth)  # Place dropdown list
                Row += 1  # Shift row
                mWaterCueType = ttk.Label(MainWindowRightFrame, text='WaterCueType')
                mWaterCueType.place(x=GridX + Row * GridWidth, y=GridY + Line * GridHeight, width=EntryWidth)  # Put label
                WaterCueTypeVar = StringVar(MainWindowRoot)  # Declare variable receiving value from the entry field
                tWaterCueType = OptionMenu(MainWindowRightFrame, WaterCueTypeVar, "Normal", "Blink")
                tWaterCueType.place(x=GridX + Row * GridWidth, y=GridY + (Line + 1) * GridHeight-7, width=EntryWidth)  # Place dropdown list
                Row += 1  # Shift row
                mPunishWithLight = ttk.Label(MainWindowRightFrame, text='PunishLight')
                mPunishWithLight.place(x=GridX + Row * GridWidth, y=GridY + Line * GridHeight, width=EntryWidth)  # Put label
                PunishWithLightVar = StringVar(MainWindowRoot)  # Declare variable receiving value from the entry field
                tPunishWithLight = OptionMenu(MainWindowRightFrame, PunishWithLightVar, "ON", "OFF")
                tPunishWithLight.place(x=GridX + Row * GridWidth, y=GridY + (Line + 1) * GridHeight-7, width=EntryWidth)  # Place dropdown list
                Row += 1  # Shift row
                mAwsOn = ttk.Label(MainWindowRightFrame, text='AWS')
                mAwsOn.place(x=GridX + Row * GridWidth, y=GridY + Line * GridHeight, width=EntryWidth)  # Put label
                AwsOnVar = StringVar(MainWindowRoot)  # Declare variable receiving value from the entry field
                tAwsOn = OptionMenu(MainWindowRightFrame, AwsOnVar, "ON", "OFF")
                tAwsOn.place(x=GridX + Row * GridWidth, y=GridY + (Line + 1) * GridHeight - 7, width=EntryWidth)  # Place dropdown list
                Row = 0  # Shift row
                Line += 2  # Shift line
                mDelay0 = ttk.Label(MainWindowRightFrame, text='Delay0(sec)')
                mDelay0.place(x=GridX + Row * GridWidth, y=GridY + Line * GridHeight, width=EntryWidth)  # Put label
                Delay0Var = StringVar(MainWindowRoot)  # Declare variable receiving value from the entry field
                iDelay0 = ttk.Entry(MainWindowRightFrame, textvariable=Delay0Var)
                iDelay0.place(x=GridX + Row * GridWidth, y=GridY + (Line + 1) * GridHeight-3, width=EntryWidth)  # Place entry field
                Row += 1  # Shift row
                mDelay1 = ttk.Label(MainWindowRightFrame, text='Delay1(sec)')
                mDelay1.place(x=GridX + Row * GridWidth, y=GridY + Line * GridHeight, width=EntryWidth)  # Put label
                Delay1Var = StringVar(MainWindowRoot)  # Declare variable receiving value from the entry field
                iDelay1 = ttk.Entry(MainWindowRightFrame, textvariable=Delay1Var)
                iDelay1.place(x=GridX + Row * GridWidth, y=GridY + (Line + 1) * GridHeight-3, width=EntryWidth)  # Place entry field
                Row += 1  # Shift row
                mDelay2 = ttk.Label(MainWindowRightFrame, text='Delay2(sec)')
                mDelay2.place(x=GridX + Row * GridWidth, y=GridY + Line * GridHeight, width=EntryWidth)  # Put label
                Delay2Var = StringVar(MainWindowRoot)  # Declare variable receiving value from the entry field
                iDelay2 = ttk.Entry(MainWindowRightFrame, textvariable=Delay2Var)
                iDelay2.place(x=GridX + Row * GridWidth, y=GridY + (Line + 1) * GridHeight-3, width=EntryWidth)  # Place entry field
                Row += 1  # Shift row
                mDelay3 = ttk.Label(MainWindowRightFrame, text='Delay3(sec)')
                mDelay3.place(x=GridX + Row * GridWidth, y=GridY + Line * GridHeight, width=EntryWidth)  # Put label
                Delay3Var = StringVar(MainWindowRoot)  # Declare variable receiving value from the entry field
                iDelay3 = ttk.Entry(MainWindowRightFrame, textvariable=Delay3Var)
                iDelay3.place(x=GridX + Row * GridWidth, y=GridY + (Line + 1) * GridHeight-3, width=EntryWidth)  # Place entry field
                Row += 1  # Shift row
                mDelay4 = ttk.Label(MainWindowRightFrame, text='Delay4(sec)')
                mDelay4.place(x=GridX + Row * GridWidth, y=GridY + Line * GridHeight, width=EntryWidth)  # Put label
                Delay4Var = StringVar(MainWindowRoot)  # Declare variable receiving value from the entry field
                iDelay4 = ttk.Entry(MainWindowRightFrame, textvariable=Delay4Var)
                iDelay4.place(x=GridX + Row * GridWidth, y=GridY + (Line + 1) * GridHeight-3, width=EntryWidth)  # Place entry field
                Row += 1  # Shift row
                mDelay5 = ttk.Label(MainWindowRightFrame, text='Delay5(sec)')
                mDelay5.place(x=GridX + Row * GridWidth, y=GridY + Line * GridHeight, width=EntryWidth)  # Put label
                Delay5Var = StringVar(MainWindowRoot)  # Declare variable receiving value from the entry field
                iDelay5 = ttk.Entry(MainWindowRightFrame, textvariable=Delay5Var)
                iDelay5.place(x=GridX + Row * GridWidth, y=GridY + (Line + 1) * GridHeight-3, width=EntryWidth)  # Place entry field
                Row += 1  # Shift row
                mDelay6 = ttk.Label(MainWindowRightFrame, text='Delay6(sec)')
                mDelay6.place(x=GridX + Row * GridWidth, y=GridY + Line * GridHeight, width=EntryWidth)  # Put label
                Delay6Var = StringVar(MainWindowRoot)  # Declare variable receiving value from the entry field
                iDelay6 = ttk.Entry(MainWindowRightFrame, textvariable=Delay6Var)
                iDelay6.place(x=GridX + Row * GridWidth, y=GridY + (Line + 1) * GridHeight-3, width=EntryWidth)  # Place entry field
                Row += 1  # Shift row
                mDelay7 = ttk.Label(MainWindowRightFrame, text='Delay7(sec)')
                mDelay7.place(x=GridX + Row * GridWidth, y=GridY + Line * GridHeight, width=EntryWidth)  # Put label
                Delay7Var = StringVar(MainWindowRoot)  # Declare variable receiving value from the entry field
                iDelay7 = ttk.Entry(MainWindowRightFrame, textvariable=Delay7Var)
                iDelay7.place(x=GridX + Row * GridWidth, y=GridY + (Line + 1) * GridHeight-3, width=EntryWidth)  # Place entry field
                Row += 1  # Shift row
                mDelay8 = ttk.Label(MainWindowRightFrame, text='Delay8(sec)')
                mDelay8.place(x=GridX + Row * GridWidth, y=GridY + Line * GridHeight, width=EntryWidth)  # Put label
                Delay8Var = StringVar(MainWindowRoot)  # Declare variable receiving value from the entry field
                iDelay8 = ttk.Entry(MainWindowRightFrame, textvariable=Delay8Var)
                iDelay8.place(x=GridX + Row * GridWidth, y=GridY + (Line + 1) * GridHeight-3, width=EntryWidth)  # Place entry field
                Row += 1  # Shift row
                mDelay9 = ttk.Label(MainWindowRightFrame, text='Delay9(sec)')
                mDelay9.place(x=GridX + Row * GridWidth, y=GridY + Line * GridHeight, width=EntryWidth)  # Put label
                Delay9Var = StringVar(MainWindowRoot)  # Declare variable receiving value from the entry field
                iDelay9 = ttk.Entry(MainWindowRightFrame, textvariable=Delay9Var)
                iDelay9.place(x=GridX + Row * GridWidth, y=GridY + (Line + 1) * GridHeight-3, width=EntryWidth)  # Place entry field

                Phase0_Init = 1

        if LoadTrg == 1:  # If load trigger is on

            Str = "ParametersForTask" + str(Task)
            if os.path.exists(Str+'/MaxCorrectNum.dat') == True:  # If save file exists
                with open(Str+'/MaxCorrectNum.dat', 'rb') as PickleInst[Task]:
                    MaxCorrectNumVar.set(pickle.load(PickleInst[Task]))  # Load
            else:
                MaxCorrectNumVar.set(80)     # Default value

            if os.path.exists(Str+'/MaxTrialNum.dat') == True:  # If save file exists
                with open(Str+'/MaxTrialNum.dat', 'rb') as PickleInst[Task]:
                    MaxTrialNumVar.set(pickle.load(PickleInst[Task]))  # Load
            else:
                MaxTrialNumVar.set(999)     # Default value

            if os.path.exists(Str+'/TimeLimit.dat') == True:  # If save file exists
                with open(Str+'/TimeLimit.dat', 'rb') as PickleInst[Task]:
                    TimeLimitVar.set(pickle.load(PickleInst[Task]))  # Load
            else:
                TimeLimitVar.set(600)     # Default value

            if os.path.exists(Str+'/PunishDur.dat') == True:  # If save file exists
                with open(Str+'/PunishDur.dat', 'rb') as PickleInst[Task]:
                    PunishDurVar.set(pickle.load(PickleInst[Task]))  # Load
            else:
                PunishDurVar.set(10)     # Default value

            if os.path.exists(Str+'/LickDur.dat') == True:  # If save file exists
                with open(Str+'/LickDur.dat', 'rb') as PickleInst[Task]:
                    LickDurVar.set(pickle.load(PickleInst[Task]))  # Load
            else:
                LickDurVar.set(2)     # Default value

            if os.path.exists(Str+'/Iti.dat') == True:  # If save file exists
                with open(Str+'/Iti.dat', 'rb') as PickleInst[Task]:
                    ItiVar.set(pickle.load(PickleInst[Task]))  # Load
            else:
                ItiVar.set(20)     # Default value

            if os.path.exists(Str+'/DelayAllowFactor.dat') == True:  # If save file exists
                with open(Str+'/DelayAllowFactor.dat', 'rb') as PickleInst[Task]:
                    DelayAllowFactorVar.set(pickle.load(PickleInst[Task]))  # Load
            else:
                DelayAllowFactorVar.set(130)     # Default value

            if os.path.exists(Str+'/RateTh.dat') == True:  # If save file exists
                with open(Str+'/RateTh.dat', 'rb') as PickleInst[Task]:
                    RateThVar.set(pickle.load(PickleInst[Task]))  # Load
            else:
                RateThVar.set(80)     # Default value

            if os.path.exists(Str+'/DayTh.dat') == True:  # If save file exists
                with open(Str+'/DayTh.dat', 'rb') as PickleInst[Task]:
                    DayThVar.set(pickle.load(PickleInst[Task]))  # Load
            else:
                DayThVar.set(2)     # Default value

            if os.path.exists(Str+'/StartSession.dat') == True:  # If save file exists
                with open(Str+'/StartSession.dat', 'rb') as PickleInst[Task]:
                    StartSessionVar.set(pickle.load(PickleInst[Task]))  # Load
            else:
                NextTaskVar.set(23)     # Default value

            if os.path.exists(Str+'/Seed.dat') == True:  # If save file exists
                with open(Str+'/Seed.dat', 'rb') as PickleInst[Task]:
                    SeedVar.set(pickle.load(PickleInst[Task]))  # Load
            else:
                SeedVar.set(0)     # Default value
            if os.path.exists(Str+'/NextTask.dat') == True:  # If save file exists
                with open(Str+'/NextTask.dat', 'rb') as PickleInst[Task]:
                    NextTaskVar.set(pickle.load(PickleInst[Task]))  # Load
            else:
                NextTaskVar.set(23)     # Default value
            if os.path.exists(Str + '/TaskType.dat') == True:  # If save file exists
                with open(Str + '/TaskType.dat', 'rb') as PickleInst[Task]:
                    TaskTypeVar.set(pickle.load(PickleInst[Task]))  # Load
            else:
                TaskTypeVar.set('DNMS1')  # Default value

            if os.path.exists(Str+'/WaterCueType.dat') == True:  # If save file exists
                with open(Str+'/WaterCueType.dat', 'rb') as PickleInst[Task]:
                    WaterCueTypeVar.set(pickle.load(PickleInst[Task]))  # Load
            else:
                WaterCueTypeVar.set('Normal')     # Default value

            if os.path.exists(Str+'/PunishWithLight.dat') == True:  # If save file exists
                with open(Str+'/PunishWithLight.dat', 'rb') as PickleInst[Task]:
                    PunishWithLightVar.set(pickle.load(PickleInst[Task]))  # Load
            else:
                PunishWithLightVar.set('ON')     # Default value

            if os.path.exists(Str+'/Delay0.dat') == True:  # If save file exists
                with open(Str+'/Delay0.dat', 'rb') as PickleInst[Task]:
                    Delay0Var.set(pickle.load(PickleInst[Task]))  # Load
            else:
                Delay0Var.set('1')     # Default value
            if os.path.exists(Str+'/AwsOn.dat') == True:  # If save file exists
                with open(Str+'/AwsOn.dat', 'rb') as PickleInst[Task]:
                    AwsOnVar.set(pickle.load(PickleInst[Task]))  # Load
            else:
                AwsOnVar.set('ON')     # Default value
            if os.path.exists(Str+'/Delay1.dat') == True:  # If save file exists
                with open(Str+'/Delay1.dat', 'rb') as PickleInst[Task]:
                    Delay1Var.set(pickle.load(PickleInst[Task]))  # Load
            else:
                Delay1Var.set('2')     # Default value
            if os.path.exists(Str+'/Delay2.dat') == True:  # If save file exists
                with open(Str+'/Delay2.dat', 'rb') as PickleInst[Task]:
                    Delay2Var.set(pickle.load(PickleInst[Task]))  # Load
            else:
                Delay2Var.set('3')     # Default value
            if os.path.exists(Str + '/Delay3.dat') == True:  # If save file exists
                with open(Str + '/Delay3.dat', 'rb') as PickleInst[Task]:
                    Delay3Var.set(pickle.load(PickleInst[Task]))  # Load
            else:
                Delay3Var.set('5')  # Default value
            if os.path.exists(Str+'/Delay4.dat') == True:  # If save file exists
                with open(Str+'/Delay4.dat', 'rb') as PickleInst[Task]:
                    Delay4Var.set(pickle.load(PickleInst[Task]))  # Load
            else:
                Delay4Var.set('8')     # Default value
            if os.path.exists(Str+'/Delay5.dat') == True:  # If save file exists
                with open(Str+'/Delay5.dat', 'rb') as PickleInst[Task]:
                    Delay5Var.set(pickle.load(PickleInst[Task]))  # Load
            else:
                Delay5Var.set('12')     # Default value
            if os.path.exists(Str+'/Delay6.dat') == True:  # If save file exists
                with open(Str+'/Delay6.dat', 'rb') as PickleInst[Task]:
                    Delay6Var.set(pickle.load(PickleInst[Task]))  # Load
            else:
                Delay6Var.set('16')     # Default value
            if os.path.exists(Str+'/Delay7.dat') == True:  # If save file exists
                with open(Str+'/Delay7.dat', 'rb') as PickleInst[Task]:
                    Delay7Var.set(pickle.load(PickleInst[Task]))  # Load
            else:
                Delay7Var.set('20')     # Default value
            if os.path.exists(Str+'/Delay8.dat') == True:  # If save file exists
                with open(Str+'/Delay8.dat', 'rb') as PickleInst[Task]:
                    Delay8Var.set(pickle.load(PickleInst[Task]))  # Load
            else:
                Delay8Var.set('24')     # Default value
            if os.path.exists(Str+'/Delay9.dat') == True:  # If save file exists
                with open(Str+'/Delay9.dat', 'rb') as PickleInst[Task]:
                    Delay9Var.set(pickle.load(PickleInst[Task]))  # Load
            else:
                Delay9Var.set('24')     # Default value

            LoadTrg = 0

        if SaveTrg == 1:    # If save trigger is on
            # Parameters of each task are saved into different folder
            Str="ParametersForTask"+str(Task)   # Path to the folder for saving of parameters
            if os.path.exists(Str) == False:    # If folder for saving parameters is not exist
                os.mkdir(Str)   # Make folder for saving
            with open(Str+'/MaxCorrectNum.dat', 'wb') as PickleInst[Task]:
                pickle.dump(MaxCorrectNumVar.get(),PickleInst[Task])     # Save
            with open(Str+'/MaxTrialNum.dat', 'wb') as PickleInst[Task]:
                pickle.dump(MaxTrialNumVar.get(),PickleInst[Task])     # Save
            with open(Str + '/TimeLimit.dat', 'wb') as PickleInst[Task]:
                pickle.dump(TimeLimitVar.get(), PickleInst[Task])  # Save
            with open(Str+'/PunishDur.dat', 'wb') as PickleInst[Task]:
                pickle.dump(PunishDurVar.get(), PickleInst[Task])     # Save
            with open(Str + '/LickDur.dat', 'wb') as PickleInst[Task]:
                pickle.dump(LickDurVar.get(), PickleInst[Task])  # Save
            with open(Str + '/Iti.dat', 'wb') as PickleInst[Task]:
                pickle.dump(ItiVar.get(), PickleInst[Task])  # Save
            with open(Str + '/DelayAllowFactor.dat', 'wb') as PickleInst[Task]:
                pickle.dump(DelayAllowFactorVar.get(), PickleInst[Task])  # Save
            with open(Str + '/RateTh.dat', 'wb') as PickleInst[Task]:
                pickle.dump(RateThVar.get(), PickleInst[Task])  # Save
            with open(Str + '/DayTh.dat', 'wb') as PickleInst[Task]:
                pickle.dump(DayThVar.get(), PickleInst[Task])  # Save
            with open(Str + '/StartSession.dat', 'wb') as PickleInst[Task]:
                pickle.dump(StartSessionVar.get(), PickleInst[Task])  # Save
            with open(Str+'/Seed.dat', 'wb') as PickleInst[Task]:
                pickle.dump(SeedVar.get(), PickleInst[Task])     # Save
            with open(Str + '/NextTask.dat', 'wb') as PickleInst[Task]:
                pickle.dump(NextTaskVar.get(), PickleInst[Task])  # Save
            with open(Str + '/TaskType.dat', 'wb') as PickleInst[Task]:
                pickle.dump(TaskTypeVar.get(), PickleInst[Task])  # Save
            with open(Str+'/WaterCueType.dat', 'wb') as PickleInst[Task]:
                pickle.dump(WaterCueTypeVar.get(), PickleInst[Task])     # Save
            with open(Str+'/PunishWithLight.dat', 'wb') as PickleInst[Task]:
                pickle.dump(PunishWithLightVar.get(), PickleInst[Task])     # Save
            with open(Str + '/AwsOn.dat', 'wb') as PickleInst[Task]:
                pickle.dump(AwsOnVar.get(), PickleInst[Task])  # Save
            with open(Str+'/Delay0.dat', 'wb') as PickleInst[Task]:
                pickle.dump(Delay0Var.get(),PickleInst[Task])     # Save
            with open(Str+'/Delay1.dat', 'wb') as PickleInst[Task]:
                pickle.dump(Delay1Var.get(),PickleInst[Task])     # Save
            with open(Str+'/Delay2.dat', 'wb') as PickleInst[Task]:
                pickle.dump(Delay2Var.get(),PickleInst[Task])     # Save
            with open(Str+'/Delay3.dat', 'wb') as PickleInst[Task]:
                pickle.dump(Delay3Var.get(),PickleInst[Task])     # Save
            with open(Str+'/Delay4.dat', 'wb') as PickleInst[Task]:
                pickle.dump(Delay4Var.get(),PickleInst[Task])     # Save
            with open(Str+'/Delay5.dat', 'wb') as PickleInst[Task]:
                pickle.dump(Delay5Var.get(),PickleInst[Task])     # Save
            with open(Str+'/Delay6.dat', 'wb') as PickleInst[Task]:
                pickle.dump(Delay6Var.get(),PickleInst[Task])     # Save
            with open(Str+'/Delay7.dat', 'wb') as PickleInst[Task]:
                pickle.dump(Delay7Var.get(),PickleInst[Task])     # Save
            with open(Str+'/Delay8.dat', 'wb') as PickleInst[Task]:
                pickle.dump(Delay8Var.get(),PickleInst[Task])     # Save
            with open(Str+'/Delay9.dat', 'wb') as PickleInst[Task]:
                pickle.dump(Delay9Var.get(),PickleInst[Task])     # Save

            SaveTrg = 0

        if Phase == 1:  # Wait for starting of task
            if Phase1_Init == 0:
                PutPreTaskButton()
                mStatusVar = StringVar(MainWindowRoot)
                mStatus = ttk.Label(MainWindowRightFrame, textvariable=mStatusVar)
                mStatus.place(x=10, y=0)
                mOngoingResultVar = StringVar(MainWindowRoot)
                LearningPhase = 0  # Phase of task, 0:Acquisition, 1:DelayedTask
                SessionDelayID = int(StartSessionVar.get()) # Substitute delay ID (0-9)
                if SessionDelayID > 0:  # If session is started from middle
                    LearningPhase = 1       # Phase of task, 0:Acquisition, 1:DelayedTask
                ThClearDay=0        # Number of stream days where criteria threshold is achieved
                NumOfDelayID=1
                for i in range(9):
                    if i==1:
                        if Delay1Var.get()!='': # If delay is designated
                            NumOfDelayID+=1
                        if Delay1Var.get() == '':   # If delay is not designated
                            break
                    if i==2:
                        if Delay2Var.get()!='': # If delay is designated
                            NumOfDelayID+=1
                        if Delay2Var.get() == '':   # If delay is not designated
                            break
                    if i==3:
                        if Delay3Var.get()!='': # If delay is designated
                            NumOfDelayID+=1
                        if Delay3Var.get() == '':   # If delay is not designated
                            break
                    if i==4:
                        if Delay4Var.get()!='': # If delay is designated
                            NumOfDelayID+=1
                        if Delay4Var.get() == '':   # If delay is not designated
                            break
                    if i==5:
                        if Delay5Var.get()!='': # If delay is designated
                            NumOfDelayID+=1
                        if Delay5Var.get() == '':   # If delay is not designated
                            break
                    if i==6:
                        if Delay6Var.get()!='': # If delay is designated
                            NumOfDelayID+=1
                        if Delay6Var.get() == '':   # If delay is not designated
                            break
                    if i==7:
                        if Delay7Var.get()!='': # If delay is designated
                            NumOfDelayID+=1
                        if Delay7Var.get() == '':   # If delay is not designated
                            break
                    if i==8:
                        if Delay8Var.get()!='': # If delay is designated
                            NumOfDelayID+=1
                        if Delay8Var.get() == '':   # If delay is not designated
                            break
                    if i==9:
                        if Delay9Var.get()!='': # If delay is designated
                            NumOfDelayID+=1
                        if Delay9Var.get() == '':   # If delay is not designated
                            break
                print('Num of delays: ' + str(NumOfDelayID))

                Phase1_Init = 1
            mStatusVar.set('DNMS/DMS task (' + str(Task) + ')    Waiting...')
            if IsStartTime() == 1:  # If task start time is arrived
                StartNow()
        if Phase == 2:  # During task
            if Phase2_Init == 0: # Initialization of the task
                PutEndTaskNowButton()

                mStatusVar.set('DNMS/DMS task (' + str(Task) + ')    Start time ' + str(TaskStartedMonth) + '/' + str(TaskStartedDay) + ' ' + str(TaskStartedHour) + ':' + str(TaskStartedMinute) + '    Running')
                mOngoingResult = ttk.Label(MainWindowRightFrame, textvariable=mOngoingResultVar)
                mOngoingResult.place(x=10, y=18)

                # Convert StringVars of parameters into integer or normal string to use in the following
                MaxCorrectNum=int(MaxCorrectNumVar.get())
                MaxTrialNum = int(MaxTrialNumVar.get())
                TimeLimit = int(TimeLimitVar.get())
                PunishDur = int(PunishDurVar.get())
                LickDur = int(LickDurVar.get())
                Iti = int(ItiVar.get())
                AwsOn=AwsOnVar.get()
                DelayAllowFactor = int(DelayAllowFactorVar.get())
                RateTh = int(RateThVar.get())
                DayTh = int(DayThVar.get())
                StartSession = int(StartSessionVar.get())
                Seed = int(SeedVar.get())
                NextTask = int(NextTaskVar.get())
                TaskType = TaskTypeVar.get()
                WaterCueType = WaterCueTypeVar.get()
                PunishWithLight = PunishWithLightVar.get()

                PresetDelay=[0 for i in range(10)]
                if Delay0Var.get()!="":
                    PresetDelay[0] = int(Delay0Var.get())
                if Delay1Var.get() != "":
                    PresetDelay[1] = int(Delay1Var.get())
                if Delay2Var.get() != "":
                    PresetDelay[2] = int(Delay2Var.get())
                if Delay3Var.get() != "":
                    PresetDelay[3] = int(Delay3Var.get())
                if Delay4Var.get() != "":
                    PresetDelay[4] = int(Delay4Var.get())
                if Delay5Var.get() != "":
                    PresetDelay[5] = int(Delay5Var.get())
                if Delay6Var.get() != "":
                    PresetDelay[6] = int(Delay6Var.get())
                if Delay7Var.get() != "":
                    PresetDelay[7] = int(Delay7Var.get())
                if Delay8Var.get() != "":
                    PresetDelay[8] = int(Delay8Var.get())
                if Delay9Var.get() != "":
                    PresetDelay[9] = int(Delay9Var.get())

                if SessionDelayID == 0:
                    DelayA = PresetDelay[SessionDelayID]
                    DelayB = PresetDelay[SessionDelayID]
                if SessionDelayID > 0:
                    DelayA = PresetDelay[SessionDelayID-1]
                    DelayB = PresetDelay[SessionDelayID]

                StartLickRecording()
                RoofLightTurnOff()
                InfraredTurnOn()
                WaterCueTurnOn()
                WaterPosInside()
                CreateBlinkPanel(0)
                CreateBlinkPanel(1)  # tagg
                CreateNormalPanel(2)
                CreateNormalPanel(3)
                CreateNormalPanel(4)

                #MakeWaterCueBlink()  # Make water cue blink
                #MakeWaterCueNonBlink()

                # Declar local variables for this task
                CurrTrialNum = -1
                TotalCorrectNum = 0
                TrialNum = [0 for i in range(2)]
                CorrectNum = [0 for i in range(2)]
                IncorrectNum = [0 for i in range(2)]
                CorrectRate = [0 for i in range(2)]
                ValidCorrectNum=0   # Correct touch num which have done within the designated delay
                ValidIncorrectNum = 0
                ValidTouchNum=0
                ValidCorrectRate=0  # Correct rate which have done within the designated delay
                TouchHistory=[[-1 for i in range(5)] for j in range(MaxTrialNum)]   # Keeps history of touch results and time of touching (For valid trial selection) p0:CorrectPanelID p1:DelayStartTime p2:DelayEndTime p3:Result p4:DelayRand
                DelayHistory = [-1 for i in range(MaxTrialNum)]   # Keeps delay history
                ValidString=['','']

                DuringTask = 1
                DoneCorrectResponse = 1
                NowDrinking = 0
                AWS_Latency = 20
                StartRecording()    # Start camera capturing and sending of TTL
                print('Seed: '+str(Seed))
                random.seed(Seed)
                TtlStart()
                Timer_Start(5)  # Task time limit timer start
                Phase2 = 8
                Phase2_Init = 1

                Writer_TouchEventTxt = open(Path + "/" + str(TimeNow.year) + "_" + str(TimeNow.month) + "_" + str(TimeNow.day) + " " + str(TimeNow.hour) + "h" + str(TimeNow.minute) + "m Task" + str(Task) +  " Touch.txt",'w')  # Initialize the text exporter
                Writer_TouchEventCsv = open(Path + "/" + str(TimeNow.year) + "_" + str(TimeNow.month) + "_" + str(TimeNow.day) + " " + str(TimeNow.hour) + "h" + str(TimeNow.minute) + "m Task" + str(Task) +  " Touch.csv",'w')  # Initialize the text exporter
                Writer_TouchEventTxt.write('TrialNum\tResult\tPanel\tyyyy/mm/dd\th:m\ts\n')  # Write item name
                print("Task #" + str(Task) + " is started at " + str(GetTaskStartedMonth()) + '/' + str(GetTaskStartedDay()) + ' ' + str(GetTaskStartedHour()) + ':' + str(
                    GetTaskStartedMinute()) + ':' + str(GetTaskStartedSecond()))

            if Phase2 == 0:  # Initiation of new trial tagg
                DoneCorrectResponse = 0
                CorrectPanelID=int(random.random()*2)  # Determine which position is correct at random
                print('Trial: ' + str(CurrTrialNum))
                Trg = 0
                if CurrTrialNum <= 1:
                    TouchHistory[CurrTrialNum][0] = CorrectPanelID
                if CurrTrialNum > 1:
                    if CorrectPanelID == TouchHistory[CurrTrialNum-1][0] and CorrectPanelID == TouchHistory[CurrTrialNum-2][0]: # If Correct position is same as previous and pre-previous position
                        if CorrectPanelID==0:
                            CorrectPanelID =1   # Change correct position to the opposite side
                            Trg=1
                        if CorrectPanelID==1 and Trg==0:
                            CorrectPanelID = 0   # Change correct position to the opposite side
                TouchHistory[CurrTrialNum][0] = CorrectPanelID
                if CorrectPanelID == 0:
                    ShowPanel(0)
                if CorrectPanelID == 1:
                    ShowPanel(1)
                Writer_TouchEventTxt.write(str(CurrTrialNum+1) + '\tCueStart\t' + str(CorrectPanelID) + '\t' + str(TimeNow.year) + "/" + str(TimeNow.month) + "/" + str(TimeNow.day) + "\t" + str(TimeNow.hour) + ":" + str(TimeNow.minute) + "\t" + str(TimeNow.second) + "." + str(TimeNow.microsecond // 1000) + "\n")  # Write the response on the text file
                Writer_TouchEventCsv.write(str(CurrTrialNum+1) + ',0,' + str(CorrectPanelID) + ',' + str(TimeNow.year) + "," + str(TimeNow.month) + "," + str(TimeNow.day) + "," + str(TimeNow.hour) + "," + str(TimeNow.minute) + "," + str(TimeNow.second) + "." + str(TimeNow.microsecond // 1000) + "\n")  # Write the response on the csv file
                Timer_Start(0)  # Start the latency timer
                Phase2 = 1

            if Phase2 == 1:   # Sample panel presentation phase
                TouchedPanelID = DetectPanelTouch() # Check which panel is touched (return panel ID. If none of the panels touched, return -1)
                if TouchedPanelID == CorrectPanelID: # If mouse touches CORRECT panel
                    DoneCorrectResponse = 1

                    NowDrinking = 0
                    Writer_TouchEventTxt.write(str(CurrTrialNum+1) + '\tCueCorrectTouch\t' +str(CorrectPanelID)+'\t'+ str(TimeNow.year) + "/" + str(TimeNow.month) + "/" + str(TimeNow.day) + "\t" + str(TimeNow.hour) + ":" + str(TimeNow.minute) + "\t" + str(TimeNow.second) + "." + str(TimeNow.microsecond//1000) + "\n")  # Write the response on the text file
                    Writer_TouchEventCsv.write(str(CurrTrialNum+1) + ',1,' +str(CorrectPanelID)+','+ str(TimeNow.year) + "," + str(TimeNow.month) + "," + str(TimeNow.day) + "," + str(TimeNow.hour) + "," + str(TimeNow.minute) + "," + str(TimeNow.second) + "." + str(TimeNow.microsecond//1000) + "\n")  # Write the response on the csv file
                    HidePanel(0)
                    HidePanel(1)
                    Timer_End(0)


                    DelayRand = int(random.random() * 2)
                    Trg = 0
                    if CurrTrialNum > 1:
                        if DelayRand == DelayHistory[CurrTrialNum - 1] and DelayRand == DelayHistory[CurrTrialNum - 2]:  # If Correct position is same as previous and pre-previous position
                            if DelayRand == 0:
                                DelayRand = 1  # Change correct position to the opposite side
                                Trg = 1
                            if DelayRand == 1 and Trg == 0:
                                DelayRand = 0  # Change correct position to the opposite side
                    DelayHistory[CurrTrialNum] = DelayRand # Enter to the history
                    if DelayRand==0:
                        DelayDur = DelayA   # If this trial is DelayA
                    if DelayRand==1:
                        DelayDur = DelayB  # If this trial is DelayB
                    AllowedDelay = 10 + (DelayDur * DelayAllowFactor / 100) # Caliculate threshold for data selection
                    #print(AllowedDelay)
                    Phase2 = 2  # Go to interval
                    Timer_Start(0)

                if GetTimerSec(5) >= TimeLimit * 60:   # If time limit is exceeded
                    Timer_End(5)
                    Phase2 = 12

            if Phase2 == 2: # Interval between sample touch and 1st center presentation
                #print(GetTimerSec(0))
                if GetTimerSec(0) >= 1:
                    ShowPanel(2)    # Show 1st center panel
                    Phase2=3

            if Phase2 == 3: # 1st center panel presentation phase
                TouchedPanelID = DetectPanelTouch()  # Check which panel is touched (return panel ID. If none of the panels touched, return -1)
                if TouchedPanelID == 2:  # If mouse touches 1st center panel
                    DoneCorrectResponse = 1

                    NowDrinking = 0
                    TouchHistory[CurrTrialNum][1] = (TimeNow.hour * 60 * 60) + (TimeNow.minute * 60) + TimeNow.second
                    Writer_TouchEventTxt.write(str(CurrTrialNum+1) + '\t1stCenterCorrectTouch\t' + str(TouchedPanelID) + '\t' + str(TimeNow.year) + "/" + str(TimeNow.month) + "/" + str(TimeNow.day) + "\t" + str(TimeNow.hour) + ":" + str(TimeNow.minute) + "\t" + str(TimeNow.second) + "." + str(TimeNow.microsecond // 1000) + "\n")  # Write the response on the text file
                    Writer_TouchEventCsv.write(str(CurrTrialNum+1) + ',2,' + str(TouchedPanelID) + ',' + str(TimeNow.year) + "," + str(TimeNow.month) + "," + str(TimeNow.day) + "," + str(TimeNow.hour) + "," + str(TimeNow.minute) + "," + str(TimeNow.second) + "." + str(TimeNow.microsecond // 1000) + "\n")  # Write the response on the csv file
                    HidePanel(2)
                    Timer_End(0)
                    Phase2 = 4  # Start reward phase
                    Timer_Start(0)
                if GetTimerSec(5) >= TimeLimit * 60:  # If time limit is exceeded
                    Timer_End(5)
                    Phase2 = 12

            if Phase2 == 4: # Interval between sample touch and 1st center presentation
                if GetTimerSec(0) >= DelayDur:
                    ShowPanel(2)    # Show 1st center panel
                    Phase2=5

            if Phase2 == 5: # 2nd center panel presentation phase
                TouchedPanelID = DetectPanelTouch()  # Check which panel is touched (return panel ID. If none of the panels touched, return -1)
                if TouchedPanelID == 2:  # If mouse touches 1st center panel
                    DoneCorrectResponse = 1

                    NowDrinking = 0
                    Writer_TouchEventTxt.write(str(CurrTrialNum+1) + '\t2ndCenterCorrectTouch\t' + str(TouchedPanelID) + '\t' + str(TimeNow.year) + "/" + str(TimeNow.month) + "/" + str(TimeNow.day) + "\t" + str(TimeNow.hour) + ":" + str(TimeNow.minute) + "\t" + str(TimeNow.second) + "." + str(TimeNow.microsecond // 1000) + "\t"+str(DelayDur)+"\n")  # Write the response on the text file
                    Writer_TouchEventCsv.write(str(CurrTrialNum+1) + ',3,' + str(TouchedPanelID) + ',' + str(TimeNow.year) + "," + str(TimeNow.month) + "," + str(TimeNow.day) + "," + str(TimeNow.hour) + "," + str(TimeNow.minute) + "," + str(TimeNow.second) + "." + str(TimeNow.microsecond // 1000) + ","+str(DelayDur)+"\n")  # Write the response on the csv file
                    HidePanel(2)
                    Timer_End(0)
                    Phase2 = 6  # Start reward phase
                    Timer_Start(0)
                if GetTimerSec(5) >= TimeLimit * 60:  # If time limit is exceeded
                    Timer_End(5)
                    Phase2 = 12

            if Phase2 == 6: # Interval between sample touch and 1st center presentation
                if GetTimerSec(0) >= 1:
                    if CorrectPanelID==0:
                        if TaskType=='DNMS1':
                            ShowPanel(4)    #
                        if TaskType=='DMS1':
                            ShowPanel(3)  #
                        if TaskType=='DNMS2' or TaskType=='DMS2':
                            ShowPanel(3)  #
                            ShowPanel(4)  #
                    if CorrectPanelID==1:
                        if TaskType=='DNMS1':
                            ShowPanel(3)    #
                        if TaskType=='DMS1':
                            ShowPanel(4)  #
                        if TaskType=='DNMS2' or TaskType=='DMS2':
                            ShowPanel(3)  #
                            ShowPanel(4)  #
                    Phase2=7

            if Phase2 == 7: # Choice phase
                TouchedPanelID = DetectPanelTouch()  # Check which panel is touched (return panel ID. If none of the panels touched, return -1)
                if TouchedPanelID != -1:
                    TouchResult = 0
                    if TaskType == 'DMS1' or TaskType == 'DMS2':
                        if TouchedPanelID == CorrectPanelID or TouchedPanelID == CorrectPanelID+3:  # If mouse touches same position with the sample phase
                            TouchResult=1   # Correct
                        if TouchedPanelID != CorrectPanelID and TouchedPanelID != CorrectPanelID + 3 and TouchedPanelID != 2:  # If mouse touches opposite position to the sample phase
                            TouchResult = -1   # Wrong
                    if TaskType == 'DNMS1' or TaskType == 'DNMS2':
                        if TouchedPanelID != CorrectPanelID and TouchedPanelID != CorrectPanelID + 3 and TouchedPanelID != 2:  # If mouse touches opposite position to the sample phase
                            TouchResult = 1   # Correct

                        if TouchedPanelID == CorrectPanelID or TouchedPanelID == CorrectPanelID + 3:   # If mouse touches same position with the sample phase
                            TouchResult = -1   # Wrong
                    if TouchResult==1: # If mouse touches correct panel
                        DoneCorrectResponse = 1
                        NowDrinking = 0
                        TouchHistory[CurrTrialNum][2] = (TimeNow.hour * 60 * 60) + (TimeNow.minute * 60) + TimeNow.second
                        TouchHistory[CurrTrialNum][3] =1
                        TouchHistory[CurrTrialNum][4] = DelayRand
                        TrialNum[DelayRand] += 1
                        CorrectNum[DelayRand] += 1  # Increase the number of correct respon
                        TotalCorrectNum += 1
                        CorrectRate[DelayRand] = round(CorrectNum[DelayRand] * 100.0 / TrialNum[DelayRand], 2)
                        Writer_TouchEventTxt.write(str(CurrTrialNum) + '\tTestCorrectTouch\t' + str(TouchedPanelID) + '\t' + str(TimeNow.year) + "/" + str(TimeNow.month) + "/" + str(TimeNow.day) + "\t" + str(TimeNow.hour) + ":" + str(TimeNow.minute) + "\t" + str(TimeNow.second) + "." + str(TimeNow.microsecond // 1000) + "\t"+str(DelayDur)+"\t"+str(DelayRand)+"\n")  # Write the response on the text file
                        Writer_TouchEventCsv.write(str(CurrTrialNum) + ',4,' + str(TouchedPanelID) + ',' + str(TimeNow.year) + "," + str(TimeNow.month) + "," + str(TimeNow.day) + "," + str(TimeNow.hour) + "," + str(TimeNow.minute) + "," + str(TimeNow.second) + "." + str(TimeNow.microsecond // 1000) + ","+str(DelayDur)+","+str(DelayRand)+"\n")  # Write the response on the csv file
                        HidePanel(3)
                        HidePanel(4)
                        Timer_End(0)
                        WaterCueTurnOn()
                        WaterPosInside()
                        Phase2 = 8  # Go to reward phase

                    if TouchResult==-1:  # If mouse touches wrong panel
                        DoneCorrectResponse = 0
                        NowDrinking = 0
                        TouchHistory[CurrTrialNum][2] = (TimeNow.hour * 60 * 60) + (TimeNow.minute * 60) + TimeNow.second
                        TouchHistory[CurrTrialNum][3] = 0
                        TouchHistory[CurrTrialNum][4] = DelayRand
                        TrialNum[DelayRand] += 1
                        IncorrectNum[DelayRand] += 1  # Increase the number of correct response
                        CorrectRate[DelayRand] = round(CorrectNum[DelayRand] * 100.0 / TrialNum[DelayRand], 2)
                        Writer_TouchEventTxt.write(str(CurrTrialNum+1) + '\tTestIncorrectTouch\t' + str(TouchedPanelID) + '\t' + str(TimeNow.year) + "/" + str(TimeNow.month) + "/" + str(TimeNow.day) + "\t" + str(TimeNow.hour) + ":" + str(TimeNow.minute) + "\t" + str(TimeNow.second) + "." + str(TimeNow.microsecond // 1000) + "\t"+str(DelayDur)+"\t"+str(DelayRand)+"\n")  # Write the response on the text file
                        Writer_TouchEventCsv.write(str(CurrTrialNum+1) + ',5,' + str(TouchedPanelID) + ',' + str(TimeNow.year) + "," + str(TimeNow.month) + "," + str(TimeNow.day) + "," + str(TimeNow.hour) + "," + str(TimeNow.minute) + "," + str(TimeNow.second) + "." + str(TimeNow.microsecond // 1000) + ","+str(DelayDur)+","+str(DelayRand)+"\n")  # Write the response on the csv file
                        HidePanel(3)
                        HidePanel(4)
                        Timer_End(0)
                        if PunishWithLight == 'ON':
                            RoofLightTurnOn()  # Turn on roof light
                        WaterPosOutside()
                        Phase2 = 8  # Start reward phase
                        Timer_Start(0)

                if GetTimerSec(5) >= TimeLimit * 60:  # If time limit is exceeded
                    Timer_End(5)
                    Phase2 = 12

            if Phase2 == 8:
                for i2 in range(2):
                    # Caliculate valid score
                    ValidTouchNum = 0
                    ValidCorrectNum = 0
                    ValidIncorrectNum = 0
                    for i in range(CurrTrialNum+1):  # Loop for trials
                        if TouchHistory[i][2] == -1:  # If this trial is not completed
                            break
                        if TouchHistory[i][4] == i2:  # If this trial is completed
                            if TouchHistory[i][2] != -1:  # If this trial is completed
                                ActualDelay = TouchHistory[i][2] - TouchHistory[i][1]
                                if ActualDelay <= AllowedDelay:
                                    ValidTouchNum += 1
                                    if TouchHistory[i][3] == 1:
                                        ValidCorrectNum += 1
                                    if TouchHistory[i][3] == 0:
                                        ValidIncorrectNum += 1
                    if ValidTouchNum > 0:
                        ValidCorrectRate = round(ValidCorrectNum / ValidTouchNum * 100, 1)
                        ValidString[i2] = '  /  ValidCorrect:' + str(ValidCorrectNum) + '  ValidWrong:' + str(ValidIncorrectNum) + '  ValidTotalNum:' + str(ValidTouchNum) + '  ValidCorrect:' + str(ValidCorrectRate) + '%'
                ResultStringA = 'Delay ' + str(DelayA) + 's : CorrectNum:' + str(CorrectNum[0]) + '  IncorrectNum:' + str(IncorrectNum[0]) + '  TrialNum:' + str(TrialNum[0]) + '  Correct:' + str(CorrectRate[0]) + '%' + ValidString[0]
                ResultStringB = 'Delay ' + str(DelayB) + 's : CorrectNum:' + str(CorrectNum[1]) + '  IncorrectNum:' + str(IncorrectNum[1]) + '  TrialNum:' + str(TrialNum[1]) + '  Correct:' + str(CorrectRate[1]) + '%' + ValidString[1]
                mOngoingResultVar.set(ResultStringA+'\n'+ResultStringB)
                if DoneCorrectResponse == 1:
                    Phase2 = 9
                if DoneCorrectResponse == 0:
                    Phase2 = 10

            if Phase2 == 9:  # Reward phase
                if NosePoking == 1 and NowDrinking == 0:    # If the mouse initiates nose poke
                    NowDrinking = 1
                    Timer_Start(0)  # Start lick timer
                if NowDrinking == 1:
                    if DoneCorrectResponse == 1 and GetTimerSec(0) >= LickDur:   # If lick time exceed the designated time
                        Timer_End(0) # End lick timer
                        WaterPosMiddle()    # Move water nozzle to the intermediate position
                        WaterCueTurnOff()
                        NowDrinking = 0
                        Timer_Start(0)  # Start ITI timer
                        Phase2 = 11 # Go to ITI

            if Phase2 == 10:   # Punishment phase
                if GetTimerSec(0) >= PunishDur:    # If punishment time is passed
                    RoofLightTurnOff()
                    WaterPosMiddle()    # Move water nozzle to the intermediate position
                    Timer_End(0)  # End punishment timer1
                    Timer_Start(0)  # Start ITI timer
                    Phase2 = 11 # Go to ITI

            if Phase2 == 11:   # ITI
                if GetTimerSec(0) >= Iti:    # If ITI is passed
                    if TotalCorrectNum >= MaxCorrectNum or CurrTrialNum >= MaxTrialNum-1: # If mouse achieved criteria of finishing the task
                        Timer_End(5)
                        WaterPosMiddle()
                        WaterCueTurnOff()
                        Timer_Start(0)  # Timer for interval between task and arbitary water supply is started
                        Phase2 = 12  # Go to the AWS
                    else:
                        CurrTrialNum += 1
                        Phase2 = 0  # Go to the next trial

            if Phase2==12:  # End session
                HidePanel(0)
                HidePanel(1)
                HidePanel(2)
                HidePanel(3)
                HidePanel(4)
                if TotalCorrectNum < MaxCorrectNum and AwsOn == 'ON':  # If mouse didn't achieved the max correct response
                    Timer_Start(0)
                    Phase2 = 13
                if TotalCorrectNum == MaxCorrectNum or AwsOn == 'OFF':  # If mouse achieved the max correct response
                    Phase2 = -1

            if Phase2==13:   # Wait until arbitary water suuply is started
                if GetTimerSec(0) >= 20:   # If the interval is past 20
                    Timer_End(0)
                    ArbitaryWaterSupplyDur=(MaxCorrectNum - TotalCorrectNum) * LickDur * 1000    # Caliculate duration of complement water supply
                    StartArbitaryWaterSupply(ArbitaryWaterSupplyDur) # Start complement water supply
                    print("AWSstart")
                    Phase2=14
            if Phase2==14:
                if GetArbitaryWaterSupplyStat()==1: # If complement water supply is finished
                    Phase2 = -1

            if Phase2 == -1 or Phase2 == -2:  # Task finish phase
                DuringTask = 0
                WaterPosMiddle()
                ClearPanel()
                MakeWaterCueNonBlink()
                InfraredTurnOff()
                if NowRecording == 1:
                    SetEndRecordingTimer(60)

                if CurrTrialNum > 0:
                    Writer_TouchEventTxt.write(ResultStringA+'\n'+ResultStringB+'\n')	#Summary of results
                Writer_TouchEventTxt.write('TaskStartTime: ' + str(GetTaskStartedMonth()) + '/' + str(GetTaskStartedDay()) + ' ' + str(GetTaskStartedHour()) + ':' + str(GetTaskStartedMinute()) + ':' + str(GetTaskStartedSecond()) + "\n")
                Writer_TouchEventTxt.write('TaskEndTime: ' + str(TimeNow.month) + '/' + str(TimeNow.day) + ' ' + str(TimeNow.hour) + ':' + str(TimeNow.minute) + ':' + str(TimeNow.second + (TimeNow.microsecond // 1000) / 1000) + "\n")
                Writer_TouchEventTxt.write('DelayA: ' + str(DelayA) + " sec\n")
                Writer_TouchEventTxt.write('DelayB: ' + str(DelayB) + " sec\n")
                Writer_TouchEventTxt.write('MaxCorrectNum: '+str(MaxCorrectNum)+"\n")
                Writer_TouchEventTxt.write('MaxTrialNum: ' + str(MaxTrialNum) + "\n")
                Writer_TouchEventTxt.write('TimeLimit: ' + str(TimeLimit) + " min\n")
                Writer_TouchEventTxt.write('PunishDur: ' + str(PunishDur) + " sec\n")
                Writer_TouchEventTxt.write('LickDur: ' + str(LickDur) + " sec\n")
                Writer_TouchEventTxt.write('Iti: ' + str(Iti) + " sec\n")
                Writer_TouchEventTxt.write('ValidDelay%: ' + str(DelayAllowFactor) + " %\n")
                Writer_TouchEventTxt.write('RateTh: ' + str(RateTh) + " %\n")
                Writer_TouchEventTxt.write('DayTh: ' + str(DayTh) + " day\n")
                Writer_TouchEventTxt.write('Seed: ' + str(Seed) + "\n")
                Writer_TouchEventTxt.write('NextTask: ' + str(NextTask) + "\n")
                Writer_TouchEventTxt.write('TaskType: ' + str(TaskType) + "\n")
                Writer_TouchEventTxt.write('WaterCueType: ' + str(WaterCueType) + "\n")
                Writer_TouchEventTxt.write('PunishWithLight: ' + str(PunishWithLight) + "\n")
                Writer_TouchEventTxt.write('RecordFPS: ' + str(RecordFPS) + "\n")
                Writer_TouchEventTxt.write('AWS: ' + AwsOn + "\n")
                Writer_TouchEventTxt.write('AWS_Latency: ' + str(AWS_Latency) + "\n")

                Writer_TouchEventTxt.close()
                Writer_TouchEventCsv.close()
                EndLickRecording()

                SendMail(DeviceNameVar.get() + ' finished task '+str(Task)+'.'+ResultStringA+';  '+ResultStringB+';  Dur:' + str(round(GetTimerSec(5) / 60,1)) + ' min', 'Task is finished.')
                TtlDelayStop()

                if IsHousingAnalysis == 1:  #
                    SeedVar.set(Seed+1)
                    # Update condition of experiment
                    if LearningPhase == 0:   # If it is acquisition phase
                        TotalCorrectRate = (CorrectNum[0] + CorrectNum[1]) * 100 / (TrialNum[0] + TrialNum[1])
                        if CurrTrialNum!=0:
                            if TotalCorrectRate >= RateTh:   # If correct rate excceeded the criteria
                                ThClearDay+=1   # Increase the criteria counter
                                print("Current cleared stream days:" + str(ThClearDay))
                                if ThClearDay >= DayTh: # If acquisition is completed
                                    LearningPhase = 1    # Go to the delayed phase
                                    print("Delayed phase is started")
                        if TotalCorrectRate < RateTh:  # If correct rate belowed the criteria
                            ThClearDay =0   # Reset the criteria counter
                    if LearningPhase == 1:   # If it is delayed phase
                        SessionDelayID += 1 # Change delay
                        if SessionDelayID==1:
                            print("Next delay is "+Delay0Var.get()+" sec / "+Delay1Var.get()+" sec")
                        if SessionDelayID==2:
                            print("Next delay is "+Delay1Var.get()+" sec / "+Delay2Var.get()+" sec")
                        if SessionDelayID==3:
                            print("Next delay is "+Delay2Var.get()+" sec / "+Delay3Var.get()+" sec")
                        if SessionDelayID==4:
                            print("Next delay is "+Delay3Var.get()+" sec / "+Delay4Var.get()+" sec")
                        if SessionDelayID==5:
                            print("Next delay is "+Delay4Var.get()+" sec / "+Delay5Var.get()+" sec")
                        if SessionDelayID==6:
                            print("Next delay is "+Delay5Var.get()+" sec / "+Delay6Var.get()+" sec")
                        if SessionDelayID==7:
                            print("Next delay is "+Delay6Var.get()+" sec / "+Delay7Var.get()+" sec")
                        if SessionDelayID==8:
                            print("Next delay is "+Delay7Var.get()+" sec / "+Delay8Var.get()+" sec")
                        if SessionDelayID==9:
                            print("Next delay is "+Delay8Var.get()+" sec / "+Delay9Var.get()+" sec")
                        if Phase2 == -1:
                            if SessionDelayID > NumOfDelayID-1:    # If the last delayed session is finished (This task is completed)
                                SwitchTask(NextTask)  # Onset task switch trigger
                                print("Task is switched to task#" + str(NextTask) + "  " + str(GetTaskStartedMonth()) + '/' + str(GetTaskStartedDay()) + ' ' + str(GetTaskStartedHour()) + ':' + str(GetTaskStartedMinute()) + ':' + str(GetTaskStartedSecond()))

                if IsHousingAnalysis == 0:
                    RoofLightTurnOn()

                Phase = 1  # Go back to the task-waiting phase
                Phase2 = 0
                Phase2_Init = 0
    return

def Task26():   # Spatial discrimination task
    global Phase, Phase2, Init, Task, SaveTrg, LoadTrg, NosePoking, DuringTask, NowRecording, RecordFPS
    Task = 26
    Phase0_Init=0
    Phase1_Init=0
    Phase2_Init=0
    while EndFlag==0:
        OperantHouseUpdate()
        if Phase == -1:  # Back to the task select phase
            Phase = 0
            Task = 0
            break
        if Phase == 0:  # Parameter inputs
            if Phase0_Init == 0:
                LoadTrg = 1
                # Make GUI for the setting of the parameters for this task
                RemoveMainRightWidget() # Remove task buttons

                PutStartBackButton()    # Put start/back buttons
                mSpace = ttk.Label(MainWindowRightFrame, text=' ').grid(row=0, column=1)  # Used just as spacer

                mMaxCorrectNum = ttk.Label(MainWindowRightFrame, text='MaxCorrectNum').grid(row=0, column=2, sticky=W)    # Put label
                MaxCorrectNumVar = IntVar(MainWindowRoot)  # Declare variable receiving value from the entry field
                iMaxCorrectNum = ttk.Entry(MainWindowRightFrame, textvariable=MaxCorrectNumVar).grid(row=1, column=2) # Place entry field

                mMaxTrialNum = ttk.Label(MainWindowRightFrame, text='MaxTrialNum').grid(row=0, column=3, sticky=W)
                MaxTrialNumVar = IntVar(MainWindowRoot)
                iMaxTrialNum = ttk.Entry(MainWindowRightFrame, textvariable=MaxTrialNumVar).grid(row=1, column=3)

                mTimeLimit = ttk.Label(MainWindowRightFrame, text='TimeLimit(min)').grid(row=0, column=4, sticky=W)
                TimeLimitVar = IntVar(MainWindowRoot)
                iTimeLimit = ttk.Entry(MainWindowRightFrame, textvariable=TimeLimitVar).grid(row=1, column=4)

                mPunishDur = ttk.Label(MainWindowRightFrame, text='PunishDur(s)').grid(row=0, column=5, sticky=W)
                PunishDurVar = IntVar(MainWindowRoot)
                iPunishDur = ttk.Entry(MainWindowRightFrame, textvariable=PunishDurVar).grid(row=1, column=5)

                mIti = ttk.Label(MainWindowRightFrame, text='ITI(s)').grid(row=0, column=6, sticky=W)
                ItiVar = IntVar(MainWindowRoot)
                iIti = ttk.Entry(MainWindowRightFrame, textvariable=ItiVar).grid(row=1, column=6)

                mLickDur = ttk.Label(MainWindowRightFrame, text='LickDur(s)').grid(row=0, column=7, sticky=W)
                LickDurVar = IntVar(MainWindowRoot)
                iLickDur = ttk.Entry(MainWindowRightFrame, textvariable=LickDurVar).grid(row=1, column=7)

                mNextTaskTh = ttk.Label(MainWindowRightFrame, text='NextTaskTh(Correct%)').grid(row=2, column=2, sticky=W)
                NextTaskThVar = IntVar(MainWindowRoot)
                iNextTaskTh = ttk.Entry(MainWindowRightFrame, textvariable=NextTaskThVar).grid(row=3, column=2)

                mNextTask = ttk.Label(MainWindowRightFrame, text='NextTask#').grid(row=2, column=3, sticky=W)
                NextTaskVar = IntVar(MainWindowRoot)
                iNextTask = ttk.Entry(MainWindowRightFrame, textvariable=NextTaskVar).grid(row=3, column=3)

                mCorrectPos = ttk.Label(MainWindowRightFrame, text='CorrectPos').grid(row=2, column=4, sticky=W)    # Put label
                CorrectPosVar = StringVar(MainWindowRightFrame)  # Declare variable receiving value from the entry field
                tCorrectPos = OptionMenu(MainWindowRightFrame, CorrectPosVar, "0", "1").grid(row=3, column=4) # Place drop-down list

                mPanelType = ttk.Label(MainWindowRightFrame, text='PanelType').grid(row=2, column=5, sticky=W)
                PanelTypeVar = StringVar(MainWindowRightFrame)
                tPanelType = OptionMenu(MainWindowRightFrame, PanelTypeVar, "Normal", "Blink", "Textured").grid(row=3, column=5)

                mWaterCueType = ttk.Label(MainWindowRightFrame, text='WaterCueType').grid(row=2, column=6, sticky=W)
                WaterCueTypeVar = StringVar(MainWindowRightFrame)
                tWaterCueType = OptionMenu(MainWindowRightFrame, WaterCueTypeVar, "Normal", "Blink").grid(row=3, column=6)

                mLitPattern = ttk.Label(MainWindowRightFrame, text='LitPattern').grid(row=2, column=7, sticky=W)
                LitPatternVar = StringVar(MainWindowRightFrame)
                tLitPattern = OptionMenu(MainWindowRightFrame, LitPatternVar, "Random", "All").grid(row=3, column=7)

                mPunishWithLight = ttk.Label(MainWindowRightFrame, text='PunishWithLight').grid(row=2, column=8, sticky=W)
                PunishWithLightVar = StringVar(MainWindowRightFrame)
                tPunishWithLight = OptionMenu(MainWindowRightFrame, PunishWithLightVar, "ON", "OFF").grid(row=3, column=8)

                mAwsOn = ttk.Label(MainWindowRightFrame, text='AWS').grid(row=4, column=2, sticky=W)
                AwsOnVar = StringVar(MainWindowRightFrame)
                tAwsOn = OptionMenu(MainWindowRightFrame, AwsOnVar, "ON", "OFF").grid(row=5, column=2)

                #InitPanel() #
                Phase0_Init = 1

        if LoadTrg == 1:  # If load trigger is on

            Str = "ParametersForTask" + str(Task)
            if os.path.exists(Str+'/MaxCorrectNum.dat') == True:  # If save file exists
                with open(Str+'/MaxCorrectNum.dat', 'rb') as PickleInst[Task]:
                    MaxCorrectNumVar.set(pickle.load(PickleInst[Task]))  # Load
            else:
                MaxCorrectNumVar.set(80)     # Default value

            if os.path.exists(Str+'/MaxTrialNum.dat') == True:  # If save file exists
                with open(Str+'/MaxTrialNum.dat', 'rb') as PickleInst[Task]:
                    MaxTrialNumVar.set(pickle.load(PickleInst[Task]))  # Load
            else:
                MaxTrialNumVar.set(110)     # Default value

            if os.path.exists(Str+'/TimeLimit.dat') == True:  # If save file exists
                with open(Str+'/TimeLimit.dat', 'rb') as PickleInst[Task]:
                    TimeLimitVar.set(pickle.load(PickleInst[Task]))  # Load
            else:
                TimeLimitVar.set(90)     # Default value

            if os.path.exists(Str+'/PunishDur.dat') == True:  # If save file exists
                with open(Str+'/PunishDur.dat', 'rb') as PickleInst[Task]:
                    PunishDurVar.set(pickle.load(PickleInst[Task]))  # Load
            else:
                PunishDurVar.set(15)     # Default value

            if os.path.exists(Str+'/Iti.dat') == True:  # If save file exists
                with open(Str+'/Iti.dat', 'rb') as PickleInst[Task]:
                    ItiVar.set(pickle.load(PickleInst[Task]))  # Load
            else:
                ItiVar.set(1)     # Default value
            if os.path.exists(Str+'/LickDur.dat') == True:  # If save file exists
                with open(Str+'/LickDur.dat', 'rb') as PickleInst[Task]:
                    LickDurVar.set(pickle.load(PickleInst[Task]))  # Load
            else:
                LickDurVar.set(2)     # Default value

            if os.path.exists(Str+'/NextTaskTh.dat') == True:  # If save file exists
                with open(Str+'/NextTaskTh.dat', 'rb') as PickleInst[Task]:
                    NextTaskThVar.set(pickle.load(PickleInst[Task]))  # Load
            else:
                NextTaskThVar.set(26)     # Default value
            if os.path.exists(Str+'/NextTask.dat') == True:  # If save file exists
                with open(Str+'/NextTask.dat', 'rb') as PickleInst[Task]:
                    NextTaskVar.set(pickle.load(PickleInst[Task]))  # Load
            else:
                NextTaskVar.set(26)     # Default value

            if os.path.exists(Str+'/CorrectPos.dat') == True:  # If save file exists
                with open(Str+'/CorrectPos.dat', 'rb') as PickleInst[Task]:
                    CorrectPosVar.set(pickle.load(PickleInst[Task]))  # Load
            else:
                CorrectPosVar.set(1)     # Default value

            if os.path.exists(Str+'/PanelType.dat') == True:  # If save file exists
                with open(Str+'/PanelType.dat', 'rb') as PickleInst[Task]:
                    PanelTypeVar.set(pickle.load(PickleInst[Task]))  # Load
            else:
                PanelTypeVar.set('Normal')     # Default value

            if os.path.exists(Str+'/WaterCueType.dat') == True:  # If save file exists
                with open(Str+'/WaterCueType.dat', 'rb') as PickleInst[Task]:
                    WaterCueTypeVar.set(pickle.load(PickleInst[Task]))  # Load
            else:
                WaterCueTypeVar.set('Blink')     # Default value

            if os.path.exists(Str+'/LitPattern.dat') == True:  # If save file exists
                with open(Str+'/LitPattern.dat', 'rb') as PickleInst[Task]:
                    LitPatternVar.set(pickle.load(PickleInst[Task]))  # Load
            else:
                LitPatternVar.set('All')     # Default value
            if os.path.exists(Str+'/PunishWithLight.dat') == True:  # If save file exists
                with open(Str+'/PunishWithLight.dat', 'rb') as PickleInst[Task]:
                    PunishWithLightVar.set(pickle.load(PickleInst[Task]))  # Load
            else:
                PunishWithLightVar.set('ON')     # Default value
            if os.path.exists(Str+'/AwsOn.dat') == True:  # If save file exists
                with open(Str+'/AwsOn.dat', 'rb') as PickleInst[Task]:
                    AwsOnVar.set(pickle.load(PickleInst[Task]))  # Load
            else:
                AwsOnVar.set('ON')     # Default value
            LoadTrg = 0

        if SaveTrg == 1:    # If save trigger is on
            # Parameters of each task are saved into different folder
            Str="ParametersForTask"+str(Task)   # Path to the folder for saving of parameters
            if os.path.exists(Str) == False:    # If folder for saving parameters is not exist
                os.mkdir(Str)   # Make folder for saving
            with open(Str+'/MaxCorrectNum.dat', 'wb') as PickleInst[Task]:
                pickle.dump(MaxCorrectNumVar.get(),PickleInst[Task])     # Save
            with open(Str+'/MaxTrialNum.dat', 'wb') as PickleInst[Task]:
                pickle.dump(MaxTrialNumVar.get(),PickleInst[Task])     # Save
            with open(Str + '/TimeLimit.dat', 'wb') as PickleInst[Task]:
                pickle.dump(TimeLimitVar.get(), PickleInst[Task])  # Save
            with open(Str+'/PunishDur.dat', 'wb') as PickleInst[Task]:
                pickle.dump(PunishDurVar.get(), PickleInst[Task])     # Save
            with open(Str+'/Iti.dat', 'wb') as PickleInst[Task]:
                pickle.dump(ItiVar.get(), PickleInst[Task])     # Save
            with open(Str+'/LickDur.dat', 'wb') as PickleInst[Task]:
                pickle.dump(LickDurVar.get(), PickleInst[Task])     # Save
            with open(Str + '/NextTask.dat', 'wb') as PickleInst[Task]:
                pickle.dump(NextTaskVar.get(), PickleInst[Task])  # Save
            with open(Str+'/NextTaskTh.dat', 'wb') as PickleInst[Task]:
                pickle.dump(NextTaskThVar.get(), PickleInst[Task])     # Save
            with open(Str+'/CorrectPos.dat', 'wb') as PickleInst[Task]:
                pickle.dump(CorrectPosVar.get(), PickleInst[Task])     # Save
            with open(Str+'/PanelType.dat', 'wb') as PickleInst[Task]:
                pickle.dump(PanelTypeVar.get(), PickleInst[Task])     # Save
            with open(Str+'/WaterCueType.dat', 'wb') as PickleInst[Task]:
                pickle.dump(WaterCueTypeVar.get(), PickleInst[Task])     # Save
            with open(Str+'/LitPattern.dat', 'wb') as PickleInst[Task]:
                pickle.dump(LitPatternVar.get(), PickleInst[Task])     # Save
            with open(Str+'/PunishWithLight.dat', 'wb') as PickleInst[Task]:
                pickle.dump(PunishWithLightVar.get(), PickleInst[Task])     # Save
            with open(Str+'/AwsOn.dat', 'wb') as PickleInst[Task]:
                pickle.dump(AwsOnVar.get(), PickleInst[Task])     # Save
            SaveTrg = 0

        if Phase == 1:  # Wait for starting of task
            if Phase1_Init == 0:
                PutPreTaskButton()
                mStatusVar = StringVar(MainWindowRoot)
                mStatus = ttk.Label(MainWindowRightFrame, textvariable=mStatusVar)
                mStatus.place(x=10, y=0)
                mOngoingResultVar = StringVar(MainWindowRoot)
                Phase1_Init = 1
            mStatusVar.set('Spatial discrimination task (' + str(Task) + ')    Waiting...')
            if IsStartTime() == 1:
                StartNow()
        if Phase == 2:  # During task
            if Phase2_Init == 0: # Initialization of the task
                PutEndTaskNowButton()

                mStatusVar.set('Spatial discrimination task (' + str(Task) + ')    Start time ' + str(TaskStartedMonth) + '/' + str(TaskStartedDay) + ' ' + str(TaskStartedHour) + ':' + str(TaskStartedMinute) + '    Running')
                mOngoingResult = ttk.Label(MainWindowRightFrame, textvariable=mOngoingResultVar)
                mOngoingResult.place(x=10, y=18)

                # Convert StringVars of parameters into integer or normal string to use in the following
                MaxCorrectNum=int(MaxCorrectNumVar.get())
                MaxTrialNum = int(MaxTrialNumVar.get())
                TimeLimit = int(TimeLimitVar.get())
                PunishDur = int(PunishDurVar.get())
                Iti = int(ItiVar.get())
                LickDur = int(LickDurVar.get())
                NextTask = int(NextTaskVar.get())
                NextTaskTh = int(NextTaskThVar.get())
                CorrectPos = CorrectPosVar.get()
                PanelType = PanelTypeVar.get()
                WaterCueType =WaterCueTypeVar.get()
                LitPattern = LitPatternVar.get()
                PunishWithLight = PunishWithLightVar.get()
                AwsOn = AwsOnVar.get()

                StartLickRecording()
                RoofLightTurnOff()
                InfraredTurnOn()
                WaterCueTurnOn()
                WaterPosInside()
                if PanelType=='Normal':
                    CreateNormalPanel(0)
                    CreateNormalPanel(1)
                if PanelType=='Blink':
                    CreateBlinkPanel(0)
                    CreateBlinkPanel(1)
                if PanelType=='Textured':
                    CreateTexturedPanel(0)
                    CreateTexturedPanel(1)
                if WaterCueType == 'Blink':
                    MakeWaterCueBlink() # Make water cue blink

                # Declar local variables for this task
                TotalTouchNum = 0
                CorrectNum = 0
                IncorrectNum = 0
                CorrectRate = 0

                DuringTask = 1
                DoneCorrectResponse = 1
                NowDrinking = 0
                AWS_Latency=20
                StartRecording()    # Start camera capturing and sending of TTL

                TrialNum=0
                TtlStart()
                Timer_Start(5)  # Task time limit timer start
                Phase2 = 2
                Phase2_Init = 1

                Writer_TouchEventTxt = open(Path + "/" + str(TimeNow.year) + "_" + str(TimeNow.month) + "_" + str(TimeNow.day) + " " + str(TimeNow.hour) + "h" + str(TimeNow.minute) + "m Task" + str(Task) + " Touch.txt",'w')  # Initialize the text exporter
                Writer_TouchEventCsv = open(Path + "/" + str(TimeNow.year) + "_" + str(TimeNow.month) + "_" + str(TimeNow.day) + " " + str(TimeNow.hour) + "h" + str(TimeNow.minute) + "m Task" + str(Task) + " Touch.csv",'w')  # Initialize the text exporter
                Writer_TouchEventTxt.write('TrialNum\tResult\t\t\tyyyy/mm/dd\th:m\ts\n')  # Write item name
                print("Task #" + str(Task) + " is started at " + str(GetTaskStartedMonth()) + '/' + str(GetTaskStartedDay()) + ' ' + str(GetTaskStartedHour()) + ':' + str(
                    GetTaskStartedMinute()) + ':' + str(GetTaskStartedSecond()))

            if Phase2 == 0:   # Initiation of new trial

                DoneCorrectResponse=0
                TrialNum += 1
                if LitPattern=='All':
                    ShowPanel(0)
                    ShowPanel(1)
                if LitPattern=='Random':
                    Rnd=random.random()*2
                    if Rnd < 1:
                        ShowPanel(0)
                    if Rnd >= 1:
                        ShowPanel(1)

                Timer_Start(0)  # Start the latency timer
                Phase2 += 1
            if Phase2 == 1:   # Panel presentation
                TouchedPanelID = DetectPanelTouch() # Examine which panel is touched (return panel ID. If none of the panels touched, return -1)
                if TouchedPanelID != -1:
                    #ShowTouchSymbol(30)
                    if TouchedPanelID == int(CorrectPos): # If mouse touchs correct panel
                        DoneCorrectResponse = 1
                        WaterPosInside()  # Move water nozzle to the inside position
                        NowDrinking = 0
                        CorrectNum += 1  # Increase the number of correct respon
                        TotalTouchNum+=1
                        mOngoingResultVar.set('CorrectNum:'+str(CorrectNum)+'  IncorrectNum:'+str(IncorrectNum)+'  TotalNum:'+str(TotalTouchNum)+'  Correct:'+str(round(CorrectNum*100.0/TotalTouchNum, 2))+'%')
                        Writer_TouchEventTxt.write(str(TrialNum) + '\tPanelTouched(Correct)\t' +str(TouchedPanelID)+'\t'+ str(TimeNow.year) + "/" + str(TimeNow.month) + "/" + str(TimeNow.day) + "\t" + str(TimeNow.hour) + ":" + str(TimeNow.minute) + "\t" + str(TimeNow.second) + "." + str(TimeNow.microsecond//1000) + "\n")  # Write the response on the text file
                        Writer_TouchEventCsv.write(str(TrialNum) + ',1,' +str(TouchedPanelID)+','+ str(TimeNow.year) + "," + str(TimeNow.month) + "," + str(TimeNow.day) + "," + str(TimeNow.hour) + "," + str(TimeNow.minute) + "," + str(TimeNow.second) + "." + str(TimeNow.microsecond//1000) + "\n")  # Write the response on the csv file
                        HidePanel(0)
                        HidePanel(1)
                        Timer_End(0)
                        WaterCueTurnOn()
                        Phase2 = 2  # Start reward phase
                    if TouchedPanelID != int(CorrectPos): # If mouse touchs wrong panel
                        WaterPosOutside()
                        if PunishWithLight == 'ON':
                            RoofLightTurnOn()  # Turn on roof light
                        IncorrectNum += 1
                        TotalTouchNum += 1
                        mOngoingResultVar.set('CorrectNum:' + str(CorrectNum) + '  IncorrectNum:' + str(IncorrectNum) + '  TotalNum:' + str(TotalTouchNum) + '  Correct(%):' + str(round(CorrectNum * 100.0 / TotalTouchNum, 2)))
                        Writer_TouchEventTxt.write(str(TrialNum) + '\tPanelTouched(Wrong)\t' +str(TouchedPanelID)+'\t'+ str(TimeNow.year) + "/" + str(TimeNow.month) + "/" + str(TimeNow.day) + "\t" + str(TimeNow.hour) + ":" + str(TimeNow.minute) + "\t" + str(TimeNow.second) + "." + str(TimeNow.microsecond//1000) + "\n")  # Write the response on the text file
                        Writer_TouchEventCsv.write(str(TrialNum) + ',0,' +str(TouchedPanelID)+','+ str(TimeNow.year) + "," + str(TimeNow.month) + "," + str(TimeNow.day) + "," + str(TimeNow.hour) + "," + str(TimeNow.minute) + "," + str(TimeNow.second) + "." + str(TimeNow.microsecond//1000) + "\n")  # Write the response on the csv file
                        HidePanel(0)
                        HidePanel(1)
                        Timer_End(0)  # End timer1
                        Timer_Start(0)  # Start punish timer
                        Phase2 = 5  # Start punishment phase
                if GetTimerSec(5) >= TimeLimit * 60:   # If time limit is exceeded
                    Timer_End(5)
                    Phase2 = 6
            if Phase2 == 2:  # Reward phase
                if NosePoking == 1 and NowDrinking == 0:    # If the mouse initiates nose poke
                    NowDrinking = 1
                    Timer_Start(0)  # Start lick timer
                if NowDrinking == 1:
                    if DoneCorrectResponse == 1 and GetTimerSec(0) >= LickDur:   # If lick time exceed the designated time
                        Timer_End(0) # End lick timer
                        WaterPosMiddle()    # Move water nozzle to the intermediate position
                        WaterCueTurnOff()
                        NowDrinking = 0
                        Timer_Start(0)  # Start ITI timer
                        Phase2 = 3

            if Phase2 == 3:   # ITI
                if GetTimerSec(0) >= Iti:  # If ITI is passed
                    Timer_End(0)
                    Phase2 = 0  # Go to the next trial
                if CorrectNum >= MaxCorrectNum or TotalTouchNum >= MaxTrialNum: # If mouse achieved criteria of finishing the task
                    Timer_End(5)
                    WaterPosMiddle()
                    WaterCueTurnOff()
                    Timer_Start(0)  # Timer for interval between task and arbitary water supply is started
                    Phase2 = 6  # Go to the AWS
            if Phase2 == 5:   # Punishment phase
                if GetTimerSec(0) >= PunishDur:    # If punishment time is passed
                    RoofLightTurnOff()
                    WaterPosMiddle()    # Move water nozzle to the intermediate position
                    Timer_End(0)  # End punishment timer1
                    Timer_Start(0)  # Start ITI timer
                    Phase2 = 3
            if Phase2==6:
                HidePanel(0)
                HidePanel(1)
                if CorrectNum < MaxCorrectNum and AwsOn=='ON':  # If mouse didn't achieved the max correct response
                    Timer_Start(0)
                    Phase2 = 7
                if CorrectNum == MaxCorrectNum or AwsOn=='OFF':  # If mouse achieved the max correct response
                    Phase2 = -1
            if Phase2==7:   # Wait until arbitary water suuply is started
                if GetTimerSec(0) >= 20:   # If the interval is past 60
                    Timer_End(0)
                    ArbitaryWaterSupplyDur=(MaxCorrectNum - CorrectNum) * LickDur * 1000    # Caliculate duration of complement water supply
                    StartArbitaryWaterSupply(ArbitaryWaterSupplyDur) # Start complement water supply
                    print("AWSstart")
                    Phase2=8
            if Phase2==8:
                if GetArbitaryWaterSupplyStat()==1: # If complement water supply is finished
                    Phase2 = -1

            if Phase2 == -1 or Phase2 == -2:  # Task finish phase
                DuringTask = 0
                WaterPosMiddle()
                ClearPanel()
                MakeWaterCueNonBlink()
                InfraredTurnOff()
                if NowRecording == 1:
                    SetEndRecordingTimer(60)
                if CorrectNum > 0 or IncorrectNum > 0:
                    CorrectRate = int(CorrectNum * 100.0 / TotalTouchNum)
                    Writer_TouchEventTxt.write('TotalNum:'+str(TotalTouchNum)+'  Correct num:'+str(CorrectNum)+'  Incorrect num:'+str(IncorrectNum)+'  Correct rate'+str(CorrectRate)+'%'+"\n")	#結果テキストの一番最後に成績のまとめを記入
                Writer_TouchEventTxt.write('TaskStartTime: ' + str(GetTaskStartedMonth()) + '/' + str(GetTaskStartedDay()) + ' ' + str(GetTaskStartedHour()) + ':' + str(GetTaskStartedMinute()) + ':' + str(
                    GetTaskStartedSecond()) + "\n")
                Writer_TouchEventTxt.write('TaskEndTime: ' + str(TimeNow.month) + '/' + str(TimeNow.day) + ' ' + str(TimeNow.hour) + ':' + str(TimeNow.minute) + ':' + str(
                    TimeNow.second + (TimeNow.microsecond // 1000) / 1000) + "\n")
                Writer_TouchEventTxt.write('MaxCorrectNum: '+str(MaxCorrectNum)+"\n")
                Writer_TouchEventTxt.write('MaxTrialNum: ' + str(MaxTrialNum) + "\n")
                Writer_TouchEventTxt.write('TimeLimit: ' + str(TimeLimit) + "\n")
                Writer_TouchEventTxt.write('PunishDur: ' + str(PunishDur) + "\n")
                Writer_TouchEventTxt.write('Iti: ' + str(Iti) + "\n")
                Writer_TouchEventTxt.write('LickDur: ' + str(LickDur) + "\n")
                Writer_TouchEventTxt.write('NextTask: ' + str(NextTask) + "\n")
                Writer_TouchEventTxt.write('NextTaskTh: ' + str(NextTaskTh)+"\n")
                Writer_TouchEventTxt.write('CorrectPos: ' + str(CorrectPos) + "\n")
                Writer_TouchEventTxt.write('PanelType: ' + str(PanelType) + "\n")
                Writer_TouchEventTxt.write('WaterCueType: ' + str(WaterCueType) + "\n")
                Writer_TouchEventTxt.write('LitPattern: ' + str(LitPattern) + "\n")
                Writer_TouchEventTxt.write('PunishWithLight: ' + str(PunishWithLight)+"\n")
                Writer_TouchEventTxt.write('RecordFPS: ' + str(RecordFPS) + "\n")
                Writer_TouchEventTxt.write('AWS: ' + AwsOn + "\n")
                Writer_TouchEventTxt.write('AWS_Latency: ' + str(AWS_Latency) + "\n")
                Writer_TouchEventTxt.close()
                Writer_TouchEventCsv.close()
                EndLickRecording()
                if CorrectRate >= NextTaskTh:
                    Task = NextTask
                #SendMail()
                SendMail(DeviceNameVar.get() + ' finished task '+str(Task)+'. Correct:' + str(CorrectNum) + ' Incorrect:' + str(IncorrectNum) + ' Correct:'+str(CorrectRate)+'% Dur:' + str(round(GetTimerSec(5) / 60,1)) + ' min', 'The task is finished.')
                TtlDelayStop()

                if IsHousingAnalysis == 1 and Phase2 == -1:  # If it is housing analysis
                    if CorrectRate >= NextTaskTh:  # If the score exceed the criteria to switch the next task
                        SwitchTask(NextTask)  # Onset task switch trigger
                        print("Task is switched to task#" + str(NextTask) + "  " + str(GetTaskStartedMonth()) + '/' + str(GetTaskStartedDay()) + ' ' + str(GetTaskStartedHour()) + ':' + str(GetTaskStartedMinute()) + ':' + str(GetTaskStartedSecond()))

                if IsHousingAnalysis == 0:
                    RoofLightTurnOn()
                Phase = 1  # Go back to the task-waiting phase
                Phase2 = 0
                Phase2_Init = 0
    return

def Task27():
    global Phase, Task
    Phase = 0
    Task = 27
    return
def Task28():
    global Phase, Task
    Phase = 0
    Task = 28
    return
def Task29():   # Go-NoGo task
    global Phase, Phase2, Task, SaveTrg, LoadTrg, NosePoking, DuringTask, NowRecording, RecordFPS

    Task = 29
    Phase0_Init=0
    Phase1_Init = 0
    Phase2_Init = 0
    while EndFlag == 0:
        OperantHouseUpdate()

        if Phase == -1:  # Back to the task select phase
            Phase = 0
            Task = 0
            break
        if Phase == 0:  # Parameter inputs
            if Phase0_Init == 0:
                LoadTrg = 1
                # Make GUI for the setting of the parameters for this task
                RemoveMainRightWidget() # Remove task buttons

                PutStartBackButton()    # Put start/back buttons
                mSpace = ttk.Label(MainWindowRightFrame, text=' ').grid(row=0, column=1)  # Used just as spacer

                mMaxCorrectNum = ttk.Label(MainWindowRightFrame, text='MaxCorrectNum').grid(row=0, column=2, sticky=W)    # Put label
                MaxCorrectNumVar = IntVar(MainWindowRoot)  # Declare variable receiving value from the entry field
                iMaxCorrectNum = ttk.Entry(MainWindowRightFrame, textvariable=MaxCorrectNumVar).grid(row=1, column=2) # Place entry field

                mTimeLimit = ttk.Label(MainWindowRightFrame, text='TimeLimit(min)').grid(row=0, column=3, sticky=W)  # Put label
                TimeLimitVar = IntVar(MainWindowRoot)  # Declare variable receiving value from the entry field
                iTimeLimit = ttk.Entry(MainWindowRightFrame, textvariable=TimeLimitVar).grid(row=1, column=3)  # Place entry field

                mPresentDur = ttk.Label(MainWindowRightFrame, text='PresentDur(s)').grid(row=0, column=4, sticky=W)
                PresentDurVar = IntVar(MainWindowRoot)
                iPresentDur = ttk.Entry(MainWindowRightFrame, textvariable=PresentDurVar).grid(row=1, column=4)

                mPunishDur = ttk.Label(MainWindowRightFrame, text='PunishDur(s)').grid(row=0, column=5, sticky=W)
                PunishDurVar = IntVar(MainWindowRoot)
                iPunishDur = ttk.Entry(MainWindowRightFrame, textvariable=PunishDurVar).grid(row=1, column=5)

                mIti = ttk.Label(MainWindowRightFrame, text='ITI(s)').grid(row=0, column=6, sticky=W)
                ItiVar = IntVar(MainWindowRoot)
                iIti = ttk.Entry(MainWindowRightFrame, textvariable=ItiVar).grid(row=1, column=6)

                mLickDur = ttk.Label(MainWindowRightFrame, text='LickDur(s)').grid(row=0, column=7, sticky=W)
                LickDurVar = IntVar(MainWindowRoot)
                iLickDur = ttk.Entry(MainWindowRightFrame, textvariable=LickDurVar).grid(row=1, column=7)

                mNextTask = ttk.Label(MainWindowRightFrame, text='NextTask#').grid(row=2, column=2, sticky=W)
                NextTaskVar = IntVar(MainWindowRoot)
                iNextTask = ttk.Entry(MainWindowRightFrame, textvariable=NextTaskVar).grid(row=3, column=2)

                mNextTaskTh = ttk.Label(MainWindowRightFrame, text='NextTaskTh(Correct%)').grid(row=2, column=3, sticky=W)
                NextTaskThVar = IntVar(MainWindowRoot)
                iNextTaskTh = ttk.Entry(MainWindowRightFrame, textvariable=NextTaskThVar).grid(row=3, column=3)

                mTaskType = ttk.Label(MainWindowRightFrame, text='TaskType').grid(row=2, column=4, sticky=W)    # Put label
                TaskTypeVar = StringVar(MainWindowRightFrame)  # Declare variable receiving value from the entry field
                tTaskType = OptionMenu(MainWindowRightFrame, TaskTypeVar, "Go", "NoGo").grid(row=3, column=4) # Place drop-down list

                mPunishLight = ttk.Label(MainWindowRightFrame, text='PunishLight').grid(row=2, column=5, sticky=W)
                PunishLightVar = StringVar(MainWindowRightFrame)
                tPunishLight = OptionMenu(MainWindowRightFrame, PunishLightVar, "ON", "OFF").grid(row=3, column=5)

                mPanelType = ttk.Label(MainWindowRightFrame, text='PanelType').grid(row=2, column=5, sticky=W)
                PanelTypeVar = StringVar(MainWindowRightFrame)
                tPanelType = OptionMenu(MainWindowRightFrame, PanelTypeVar, "Normal", "Blink", "Textured").grid(row=3, column=5)

                mWaterCueType = ttk.Label(MainWindowRightFrame, text='WaterCueType').grid(row=2, column=6, sticky=W)
                WaterCueTypeVar = StringVar(MainWindowRightFrame)
                tWaterCueType = OptionMenu(MainWindowRightFrame, WaterCueTypeVar, "Normal", "Blink").grid(row=3, column=6)

                #InitPanel()
                Phase0_Init = 1

        if LoadTrg == 1:  # If load trigger is on

            Str = "ParametersForTask" + str(Task)
            if os.path.exists(Str+'/MaxCorrectNum.dat') == True:  # If save file exists
                with open(Str+'/MaxCorrectNum.dat', 'rb') as PickleInst[Task]:
                    MaxCorrectNumVar.set(pickle.load(PickleInst[Task]))  # Load
            else:
                MaxCorrectNumVar.set(80)     # Default value
            if os.path.exists(Str+'/TimeLimit.dat') == True:  # If save file exists
                with open(Str+'/TimeLimit.dat', 'rb') as PickleInst[Task]:
                    TimeLimitVar.set(pickle.load(PickleInst[Task]))  # Load
            else:
                TimeLimitVar.set(90)     # Default value
            if os.path.exists(Str+'/PresentDur.dat') == True:  # If save file exists
                with open(Str+'/PresentDur.dat', 'rb') as PickleInst[Task]:
                    PresentDurVar.set(pickle.load(PickleInst[Task]))  # Load
            else:
                PresentDurVar.set(1)     # Default value

            if os.path.exists(Str+'/PunishDur.dat') == True:  # If save file exists
                with open(Str+'/PunishDur.dat', 'rb') as PickleInst[Task]:
                    PunishDurVar.set(pickle.load(PickleInst[Task]))  # Load
            else:
                PunishDurVar.set(1)     # Default value

            if os.path.exists(Str+'/Iti.dat') == True:  # If save file exists
                with open(Str+'/Iti.dat', 'rb') as PickleInst[Task]:
                    ItiVar.set(pickle.load(PickleInst[Task]))  # Load
            else:
                ItiVar.set(1)     # Default value
            if os.path.exists(Str+'/LickDur.dat') == True:  # If save file exists
                with open(Str+'/LickDur.dat', 'rb') as PickleInst[Task]:
                    LickDurVar.set(pickle.load(PickleInst[Task]))  # Load
            else:
                LickDurVar.set(1)     # Default value
            if os.path.exists(Str+'/NextTaskTh.dat') == True:  # If save file exists
                with open(Str+'/NextTaskTh.dat', 'rb') as PickleInst[Task]:
                    NextTaskThVar.set(pickle.load(PickleInst[Task]))  # Load
            else:
                NextTaskThVar.set(1)     # Default value
            if os.path.exists(Str+'/NextTask.dat') == True:  # If save file exists
                with open(Str+'/NextTask.dat', 'rb') as PickleInst[Task]:
                    NextTaskVar.set(pickle.load(PickleInst[Task]))  # Load
            else:
                NextTaskVar.set(1)     # Default value
            if os.path.exists(Str+'/TaskType.dat') == True:  # If save file exists
                with open(Str+'/TaskType.dat', 'rb') as PickleInst[Task]:
                    TaskTypeVar.set(pickle.load(PickleInst[Task]))  # Load
            else:
                TaskTypeVar.set('Go')     # Default value
            if os.path.exists(Str+'/PunishLight.dat') == True:  # If save file exists
                with open(Str+'/PunishLight.dat', 'rb') as PickleInst[Task]:
                    PunishLightVar.set(pickle.load(PickleInst[Task]))  # Load
            else:
                PunishLightVar.set('ON')     # Default value

            if os.path.exists(Str+'/PanelType.dat') == True:  # If save file exists
                with open(Str+'/PanelType.dat', 'rb') as PickleInst[Task]:
                    PanelTypeVar.set(pickle.load(PickleInst[Task]))  # Load
            else:
                PanelTypeVar.set('Normal')     # Default value

            if os.path.exists(Str+'/WaterCueType.dat') == True:  # If save file exists
                with open(Str+'/WaterCueType.dat', 'rb') as PickleInst[Task]:
                    WaterCueTypeVar.set(pickle.load(PickleInst[Task]))  # Load
            else:
                WaterCueTypeVar.set('Normal')     # Default value
            LoadTrg = 0

        if SaveTrg == 1:    # If save trigger is on
            # Parameters of each task are saved into different folder
            Str="ParametersForTask"+str(Task)   # Path to the folder for saving of parameters
            if os.path.exists(Str) == False:    # If folder for saving parameters is not exist
                os.mkdir(Str)   # Make folder for saving
            with open(Str+'/MaxCorrectNum.dat', 'wb') as PickleInst[Task]:
                pickle.dump(MaxCorrectNumVar.get(),PickleInst[Task])     # Save
            with open(Str+'/TimeLimit.dat', 'wb') as PickleInst[Task]:
                pickle.dump(TimeLimitVar.get(),PickleInst[Task])     # Save
            with open(Str+'/PresentDur.dat', 'wb') as PickleInst[Task]:
                pickle.dump(PresentDurVar.get(), PickleInst[Task])     # Save
            with open(Str+'/PunishDur.dat', 'wb') as PickleInst[Task]:
                pickle.dump(PunishDurVar.get(), PickleInst[Task])     # Save
            with open(Str+'/Iti.dat', 'wb') as PickleInst[Task]:
                pickle.dump(ItiVar.get(), PickleInst[Task])     # Save
            with open(Str+'/LickDur.dat', 'wb') as PickleInst[Task]:
                pickle.dump(LickDurVar.get(), PickleInst[Task])     # Save
            with open(Str+'/NextTaskTh.dat', 'wb') as PickleInst[Task]:
                pickle.dump(NextTaskThVar.get(), PickleInst[Task])     # Save
            with open(Str + '/NextTask.dat', 'wb') as PickleInst[Task]:
                pickle.dump(NextTaskVar.get(), PickleInst[Task])  # Save
            with open(Str+'/TaskType.dat', 'wb') as PickleInst[Task]:
                pickle.dump(TaskTypeVar.get(), PickleInst[Task])     # Save
            with open(Str+'/PunishLight.dat', 'wb') as PickleInst[Task]:
                pickle.dump(PunishLightVar.get(), PickleInst[Task])     # Save
            with open(Str+'/PanelType.dat', 'wb') as PickleInst[Task]:
                pickle.dump(PanelTypeVar.get(), PickleInst[Task])     # Save
            with open(Str+'/WaterCueType.dat', 'wb') as PickleInst[Task]:
                pickle.dump(WaterCueTypeVar.get(), PickleInst[Task])     # Save
            SaveTrg = 0


        if Phase == 1:  # Wait for starting of task
            if Phase1_Init == 0:
                PutPreTaskButton()
                mStatusVar = StringVar(MainWindowRoot)
                mStatus = ttk.Label(MainWindowRightFrame, textvariable=mStatusVar)
                mStatus.place(x=10, y=0)
                mOngoingResultVar = StringVar(MainWindowRoot)
                Phase1_Init = 1
            mStatusVar.set('Go/NoGo task (' + str(Task) + ')    Waiting...')
            if IsStartTime() == 1:
                StartNow()

        if Phase == 2:  # During task
            if Phase2_Init == 0: # Initialization of the task
                PutEndTaskNowButton()
                mStatusVar.set('Go/NoGo task (' + str(Task) + ')    Start time ' + str(TaskStartedMonth) + '/' + str(TaskStartedDay) + ' ' + str(TaskStartedHour) + ':' + str(TaskStartedMinute) + '    Running')
                mOngoingResult = ttk.Label(MainWindowRightFrame, textvariable=mOngoingResultVar)
                mOngoingResult.place(x=10, y=18)

                # Convert StringVars of parameters into integer or normal string to use in the following
                MaxCorrectNum=int(MaxCorrectNumVar.get())
                TimeLimit = int(TimeLimitVar.get())
                PresentDur = int(PresentDurVar.get())
                PunishDur = int(PunishDurVar.get())
                Iti = int(ItiVar.get())
                LickDur = int(LickDurVar.get())
                NextTaskTh = int(NextTaskThVar.get())
                NextTask = int(NextTaskVar.get())
                TaskType = TaskTypeVar.get()
                PunishLight = PunishLightVar.get()
                PanelType = PanelTypeVar.get()
                WaterCueType = WaterCueTypeVar.get()


                # Declar local variables for this task
                CorrectNum=0
                IncorrectNum=0
                TouchNum=0
                CorrectRate=0
                Writer_TouchEventTxt = open(Path + "/" + str(TimeNow.year) + "_" + str(TimeNow.month) + "_" + str(TimeNow.day) + " " + str(TimeNow.hour) + "h" + str(TimeNow.minute) + "m Task" + str(Task) + " Touch.txt", 'w')  # Initialize the text exporter
                Writer_TouchEventCsv = open(Path + "/" + str(TimeNow.year) + "_" + str(TimeNow.month) + "_" + str(TimeNow.day) + " " + str(TimeNow.hour) + "h" + str(TimeNow.minute) + "m Task" + str(Task) + " Touch.csv", 'w')  # Initialize the text exporter
                StartLickRecording()
                ArbitaryWaterSupplyDur=0

                DuringTask = 1
                DoneCorrectResponse = 1
                RoofLightTurnOff()
                InfraredTurnOn()
                WaterCueTurnOn()
                WaterPosInside()
                NowDrinking = 0
                NowPunishing = 0
                AutoWaterSupplyNum = 0
                AWS_Latency=0
                StartRecording()    # Start camera capturing and sending of TTL

                if PanelType == 'Normal':
                    CreateNormalPanel(0)
                if PanelType == 'Blink':
                    CreateBlinkPanel(0)
                if PanelType == 'Textured':
                    CreateTexturedPanel(0)
                if WaterCueType == 'Blink':
                    MakeWaterCueBlink()  # Make water cue blink

                Writer_TouchEventTxt.write('TrialNum\tResult\t\t\tyyyy/mm/dd\th:m\ts\n')  # Write item name
                TrialNum=0
                TtlStart()
                Timer_Start(5)  # Task time limit timer start
                Phase2 = 2
                Phase2_Init = 1
                print("Task #" + str(Task) + " is started at " + str(GetTaskStartedMonth()) + '/' + str(GetTaskStartedDay()) + ' ' + str(GetTaskStartedHour()) + ':' + str(
                    GetTaskStartedMinute()) + ':' + str(GetTaskStartedSecond()))

            if Phase2 == 0:   # Initiation of new trial
                DoneCorrectResponse=0
                ShowPanel(0)
                TrialNum += 1
                Timer_Start(0)  # Start the latency timer
                Phase2 += 1
            if Phase2 == 1:   # Panel presentation
                TouchedPanelID = DetectPanelTouch()  # Examine which panel is touched (return panel ID. If none of the panels touched, return -1)
                if (TaskType == 'Go' and TouchedPanelID!=-1) or (TaskType=='NoGo' and GetTimerSec(0) >= PresentDur): # If mouse responses correctly
                    #ShowTouchSymbol(30)
                    DoneCorrectResponse = 1
                    WaterPosInside()    # Move water nozzle to the inside position
                    WaterCueTurnOn()
                    NowDrinking = 0
                    CorrectNum += 1      # Increase the number of correct response
                    TouchNum+=1
                    if TaskType == 'Go':
                        mOngoingResultVar.set(
                            'CorrectNum:' + str(CorrectNum) + '  IncorrectNum:' + str(IncorrectNum) + '  TotalNum:' + str(TouchNum) + '  Correct:' + str(CorrectNum * 100.0 / TouchNum) + '%')
                        Writer_TouchEventTxt.write(str(TrialNum)+'\tPanelTouched(Correct)\t'+ str(TimeNow.year)+"/"+str(TimeNow.month)+"/"+str(TimeNow.day)+"\t"+str(TimeNow.hour)+":"+str(TimeNow.minute)+"\t"+str(TimeNow.second)+"."+str(TimeNow.microsecond//1000)+"\n") # Write the response on the text file
                        Writer_TouchEventCsv.write(str(TrialNum) + ',1,' + str(TimeNow.year) + "," + str(TimeNow.month) + "," + str(TimeNow.day) + "," + str(TimeNow.hour) + "," + str(TimeNow.minute) + "," + str(TimeNow.second) + "." + str(TimeNow.microsecond//1000)+"\n")  # Write the response on the csv file
                    if TaskType == 'NoGo':
                        mOngoingResultVar.set('CorrectNum:' + str(CorrectNum) + '  IncorrectNum:' + str(IncorrectNum) + '  TotalNum:' + str(TouchNum) + '  Correct:' + str(
                            CorrectNum * 100.0 / TouchNum) + '%')
                        Writer_TouchEventTxt.write(str(TrialNum)+'\tPanelIgnored(Correct)\t'+str(TimeNow.year)+"/"+str(TimeNow.month)+"/"+str(TimeNow.day)+"\t"+str(TimeNow.hour)+":"+str(TimeNow.minute)+"\t"+str(TimeNow.second)+"."+str(TimeNow.microsecond//1000)+"\n") # Write the response on the text file
                        Writer_TouchEventCsv.write(str(TrialNum) + ',1,' + str(TimeNow.year) + "," + str(TimeNow.month) + "," + str(TimeNow.day) + "," + str(TimeNow.hour) + "," + str(TimeNow.minute) + "," + str(TimeNow.second) + "." + str(TimeNow.microsecond//1000)+"\n")  # Write the response on the csv file
                    HidePanel(0)
                    Timer_End(0)
                    WaterCueTurnOn()
                    Phase2 = 2  # Start reward phase
                if (TaskType == 'NoGo' and TouchedPanelID!=-1) or (TaskType =='Go' and GetTimerSec(0) >= PresentDur):  # If mouse responses incorrectly
                    NowPunishing = 1
                    WaterPosOutside()
                    if PunishLight =='ON':
                        RoofLightTurnOn()   # Turn on roof light
                    IncorrectNum += 1
                    TouchNum += 1
                    if TaskType == 'Go':
                        mOngoingResultVar.set('CorrectNum:' + str(CorrectNum) + '  IncorrectNum:' + str(IncorrectNum) + '  TotalNum:' + str(TouchNum) + '  Correct:' + str(
                            CorrectNum * 100.0 / TouchNum) + '%')
                        Writer_TouchEventTxt.write(str(TrialNum) + '\tPanelIgnored(Wrong)\t' + str(TimeNow.year) + "/" + str(TimeNow.month) + "/" + str(TimeNow.day) + "\t" + str(TimeNow.hour) + ":" + str(TimeNow.minute) + "\t" + str(TimeNow.second) + "." + str(TimeNow.microsecond//1000)+"\n")  # Write the response on the text file
                        Writer_TouchEventCsv.write(str(TrialNum) + ',0,' + str(TimeNow.year) + "," + str(TimeNow.month) + "," + str(TimeNow.day) + "," + str(TimeNow.hour) + "," + str(TimeNow.minute) + "," + str(TimeNow.second) + "." + str(TimeNow.microsecond//1000)+"\n")  # Write the response on the csv file
                    if TaskType == 'NoGo':
                        mOngoingResultVar.set('CorrectNum:' + str(CorrectNum) + '  IncorrectNum:' + str(IncorrectNum) + '  TotalNum:' + str(TouchNum) + '  Correct:' + str(
                            CorrectNum * 100.0 / TouchNum) + '%')
                        Writer_TouchEventTxt.write(str(TrialNum) + '\tPanelTouched(Wrong)\t' + str(TimeNow.year) + "/" + str(TimeNow.month) + "/" + str(TimeNow.day) + "\t" + str(TimeNow.hour) + ":" + str(TimeNow.minute) + "\t" + str(TimeNow.second) + "." + str(TimeNow.microsecond//1000)+ "\n")  # Write the response on the text file
                        Writer_TouchEventCsv.write(str(TrialNum) + ',0,' + str(TimeNow.year) + "," + str(TimeNow.month) + "," + str(TimeNow.day) + "," + str(TimeNow.hour) + "," + str(TimeNow.minute) + "," + str(TimeNow.second) + "." + str(TimeNow.microsecond//1000)+"\n")  # Write the response on the csv file
                    HidePanel(0)
                    Timer_End(0)    # End timer1
                    Timer_Start(0)  # Start punish timer
                    Phase2 = 5 # Start punishment phase
                if GetTimerSec(5) >= TimeLimit * 60:   # If time limit is exceeded
                    Timer_End(5)
                    Phase2 = 6
            if Phase2 == 2:  # Reward phase
                if NosePoking == 1 and NowDrinking == 0:    # If the mouse initiates nose poke
                    NowDrinking = 1
                    Timer_Start(0)  # Start lick timer
                if NowDrinking == 1:
                    if DoneCorrectResponse == 1 and GetTimerSec(0) >= LickDur:   # If lick time exceed the designated time
                        Timer_End(0) # End lick timer
                        WaterPosMiddle()    # Move water nozzle to the intermediate position
                        WaterCueTurnOff()
                        NowDrinking = 0
                        Timer_Start(0)  # Start ITI timer
                        Phase2 = 3
            if Phase2 == 3:   # ITI
                if GetTimerSec(0) >= Iti:  # If ITI is passed
                    Timer_End(0)
                    Phase2 = 0  # Go to the next trial
                if CorrectNum >= MaxCorrectNum:
                    Timer_End(5)
                    Phase2=6 # Go to the task finish phase
            if Phase2 == 5:   # Punishment phase
                if GetTimerSec(0) >= PunishDur:    # If punishment time is passed
                    RoofLightTurnOff()
                    NowPunishing = 0
                    WaterPosMiddle()    # Move water nozzle to the intermediate position
                    Timer_End(0)  # End punishment timer1
                    Timer_Start(0)  # Start ITI timer
                    Phase2 = 3
            if Phase2 == 6:
                HidePanel(0)
                if CorrectNum < MaxCorrectNum:    # If mouse didn't achieved the max correct response
                    Timer_Start(0)  # Timer for interval between task and arbitary water supply is started
                    Phase2 = 7
                if CorrectNum == MaxCorrectNum:    # If mouse achieved the max correct response
                    Phase2 = -1
            if Phase2 == 7:  # Wait until arbitary water suuply is started
                if GetTimerSec(0) >= AWS_Latency:  # If the interval is past 60 20
                    Timer_End(0)
                    ArbitaryWaterSupplyDur = (MaxCorrectNum - CorrectNum) * LickDur * 1000  # Caliculate duration of complement water supply
                    StartArbitaryWaterSupply(ArbitaryWaterSupplyDur)  # Start complement water supply
                    #print("AWSstart")
                    Phase2 = 8
            if Phase2 == 8:
                if GetArbitaryWaterSupplyStat() == 1:  # If complement water supply is finished
                    Phase2 = -1

            if Phase2 == -1 or Phase2 == -2:  # Task finish phase   #
                DuringTask = 0
                WaterPosMiddle()
                #if Panel!=null:
                ClearPanel()
                InfraredTurnOff()
                NowPunishing = 0
                if NowRecording == 1:
                    SetEndRecordingTimer(60)
                if CorrectNum > 0 or IncorrectNum > 0:
                    CorrectRate = int(CorrectNum * 100.0 / (CorrectNum + IncorrectNum))
                    Writer_TouchEventTxt.write('TotalNum:'+str(CorrectNum+IncorrectNum)+'  Correct num:'+str(CorrectNum)+'  Incorrect num:'+str(IncorrectNum)+'  Correct rate'+str(CorrectRate)+'%'+"\n")	#結果テキストの一番最後に成績のまとめを記入
                Writer_TouchEventTxt.write('TaskStartTime: ' + str(GetTaskStartedMonth()) + '/' + str(GetTaskStartedDay()) + ' ' + str(GetTaskStartedHour()) + ':' + str(GetTaskStartedMinute()) + ':' + str(
                    GetTaskStartedSecond()) + "\n")
                Writer_TouchEventTxt.write('TaskEndTime: ' + str(TimeNow.month) + '/' + str(TimeNow.day) + ' ' + str(TimeNow.hour) + ':' + str(TimeNow.minute) + ':' + str(TimeNow.second + (TimeNow.microsecond // 1000) / 1000) + "\n")
                Writer_TouchEventTxt.write('MaxCorrectNum: '+str(MaxCorrectNum)+"\n")
                Writer_TouchEventTxt.write('TimeLimit: ' + str(TimeLimit) + "\n")
                Writer_TouchEventTxt.write('PresentDur: ' + str(PresentDur)+"\n")
                Writer_TouchEventTxt.write('PunishDur: ' + str(PunishDur)+"\n")
                Writer_TouchEventTxt.write('Iti: ' + str(Iti)+"\n")
                Writer_TouchEventTxt.write('LickDur: ' + str(LickDur)+"\n")
                Writer_TouchEventTxt.write('NextTaskTh: ' + str(NextTaskTh)+"\n")
                Writer_TouchEventTxt.write('NextTask: ' + str(NextTask)+"\n")
                Writer_TouchEventTxt.write('TaskType: ' + str(TaskType)+"\n")
                Writer_TouchEventTxt.write('PunishLight: ' + str(PunishLight)+"\n")
                Writer_TouchEventTxt.write('PanelType: ' + str(PanelType)+"\n")
                Writer_TouchEventTxt.write('WaterCueType: ' + str(WaterCueType)+"\n")
                Writer_TouchEventTxt.write('RecordFPS: ' + str(RecordFPS) + "\n")
                Writer_TouchEventTxt.write('AWS_Latency: ' + str(AWS_Latency) + "\n")
                Writer_TouchEventTxt.close()
                Writer_TouchEventCsv.close()
                EndLickRecording()
                if CorrectRate >= NextTaskTh:
                    Task = NextTask
                SendMail(DeviceNameVar.get()+' finished task '+str(Task)+'. Correct:'+str(CorrectNum)+' Incorrect:'+str(IncorrectNum)+' Dur:'+str(round(GetTimerSec(5) / 60,1))+' min','The task is finished.')
                TtlDelayStop()

                if IsHousingAnalysis == 1 and Phase2 == -1:  # If it is housing analysis
                    if CorrectRate >= NextTaskTh:  # If the score exceed the criteria to switch the next task
                        SwitchTask(NextTask)  # Onset task switch trigger
                        print("Task is switched to task#" + str(NextTask) + "  " + str(GetTaskStartedMonth()) + '/' + str(GetTaskStartedDay()) + ' ' + str(GetTaskStartedHour()) + ':' + str(GetTaskStartedMinute()) + ':' + str(GetTaskStartedSecond()))
                if IsHousingAnalysis == 0:
                    RoofLightTurnOn()
                Phase = 1  # Go back to the task-waiting phase
                Phase2 = 0
                Phase2_Init = 0
    return

def Task30():   # Go-NoGo task without touch monitor
    global Phase, Phase2, Init, Task, SaveTrg, LoadTrg, NosePoking, DuringTask, NowRecording, RecordFPS

    Task = 30
    Init = 0
    while EndFlag == 0:
        OperantHouseUpdate()    # House keeping funciton (this function must be executed every frame)

        if Phase == -1:  # Back to the task select phase
            Phase = 0
            Task = 0
            break
        if Phase == 0:  # Parameter inputs
            if Init == 0: # If the initialization of GUI has not been done
                LoadTrg = 1
                # Make GUI for the setting of the parameters for this task
                RemoveMainRightWidget()  # Remove task buttons

                PutStartBackButton()  # Put start/back buttons
                mSpace = ttk.Label(MainWindowRightFrame, text=' ').grid(row=0, column=1)  # Used just as spacer

                mMaxCorrectNum = ttk.Label(MainWindowRightFrame, text='MaxCorrectNum').grid(row=0, column=2, sticky=W)  # Put label
                MaxCorrectNumVar = IntVar(MainWindowRoot)  # Declare variable receiving value from the entry field
                iMaxCorrectNum = ttk.Entry(MainWindowRightFrame, textvariable=MaxCorrectNumVar).grid(row=1, column=2)  # Place entry field

                mPresentDur = ttk.Label(MainWindowRightFrame, text='PresentDur(s)').grid(row=0, column=3, sticky=W)
                PresentDurVar = IntVar(MainWindowRoot)
                iPresentDur = ttk.Entry(MainWindowRightFrame, textvariable=PresentDurVar).grid(row=1, column=3)

                mPunishDur = ttk.Label(MainWindowRightFrame, text='PunishDurDur(s)').grid(row=0, column=4, sticky=W)
                PunishDurVar = IntVar(MainWindowRoot)
                iPunishDur = ttk.Entry(MainWindowRightFrame, textvariable=PunishDurVar).grid(row=1, column=4)

                mIti = ttk.Label(MainWindowRightFrame, text='ITI(s)').grid(row=0, column=5, sticky=W)
                ItiVar = IntVar(MainWindowRoot)
                iIti = ttk.Entry(MainWindowRightFrame, textvariable=ItiVar).grid(row=1, column=5)

                mLickDur = ttk.Label(MainWindowRightFrame, text='LickDur(s)').grid(row=0, column=6, sticky=W)
                LickDurVar = IntVar(MainWindowRoot)
                iLickDur = ttk.Entry(MainWindowRightFrame, textvariable=LickDurVar).grid(row=1, column=6)

                mNextTask = ttk.Label(MainWindowRightFrame, text='NextTask#').grid(row=0, column=7, sticky=W)
                NextTaskVar = IntVar(MainWindowRoot)
                iNextTask = ttk.Entry(MainWindowRightFrame, textvariable=NextTaskVar).grid(row=1, column=7)

                mNextTaskTh = ttk.Label(MainWindowRightFrame, text='NextTaskTh(Correct%)').grid(row=2, column=2, sticky=W)
                NextTaskThVar = IntVar(MainWindowRoot)
                iNextTaskTh = ttk.Entry(MainWindowRightFrame, textvariable=NextTaskThVar).grid(row=3, column=2)

                mTaskType = ttk.Label(MainWindowRightFrame, text='TaskType').grid(row=2, column=3, sticky=W)  # Put label
                TaskTypeVar = StringVar(MainWindowRightFrame)  # Declare variable receiving value from the entry field
                tTaskType = OptionMenu(MainWindowRightFrame, TaskTypeVar, "Go", "NoGo").grid(row=3, column=3)  # Place drop-down list

                mPunishLight = ttk.Label(MainWindowRightFrame, text='PunishLight').grid(row=2, column=4, sticky=W)
                PunishLightVar = StringVar(MainWindowRightFrame)
                tPunishLight = OptionMenu(MainWindowRightFrame, PunishLightVar, "ON", "OFF").grid(row=3, column=4)

                mPanelType = ttk.Label(MainWindowRightFrame, text='PanelType').grid(row=2, column=5, sticky=W)
                PanelTypeVar = StringVar(MainWindowRightFrame)
                tPanelType = OptionMenu(MainWindowRightFrame, PanelTypeVar, "Normal", "Blink", "Textured").grid(row=3, column=5)

                mWaterCueType = ttk.Label(MainWindowRightFrame, text='WaterCueType').grid(row=2, column=6, sticky=W)
                WaterCueTypeVar = StringVar(MainWindowRightFrame)
                tWaterCueType = OptionMenu(MainWindowRightFrame, WaterCueTypeVar, "Normal", "Blink").grid(row=3, column=6)

                Init = 1

        if LoadTrg == 1:  # If load trigger is on

            Str = "ParametersForTask" + str(Task)
            if os.path.exists(Str + '/MaxCorrectNum.dat') == True:  # If save file exists
                with open(Str + '/MaxCorrectNum.dat', 'rb') as PickleInst[Task]:
                    MaxCorrectNumVar.set(pickle.load(PickleInst[Task]))  # Load the saved parameter data
            else:
                MaxCorrectNumVar.set(80)  # Default value

            if os.path.exists(Str + '/PresentDur.dat') == True:  # If save file exists
                with open(Str + '/PresentDur.dat', 'rb') as PickleInst[Task]:
                    PresentDurVar.set(pickle.load(PickleInst[Task]))  # Load
            else:
                PresentDurVar.set(1)  # Default value

            if os.path.exists(Str + '/PunishDur.dat') == True:  # If save file exists
                with open(Str + '/PunishDur.dat', 'rb') as PickleInst[Task]:
                    PunishDurVar.set(pickle.load(PickleInst[Task]))  # Load
            else:
                PunishDurVar.set(1)  # Default value

            if os.path.exists(Str + '/Iti.dat') == True:  # If save file exists
                with open(Str + '/Iti.dat', 'rb') as PickleInst[Task]:
                    ItiVar.set(pickle.load(PickleInst[Task]))  # Load
            else:
                ItiVar.set(1)  # Default value
            if os.path.exists(Str + '/LickDur.dat') == True:  # If save file exists
                with open(Str + '/LickDur.dat', 'rb') as PickleInst[Task]:
                    LickDurVar.set(pickle.load(PickleInst[Task]))  # Load
            else:
                LickDurVar.set(1)  # Default value
            if os.path.exists(Str + '/NextTask.dat') == True:  # If save file exists
                with open(Str + '/NextTask.dat', 'rb') as PickleInst[Task]:
                    NextTaskVar.set(pickle.load(PickleInst[Task]))  # Load
            else:
                NextTaskVar.set(1)  # Default value
            if os.path.exists(Str + '/NextTaskTh.dat') == True:  # If save file exists
                with open(Str + '/NextTaskTh.dat', 'rb') as PickleInst[Task]:
                    NextTaskThVar.set(pickle.load(PickleInst[Task]))  # Load
            else:
                NextTaskThVar.set(1)  # Default value
            if os.path.exists(Str + '/TaskType.dat') == True:  # If save file exists
                with open(Str + '/TaskType.dat', 'rb') as PickleInst[Task]:
                    TaskTypeVar.set(pickle.load(PickleInst[Task]))  # Load
            else:
                TaskTypeVar.set('Go')  # Default value
            if os.path.exists(Str + '/PunishLight.dat') == True:  # If save file exists
                with open(Str + '/PunishLight.dat', 'rb') as PickleInst[Task]:
                    PunishLightVar.set(pickle.load(PickleInst[Task]))  # Load
            else:
                PunishLightVar.set('ON')  # Default value

            if os.path.exists(Str + '/PanelType.dat') == True:  # If save file exists
                with open(Str + '/PanelType.dat', 'rb') as PickleInst[Task]:
                    PanelTypeVar.set(pickle.load(PickleInst[Task]))  # Load
            else:
                PanelTypeVar.set('Normal')  # Default value

            if os.path.exists(Str + '/WaterCueType.dat') == True:  # If save file exists
                with open(Str + '/WaterCueType.dat', 'rb') as PickleInst[Task]:
                    WaterCueTypeVar.set(pickle.load(PickleInst[Task]))  # Load
            else:
                WaterCueTypeVar.set('Normal')  # Default value
            LoadTrg = 0

        if SaveTrg == 1:  # If save trigger is on
            # Parameters of each task are saved into different folder
            Str = "ParametersForTask" + str(Task)  # Path to the folder for saving of parameters
            if os.path.exists(Str) == False:  # If folder for saving parameters is not exist
                os.mkdir(Str)  # Make folder for saving
            with open(Str + '/MaxCorrectNum.dat', 'wb') as PickleInst[Task]:
                pickle.dump(MaxCorrectNumVar.get(), PickleInst[Task])  # Save
            with open(Str + '/PresentDur.dat', 'wb') as PickleInst[Task]:
                pickle.dump(PresentDurVar.get(), PickleInst[Task])  # Save
            with open(Str + '/PunishDur.dat', 'wb') as PickleInst[Task]:
                pickle.dump(PunishDurVar.get(), PickleInst[Task])  # Save
            with open(Str + '/Iti.dat', 'wb') as PickleInst[Task]:
                pickle.dump(ItiVar.get(), PickleInst[Task])  # Save
            with open(Str + '/LickDur.dat', 'wb') as PickleInst[Task]:
                pickle.dump(LickDurVar.get(), PickleInst[Task])  # Save
            with open(Str + '/NextTaskTh.dat', 'wb') as PickleInst[Task]:
                pickle.dump(NextTaskThVar.get(), PickleInst[Task])  # Save
            with open(Str + '/NextTask.dat', 'wb') as PickleInst[Task]:
                pickle.dump(NextTaskVar.get(), PickleInst[Task])  # Save
            with open(Str + '/TaskType.dat', 'wb') as PickleInst[Task]:
                pickle.dump(TaskTypeVar.get(), PickleInst[Task])  # Save
            with open(Str + '/PunishLight.dat', 'wb') as PickleInst[Task]:
                pickle.dump(PunishLightVar.get(), PickleInst[Task])  # Save
            with open(Str + '/PanelType.dat', 'wb') as PickleInst[Task]:
                pickle.dump(PanelTypeVar.get(), PickleInst[Task])  # Save
            with open(Str + '/WaterCueType.dat', 'wb') as PickleInst[Task]:
                pickle.dump(WaterCueTypeVar.get(), PickleInst[Task])  # Save
            SaveTrg = 0

        if Phase == 1:  # Wait for starting of task
            if Init == 0:   # If the task initialization has not been done
                PutPreTaskButton() # Put "start", "time+", "time-", "back" button in the left of the main window
                mStatusVar = StringVar(MainWindowRoot)
                mStatus = ttk.Label(MainWindowRightFrame, textvariable=mStatusVar)
                mStatus.place(x=10, y=0)
                mOngoingResultVar = StringVar(MainWindowRoot)
                Init = 1    # 1 means initialization has been done
            mStatusVar.set('Go/NoGo task (' + str(Task) + ')    Waiting...')
        if Phase == 2:  # During task
            if Init == 0:  # Initialization of the task
                PutEndTaskNowButton()   # Put "task end" button
                mStatusVar.set('Go/NoGo task (' + str(Task) + ')    Start time ' + str(TaskStartedMonth) + '/' + str(TaskStartedDay) + ' ' + str(TaskStartedHour) + ':' + str(TaskStartedMinute) + '    Running')
                mOngoingResult = ttk.Label(MainWindowRightFrame, textvariable=mOngoingResultVar)
                mOngoingResult.place(x=10, y=18)

                # Convert StringVars of parameters into integer or normal string to use in the following processes
                MaxCorrectNum = int(MaxCorrectNumVar.get())
                PresentDur = int(PresentDurVar.get())
                PunishDur = int(PunishDurVar.get())
                Iti = int(ItiVar.get())
                LickDur = int(LickDurVar.get())
                NextTaskTh = int(NextTaskThVar.get())
                NextTask = int(NextTaskVar.get())
                TaskType = TaskTypeVar.get()
                PunishLight = PunishLightVar.get()
                PanelType = PanelTypeVar.get()
                WaterCueType = WaterCueTypeVar.get()

                # Declar local variables for this task
                TrialNum = 0    # The number of the trial in this task (For the task result)
                TotalCorrectNum = 0 # Correct number in this task (For the task result)
                TotalIncorrectNum = 0   # Incorrect number in this task (For the task result)
                CorrectRate = 0 # Correct rate of this task
                # Ready for text exporting of the result
                Writer_TouchEventTxt = open(Path + "/" + str(TimeNow.year) + "_" + str(TimeNow.month) + "_" + str(TimeNow.day) + " " + str(TimeNow.hour) + "h" + str(TimeNow.minute) + "m Task" + str(Task) +  " Touch.txt", 'w')  # Initialize the text exporter
                # Ready for csv exporting of the result
                Writer_TouchEventCsv = open(Path + "/" + str(TimeNow.year) + "_" + str(TimeNow.month) + "_" + str(TimeNow.day) + " " + str(TimeNow.hour) + "h" + str(TimeNow.minute) + "m Task" + str(Task) +  " Touch.csv",'w')  # Initialize the text exporter
                StartLickRecording()    # Start lick event recording

                DuringTask = 1  # This value is 1 all time during the task
                DoneCorrectResponse = 1
                RoofLightTurnOff()
                InfraredTurnOn()
                HoleWaterCueTurnOn(0)   # parameter: panel ID
                #WaterPosInside()
                NowDrinking = 0
                NowPunishing = 0
                TotalCorrectNum = 0 # For the caliculation of the correct rate
                TotalIncorrectNum = 0   # For the caliculation of the correct rate
                AutoWaterSupplyNum = 0

                AWS_Latency=20
                StartRecording()  # Start camera capturing and sending of TTL

                Writer_TouchEventTxt.write('TrialNum\tResult\t\t\tyyyy/mm/dd\th:m\ts\n')  # Write item name
                TrialNum = 0
                TtlStart()  # Start TTL output

                NowDrinking = 1 # 1 means now the mouse is allowed to lick
                Timer_Start(0)  # Start lick timer No.0
                Phase2 = 2  # Phase in the task
                Init = 1    # Initialization is done only when this value is 1

            if Phase2 == 0:  # Initiation of new trial
                DoneCorrectResponse = 0
                HoleCueTurnOn(0)    # Onset hole cue
                TrialNum += 1
                Timer_Start(0)  # Start the latency timer
                Phase2 += 1
            if Phase2 == 1:  # Panel presentation
                TouchedPanelID = DetectHoleTouch(0)  # Examine which panel is touched (return panel ID. If none of the panels touched, return -1)
                Trg = 0
                if PanelType == 'Blink':    # If panel type is "blink"
                    if TimeNow.microsecond // 100000 % 2 == 0: # Turn off or turn on every 100ms
                        HoleCueTurnOff(0)
                    if TimeNow.microsecond // 100000 % 2 == 1: # Turn off or turn on every 100ms
                        HoleCueTurnOn(0)
                TouchSymbolCnt = 30
                if (TaskType == 'Go' and TouchedPanelID != -1) or (TaskType == 'NoGo' and GetTimerSec(0) >= PresentDur):  # If mouse responses correctly
                    DoneCorrectResponse = 1 # If the mouse have done correct response in this trial, the value is 1
                    #WaterPosInside()  # Move water nozzle to the inside position
                    HoleWaterCueTurnOn(0)   # Turn on water cue light in the hole (panel) No.0
                    ValveTtlTurnOn()    # Allow mice to lick at the hole (panel)
                    NowDrinking = 0
                    TotalCorrectNum += 1  # Increase the number of correct response
                    if TaskType == 'Go':    # If the task type is "GO"
                        Writer_TouchEventTxt.write(
                            str(TrialNum) + '\tPanelTouched(Correct)\t' + str(TimeNow.year) + "/" + str(TimeNow.month) + "/" + str(TimeNow.day) + "\t" + str(TimeNow.hour) + ":" + str(TimeNow.minute) + "\t" + str(TimeNow.second) + "." + str(TimeNow.microsecond//1000) + "\n")  # Write the response on the text file
                        Writer_TouchEventCsv.write(
                            str(TrialNum) + ',1,' + str(TimeNow.year) + "," + str(TimeNow.month) + "," + str(TimeNow.day) + "," + str(TimeNow.hour) + "," + str(TimeNow.minute) + "," + str(TimeNow.second) + "." + str(TimeNow.microsecond//1000))  # Write the response on the csv file
                    if TaskType == 'NoGo':    # If the task type is "NOGO"
                        Writer_TouchEventTxt.write(
                            str(TrialNum) + '\tPanelIgnored(Correct)\t' + str(TimeNow.year) + "/" + str(TimeNow.month) + "/" + str(TimeNow.day) + "\t" + str(TimeNow.hour) + ":" + str(TimeNow.minute) + "\t" + str(TimeNow.second) + "." + str(TimeNow.microsecond//1000) + "\n")  # Write the response on the text file
                        Writer_TouchEventTxt.write(
                            str(TrialNum) + ',1,' + str(TimeNow.year) + "," + str(TimeNow.month) + "," + str(TimeNow.day) + "," + str(TimeNow.hour) + "," + str(TimeNow.minute) + "," + str(TimeNow.second) + "." + str(TimeNow.microsecond//1000)+ "\n")  # Write the response on the csv file
                    HoleCueTurnOff(0)   # Turn off water cue light in the hole (panel) No.0
                    Timer_End(0)    # Stop timer No.0

                    NowDrinking = 1 # When water is available , this value is 1
                    Timer_Start(0)  # Start lick timer
                    Phase2 = 2  # Start reward phase

                if (TaskType == 'NoGo' and TouchedPanelID != -1) or (TaskType == 'Go' and GetTimerSec(0) >= PresentDur):  # If mouse responses correctly
                    NowPunishing = 1
                    if PunishLight == 'ON': # If light is used for the punishment
                        RoofLightTurnOn()  # Turn on the roof light
                    TotalIncorrectNum += 1
                    if TaskType == 'Go':    # If the task type is "GO"
                        Writer_TouchEventTxt.write(
                            str(TrialNum) + '\tPanelIgnored(Wrong)\t' + str(TimeNow.year) + "/" + str(TimeNow.month) + "/" + str(TimeNow.day) + "\t" + str(TimeNow.hour) + ":" + str(TimeNow.minute) + "\t" + str(TimeNow.second) + "." + str(TimeNow.microsecond//1000) + "\n")  # Write the response on the text file
                        Writer_TouchEventCsv.write(
                            str(TrialNum) + ',0,' + str(TimeNow.year) + "," + str(TimeNow.month) + "," + str(TimeNow.day) + "," + str(TimeNow.hour) + "," + str(TimeNow.minute) + "," + str(TimeNow.second) + "." + str(TimeNow.microsecond//1000))  # Write the response on the csv file
                    if TaskType == 'NoGo':    # If the task type is "NOGO"
                        Writer_TouchEventTxt.write(
                            str(TrialNum) + '\tPanelTouched(Wrong)\t' + str(TimeNow.year) + "/" + str(TimeNow.month) + "/" + str(TimeNow.day) + "\t" + str(TimeNow.hour) + ":" + str(TimeNow.minute) + "\t" + str(TimeNow.second) + "." + str(TimeNow.microsecond//1000))  # Write the response on the text file
                        Writer_TouchEventTxt.write(
                            str(TrialNum) + ',0,' + str(TimeNow.year) + "," + str(TimeNow.month) + "," + str(TimeNow.day) + "," + str(TimeNow.hour) + "," + str(TimeNow.minute) + "," + str(TimeNow.second) + "." + str(TimeNow.microsecond//1000)+ "\n")  # Write the response on the csv file
                    HoleCueTurnOff(0)   # Turn off water cue light in the hole (panel) No.0
                    Timer_End(0)  # End timer1
                    Timer_Start(0)  # Start punish timer
                    Phase2 = 5  # Start punishment phase
            if Phase2 == 2:  # Reward phase
                if WaterCueType == 'Blink': # If reward cue is set to blink
                    if TimeNow.microsecond // 100000 % 2 == 0: # Turn off or turn on every 100ms
                        HoleWaterCueTurnOff(0)
                    if TimeNow.microsecond // 100000 % 2 == 1: # Turn off or turn on every 100ms
                        HoleWaterCueTurnOn(0)
                #if NosePoking == 1 and NowDrinking == 0:  # If the mouse initiates nose poke

                if NowDrinking == 1:
                    if DoneCorrectResponse == 1 and GetTimerSec(0) >= LickDur:  # If lick time exceed the designated time
                        Timer_End(0)  # End lick timer No.0
                        ValveTtlTurnOff()   # Don't allow animal to lick any more
                        HoleWaterCueTurnOff(0)   # Turn off the water cue in the hole(panel)
                        NowDrinking = 0 # value 0 means the mouse is not allowed to lick
                        Timer_Start(0)  # Start ITI timer
                        Phase2 = 3  # Go to the ITI phase
            if Phase2 == 3:  # ITI
                if GetTimerSec(0) >= Iti:  # If ITI is passed
                    Timer_End(0)
                    Phase2 = 0  # Go to the initialization of the next trial
                if TotalCorrectNum >= MaxCorrectNum:    # If total correct responses (=lick number) exceed the designated number
                    Phase2 = -1  # Go to the task finish phase
            if Phase2 == 5:  # Punishment phase
                if GetTimerSec(0) >= PunishDur:  # If punishment time is passed
                    RoofLightTurnOff()
                    NowPunishing = 0
                    Timer_End(0)  # End punishment timer No.0
                    Timer_Start(0)  # Start ITI timer No.0
                    Phase2 = 3  # Go to the ITI phase
            if Phase2 == -1 or Phase2 == -2:  # Task finish phase
                DuringTask = 0
                HoleCueTurnOff(0)   # Turn off the hole(panel) cue
                InfraredTurnOff()   # Turn off the infrared for detecting nosepoke to the water bottle
                NowPunishing = 0
                if NowRecording == 1:
                    SetEndRecordingTimer(60)    # Start movie record end timer (Record will be stop 60 sec later. It better to record after the task to confirm whether the last lick is finished normally or not)
                if TotalCorrectNum > 0 or TotalIncorrectNum > 0:    # If the mouse has maken any responses
                    CorrectRate = int(TotalCorrectNum * 100.0 / (TotalCorrectNum + TotalIncorrectNum))  # Calculate correct rate
                    Writer_TouchEventTxt.write(
                        'TotalNum:' + str(TotalCorrectNum + TotalIncorrectNum) + '  Correct num:' + str(TotalCorrectNum) + '  Incorrect num:' + str(TotalIncorrectNum) + '  Correct rate' + str(    # Write final result of the task
                            CorrectRate) + '%' + "\n")  # Write the brief summary of the result
                Writer_TouchEventTxt.write('TaskStartTime: ' + str(GetTaskStartedMonth()) + '/' + str(GetTaskStartedDay()) + ' ' + str(GetTaskStartedHour()) + ':' + str(GetTaskStartedMinute()) + ':' + str(
                    GetTaskStartedSecond()) + "\n")
                Writer_TouchEventTxt.write('TaskEndTime: ' + str(TimeNow.month) + '/' + str(TimeNow.day) + ' ' + str(TimeNow.hour) + ':' + str(TimeNow.minute) + ':' + str(TimeNow.second + (TimeNow.microsecond // 1000) / 1000) + "\n")
                Writer_TouchEventTxt.write('MaxCorrectNum: ' + str(MaxCorrectNum) + "\n")   # Write the parameters of the task in the result text
                Writer_TouchEventTxt.write('TimeLimit: ' + str(TimeLimit) + "\n")
                Writer_TouchEventTxt.write('PresentDur: ' + str(PresentDur) + "\n")
                Writer_TouchEventTxt.write('PunishDur: ' + str(PunishDur) + "\n")
                Writer_TouchEventTxt.write('Iti: ' + str(Iti) + "\n")
                Writer_TouchEventTxt.write('LickDur: ' + str(LickDur) + "\n")
                Writer_TouchEventTxt.write('NextTaskTh: ' + str(NextTaskTh) + "\n")
                Writer_TouchEventTxt.write('NextTask: ' + str(NextTask) + "\n")
                Writer_TouchEventTxt.write('TaskType: ' + str(TaskType) + "\n")
                Writer_TouchEventTxt.write('PunishLight: ' + str(PunishLight) + "\n")
                Writer_TouchEventTxt.write('PanelType: ' + str(PanelType) + "\n")
                Writer_TouchEventTxt.write('WaterCueType: ' + str(WaterCueType) + "\n")
                Writer_TouchEventTxt.write('RecordFPS: ' + str(RecordFPS) + "\n")
                Writer_TouchEventTxt.close()
                Writer_TouchEventCsv.close()
                EndLickRecording()  # End recording of lick events
                if CorrectRate >= NextTaskTh:   # If the correct rate exceed the threshold, change the task from next (This is used only in the housing analysis)
                    Task = NextTask
                #SendMail() # Send email to inform finishing of the task
                SendMail(DeviceNameVar.get() + ' finished task ' + str(Task) + '. Correct:' + str(TotalCorrectNum) + ' Incorrect:' + str(TotalIncorrectNum) + ' CorrectRate:' + str(CorrectRate)+ '% Dur:' + str(round(GetTimerSec(5) / 60, 1)) + ' min','The task is finished.')
                TtlDelayStop()  # Stop TTL sending

                Phase2 = 0
                if IsHousingAnalysis == 1 and Phase2 == -1:  # If it is housing analysis
                    if CorrectRate >= NextTaskTh:  # If the score exceed the criteria to switch the next task
                        SwitchTask(NextTask)  # Onset task switch trigger
                        print("Task is switched to task#" + str(NextTask) + "  " + str(GetTaskStartedMonth()) + '/' + str(GetTaskStartedDay()) + ' ' + str(GetTaskStartedHour()) + ':' + str(GetTaskStartedMinute()) + ':' + str(GetTaskStartedSecond()))

                if IsHousingAnalysis == 0: # If this is non-housing analysis
                    RoofLightTurnOn()   # Turn on the loof light
                    Phase = 0  # Go back to the task parameter setting
                    Init = 0    # Activate initialization trigger
    return
def Task31():
    global Phase, Task
    Phase = 0
    Task = 31
    return

def Task32():   # Habitual behavior task
    global Phase, Phase2, Task, SaveTrg, LoadTrg, NosePoking, DuringTask, NowRecording, RecordFPS

    Task = 32
    Phase0_Init=0
    Phase1_Init = 0
    Phase2_Init = 0
    while EndFlag == 0:
        OperantHouseUpdate()    # House keeping function

        if Phase == -1:  # Back to the task select phase
            Phase = 0
            Task = 0
            break
        if Phase == 0:  # Parameter inputs
            if Phase0_Init == 0:
                LoadTrg = 1
                # Make GUI for the setting of the parameters for this task
                RemoveMainRightWidget() # Remove task buttons

                PutStartBackButton()    # Put start/back buttons
                mSpace = ttk.Label(MainWindowRightFrame, text=' ').grid(row=0, column=1)  # Used just as spacer

                mMaxCorrectNum = ttk.Label(MainWindowRightFrame, text='MaxCorrectNum').grid(row=0, column=2, sticky=W)    # Put label
                MaxCorrectNumVar = IntVar(MainWindowRoot)  # Declare variable receiving value from the entry field
                iMaxCorrectNum = ttk.Entry(MainWindowRightFrame, textvariable=MaxCorrectNumVar).grid(row=1, column=2) # Place entry field

                mTimeLimit = ttk.Label(MainWindowRightFrame, text='TimeLimit(min)').grid(row=0, column=3, sticky=W)  # Put label
                TimeLimitVar = IntVar(MainWindowRoot)  # Declare variable receiving value from the entry field
                iTimeLimit = ttk.Entry(MainWindowRightFrame, textvariable=TimeLimitVar).grid(row=1, column=3)  # Place entry field

                mRandomInterval = ttk.Label(MainWindowRightFrame, text='Random interval(sec)').grid(row=0, column=4, sticky=W)  # Put label
                RandomIntervalVar = IntVar(MainWindowRoot)  # Declare variable receiving value from the entry field
                iRandomInterval = ttk.Entry(MainWindowRightFrame, textvariable=RandomIntervalVar).grid(row=1, column=4)  # Place entry field

                mRandomRate = ttk.Label(MainWindowRightFrame, text='Random rate(%)').grid(row=0, column=5, sticky=W)  # Put label
                RandomRateVar = IntVar(MainWindowRoot)  # Declare variable receiving value from the entry field
                iRandomRate = ttk.Entry(MainWindowRightFrame, textvariable=RandomRateVar).grid(row=1, column=5)  # Place entry field

                mPresentDur = ttk.Label(MainWindowRightFrame, text='PresentDur(s)').grid(row=0, column=6, sticky=W)
                PresentDurVar = IntVar(MainWindowRoot)
                iPresentDur = ttk.Entry(MainWindowRightFrame, textvariable=PresentDurVar).grid(row=1, column=6)

                mPunishDur = ttk.Label(MainWindowRightFrame, text='PunishDur(s)').grid(row=0, column=7, sticky=W)
                PunishDurVar = IntVar(MainWindowRoot)
                iPunishDur = ttk.Entry(MainWindowRightFrame, textvariable=PunishDurVar).grid(row=1, column=7)

                mIti = ttk.Label(MainWindowRightFrame, text='ITI(s)').grid(row=0, column=8, sticky=W)
                ItiVar = IntVar(MainWindowRoot)
                iIti = ttk.Entry(MainWindowRightFrame, textvariable=ItiVar).grid(row=1, column=8)

                mLickDur = ttk.Label(MainWindowRightFrame, text='LickDur(s)').grid(row=2, column=2, sticky=W)
                LickDurVar = IntVar(MainWindowRoot)
                iLickDur = ttk.Entry(MainWindowRightFrame, textvariable=LickDurVar).grid(row=3, column=2)

                mNextTask = ttk.Label(MainWindowRightFrame, text='NextTask#').grid(row=2, column=3, sticky=W)
                NextTaskVar = IntVar(MainWindowRoot)
                iNextTask = ttk.Entry(MainWindowRightFrame, textvariable=NextTaskVar).grid(row=3, column=3)

                mNextTaskTh = ttk.Label(MainWindowRightFrame, text='NextTaskTh(Correct%)').grid(row=2, column=4, sticky=W)
                NextTaskThVar = IntVar(MainWindowRoot)
                iNextTaskTh = ttk.Entry(MainWindowRightFrame, textvariable=NextTaskThVar).grid(row=3, column=4)

                mTaskType = ttk.Label(MainWindowRightFrame, text='TaskType').grid(row=2, column=5, sticky=W)    # Put label
                TaskTypeVar = StringVar(MainWindowRightFrame)  # Declare variable receiving value from the entry field
                tTaskType = OptionMenu(MainWindowRightFrame, TaskTypeVar, "Train", "Devaluation", "Omission").grid(row=3, column=5) # Place drop-down list

                mPunishLight = ttk.Label(MainWindowRightFrame, text='PunishLight').grid(row=2, column=6, sticky=W)
                PunishLightVar = StringVar(MainWindowRightFrame)
                tPunishLight = OptionMenu(MainWindowRightFrame, PunishLightVar, "ON", "OFF").grid(row=3, column=6)

                mPanelType = ttk.Label(MainWindowRightFrame, text='PanelType').grid(row=2, column=7, sticky=W)
                PanelTypeVar = StringVar(MainWindowRightFrame)
                tPanelType = OptionMenu(MainWindowRightFrame, PanelTypeVar, "Normal", "Blink", "Textured").grid(row=3, column=7)

                mWaterCueType = ttk.Label(MainWindowRightFrame, text='WaterCueType').grid(row=2, column=8, sticky=W)
                WaterCueTypeVar = StringVar(MainWindowRightFrame)
                tWaterCueType = OptionMenu(MainWindowRightFrame, WaterCueTypeVar, "Normal", "Blink").grid(row=3, column=8)

                #InitPanel()
                Phase0_Init = 1

        if LoadTrg == 1:  # If load trigger is on

            Str = "ParametersForTask" + str(Task)
            if os.path.exists(Str+'/MaxCorrectNum.dat') == True:  # If save file exists
                with open(Str+'/MaxCorrectNum.dat', 'rb') as PickleInst[Task]:
                    MaxCorrectNumVar.set(pickle.load(PickleInst[Task]))  # Load
            else:
                MaxCorrectNumVar.set(80)     # Default value
            if os.path.exists(Str+'/TimeLimit.dat') == True:  # If save file exists
                with open(Str+'/TimeLimit.dat', 'rb') as PickleInst[Task]:
                    TimeLimitVar.set(pickle.load(PickleInst[Task]))  # Load
            else:
                TimeLimitVar.set(90)     # Default value
            if os.path.exists(Str + '/RandomInterval.dat') == True:  # If save file exists
                with open(Str + '/RandomInterval.dat', 'rb') as PickleInst[Task]:
                    RandomIntervalVar.set(pickle.load(PickleInst[Task]))  # Load
            else:
                RandomIntervalVar.set(30)  # Default value
            if os.path.exists(Str + '/RandomRate.dat') == True:  # If save file exists
                with open(Str + '/RandomRate.dat', 'rb') as PickleInst[Task]:
                    RandomRateVar.set(pickle.load(PickleInst[Task]))  # Load
            else:
                RandomRateVar.set(10)  # Default value
            if os.path.exists(Str+'/PresentDur.dat') == True:  # If save file exists
                with open(Str+'/PresentDur.dat', 'rb') as PickleInst[Task]:
                    PresentDurVar.set(pickle.load(PickleInst[Task]))  # Load
            else:
                PresentDurVar.set(1)     # Default value

            if os.path.exists(Str+'/PunishDur.dat') == True:  # If save file exists
                with open(Str+'/PunishDur.dat', 'rb') as PickleInst[Task]:
                    PunishDurVar.set(pickle.load(PickleInst[Task]))  # Load
            else:
                PunishDurVar.set(1)     # Default value

            if os.path.exists(Str+'/Iti.dat') == True:  # If save file exists
                with open(Str+'/Iti.dat', 'rb') as PickleInst[Task]:
                    ItiVar.set(pickle.load(PickleInst[Task]))  # Load
            else:
                ItiVar.set(1)     # Default value
            if os.path.exists(Str+'/LickDur.dat') == True:  # If save file exists
                with open(Str+'/LickDur.dat', 'rb') as PickleInst[Task]:
                    LickDurVar.set(pickle.load(PickleInst[Task]))  # Load
            else:
                LickDurVar.set(1)     # Default value
            if os.path.exists(Str+'/NextTaskTh.dat') == True:  # If save file exists
                with open(Str+'/NextTaskTh.dat', 'rb') as PickleInst[Task]:
                    NextTaskThVar.set(pickle.load(PickleInst[Task]))  # Load
            else:
                NextTaskThVar.set(1)     # Default value
            if os.path.exists(Str+'/NextTask.dat') == True:  # If save file exists
                with open(Str+'/NextTask.dat', 'rb') as PickleInst[Task]:
                    NextTaskVar.set(pickle.load(PickleInst[Task]))  # Load
            else:
                NextTaskVar.set(1)     # Default value
            if os.path.exists(Str+'/TaskType.dat') == True:  # If save file exists
                with open(Str+'/TaskType.dat', 'rb') as PickleInst[Task]:
                    TaskTypeVar.set(pickle.load(PickleInst[Task]))  # Load
            else:
                TaskTypeVar.set('Train')     # Default value
            if os.path.exists(Str+'/PunishLight.dat') == True:  # If save file exists
                with open(Str+'/PunishLight.dat', 'rb') as PickleInst[Task]:
                    PunishLightVar.set(pickle.load(PickleInst[Task]))  # Load
            else:
                PunishLightVar.set('ON')     # Default value

            if os.path.exists(Str+'/PanelType.dat') == True:  # If save file exists
                with open(Str+'/PanelType.dat', 'rb') as PickleInst[Task]:
                    PanelTypeVar.set(pickle.load(PickleInst[Task]))  # Load
            else:
                PanelTypeVar.set('Normal')     # Default value

            if os.path.exists(Str+'/WaterCueType.dat') == True:  # If save file exists
                with open(Str+'/WaterCueType.dat', 'rb') as PickleInst[Task]:
                    WaterCueTypeVar.set(pickle.load(PickleInst[Task]))  # Load
            else:
                WaterCueTypeVar.set('Normal')     # Default value
            LoadTrg = 0

        if SaveTrg == 1:    # If save trigger is on
            # Parameters of each task are saved into different folder
            Str="ParametersForTask"+str(Task)   # Path to the folder for saving of parameters
            if os.path.exists(Str) == False:    # If folder for saving parameters is not exist
                os.mkdir(Str)   # Make folder for saving
            with open(Str+'/MaxCorrectNum.dat', 'wb') as PickleInst[Task]:
                pickle.dump(MaxCorrectNumVar.get(),PickleInst[Task])     # Save
            with open(Str+'/TimeLimit.dat', 'wb') as PickleInst[Task]:
                pickle.dump(TimeLimitVar.get(),PickleInst[Task])     # Save
            with open(Str+'/RandomInterval.dat', 'wb') as PickleInst[Task]:
                pickle.dump(RandomIntervalVar.get(),PickleInst[Task])     # Save
            with open(Str+'/RandomRate.dat', 'wb') as PickleInst[Task]:
                pickle.dump(RandomRateVar.get(),PickleInst[Task])     # Save
            with open(Str+'/PresentDur.dat', 'wb') as PickleInst[Task]:
                pickle.dump(PresentDurVar.get(), PickleInst[Task])     # Save
            with open(Str+'/PunishDur.dat', 'wb') as PickleInst[Task]:
                pickle.dump(PunishDurVar.get(), PickleInst[Task])     # Save
            with open(Str+'/Iti.dat', 'wb') as PickleInst[Task]:
                pickle.dump(ItiVar.get(), PickleInst[Task])     # Save
            with open(Str+'/LickDur.dat', 'wb') as PickleInst[Task]:
                pickle.dump(LickDurVar.get(), PickleInst[Task])     # Save
            with open(Str+'/NextTaskTh.dat', 'wb') as PickleInst[Task]:
                pickle.dump(NextTaskThVar.get(), PickleInst[Task])     # Save
            with open(Str + '/NextTask.dat', 'wb') as PickleInst[Task]:
                pickle.dump(NextTaskVar.get(), PickleInst[Task])  # Save
            with open(Str+'/TaskType.dat', 'wb') as PickleInst[Task]:
                pickle.dump(TaskTypeVar.get(), PickleInst[Task])     # Save
            with open(Str+'/PunishLight.dat', 'wb') as PickleInst[Task]:
                pickle.dump(PunishLightVar.get(), PickleInst[Task])     # Save
            with open(Str+'/PanelType.dat', 'wb') as PickleInst[Task]:
                pickle.dump(PanelTypeVar.get(), PickleInst[Task])     # Save
            with open(Str+'/WaterCueType.dat', 'wb') as PickleInst[Task]:
                pickle.dump(WaterCueTypeVar.get(), PickleInst[Task])     # Save
            SaveTrg = 0


        if Phase == 1:  # Wait for starting of task
            if Phase1_Init == 0:
                PutPreTaskButton()
                mStatusVar = StringVar(MainWindowRoot)
                mStatus = ttk.Label(MainWindowRightFrame, textvariable=mStatusVar)
                mStatus.place(x=10, y=0)
                mOngoingResultVar = StringVar(MainWindowRoot)
                Phase1_Init = 1
            mStatusVar.set('Habitual behavior task (' + str(Task) + ')    Waiting...')
        if Phase == 2:  # During task
            if Phase2_Init == 0: # Initialization of the task
                PutEndTaskNowButton()
                mStatusVar.set('Habitual behavior task (' + str(Task) + ')    Start time ' + str(TaskStartedMonth) + '/' + str(TaskStartedDay) + ' ' + str(TaskStartedHour) + ':' + str(TaskStartedMinute) + '    Running')
                mOngoingResult = ttk.Label(MainWindowRightFrame, textvariable=mOngoingResultVar)
                mOngoingResult.place(x=10, y=18)

                # Convert StringVars of parameters into integer or normal string to use in the following
                MaxCorrectNum=int(MaxCorrectNumVar.get())
                TimeLimit = int(TimeLimitVar.get())
                RandomInterval=int(RandomIntervalVar.get())
                RandomRate = int(RandomRateVar.get())
                PresentDur = int(PresentDurVar.get())
                PunishDur = int(PunishDurVar.get())
                Iti = int(ItiVar.get())
                LickDur = int(LickDurVar.get())
                NextTaskTh = int(NextTaskThVar.get())
                NextTask = int(NextTaskVar.get())
                TaskType = TaskTypeVar.get()
                PunishLight = PunishLightVar.get()
                PanelType = PanelTypeVar.get()
                WaterCueType = WaterCueTypeVar.get()


                # Declar local variables for this task
                TrialNum=0
                CorrectNum=0
                MissNum=0
                TouchNum=0
                CorrectRate=0
                Writer_TouchEventTxt = open(Path + "/" + str(TimeNow.year) + "_" + str(TimeNow.month) + "_" + str(TimeNow.day) + " " + str(TimeNow.hour) + "h" + str(TimeNow.minute) + "m Task" + str(Task) +  " Touch.txt", 'w')  # Initialize the text exporter
                Writer_TouchEventCsv = open(Path + "/" + str(TimeNow.year) + "_" + str(TimeNow.month) + "_" + str(TimeNow.day) + " " + str(TimeNow.hour) + "h" + str(TimeNow.minute) + "m Task" + str(Task) +  " Touch.csv", 'w')  # Initialize the text exporter
                StartLickRecording()

                DuringTask = 1
                DoneCorrectResponse = 1
                RoofLightTurnOff()
                InfraredTurnOn()
                WaterCueTurnOn()
                WaterPosInside()
                NowDrinking = 0
                NowPunishing = 0
                AutoWaterSupplyNum = 0
                AWS_Latency=20
                StartRecording()    # Start camera capturing and sending of TTL
                CntResetBook=1

                if PanelType == 'Normal':
                    CreateNormalPanel(0)
                if PanelType == 'Blink':
                    CreateBlinkPanel(0)
                if PanelType == 'Textured':
                    CreateTexturedPanel(0)
                if WaterCueType == 'Blink':
                    MakeWaterCueBlink()  # Make water cue blink

                Writer_TouchEventTxt.write('TrialNum\tResult\t\t\tyyyy/mm/dd\th:m\ts\n')  # Write item name
                TrialNum=0
                TtlStart()
                Timer_Start(5)  # Task time limit timer start
                Phase2 = 2
                if TaskType == "Devaluation":
                    Phase2 = 0
                Phase2_Init = 1
                print("Task #" + str(Task) + " is started at " + str(GetTaskStartedMonth()) + '/' + str(GetTaskStartedDay()) + ' ' + str(GetTaskStartedHour()) + ':' + str(
                    GetTaskStartedMinute()) + ':' + str(GetTaskStartedSecond()))

            if Phase2 == 0:   # Initiation of new trial
                DoneCorrectResponse=0
                ShowPanel(0)
                TrialNum += 1
                Timer_Start(0)  # Start the latency timer
                #print(GetTimerStat(1))
                if CntResetBook==1:  # If the timer is stopped
                    #print("timer1start")
                    Timer_Start(1)  # Start the panel present duration timer
                    #print(GetTimerStat(1))
                if TaskType == 'Train' and CntResetBook==1:
                    CurrRandomInterval=RandomInterval*random.random()
                    IsRewardedTrial =0
                    if RandomRate >= random.random()*100:
                        IsRewardedTrial=1
                    if IsRewardedTrial == 1:
                        print("Delay for correct touch: "+str(round(CurrRandomInterval,1))+" sec,  Rewarded trial")
                    if IsRewardedTrial == 0:
                        print("Delay for correct touch: " + str(round(CurrRandomInterval, 1)) + " sec,  Non-rewarded trial")
                if CntResetBook==1:
                    CntResetBook=0
                Phase2 += 1
            if Phase2 == 1:   # Panel presentation
                Trg=0
                TouchedPanelID = DetectPanelTouch()  # Examine which panel is touched (return panel ID. If none of the panels touched, return -1)
                if TouchedPanelID != -1:
                    #ShowTouchSymbol(30)
                    if TaskType == 'Train':
                        if GetTimerSec(1) >= CurrRandomInterval and IsRewardedTrial==1:
                            print("Correct (Latency: "+str(GetTimerSec(1))+" sec)")
                            Trg=1
                        if GetTimerSec(1) < CurrRandomInterval or IsRewardedTrial != 1:
                            print("Miss (Latency: "+str(GetTimerSec(1))+" sec)")
                            Trg=-1
                    if TaskType == 'Devaluation':
                        print("Miss")
                        Trg=-1
                    if TaskType == 'Omission':
                        print("Miss ("+str(GetTimerSec(1))+" sec past)")
                        Trg=-1
                if TaskType == 'Omission':  # If mouse holds without touching
                    if GetTimerSec(1) >= PresentDur:
                        print("CorrectOmission ("+str(GetTimerSec(1))+" sec past)")
                        Trg = 1
                if Trg==1:  # If mouse took correct response
                    DoneCorrectResponse = 1
                    WaterPosInside()  # Move water nozzle to the inside position
                    WaterCueTurnOn()
                    NowDrinking = 0
                    CorrectNum += 1  # Increase the number of correct response
                    TouchNum += 1
                    if TaskType == 'Train':
                        mOngoingResultVar.set('CorrectNum:' + str(CorrectNum) + '  Miss:' + str(MissNum) + '  Total:' + str(TouchNum) + '  Correct/Touch:' + str(round(CorrectNum / TouchNum * 100, 1)))
                        Writer_TouchEventTxt.write(str(TrialNum) + '\tCorrectTouch\t' + str(TimeNow.year) + "/" + str(TimeNow.month) + "/" + str(TimeNow.day) + "\t" + str(TimeNow.hour) + ":" + str(TimeNow.minute) + "\t" + str(TimeNow.second) + "." + str(TimeNow.microsecond // 1000) + "\n")  # Write the response on the text file
                        Writer_TouchEventCsv.write(str(TrialNum) + ',1,' + str(TimeNow.year) + "," + str(TimeNow.month) + "," + str(TimeNow.day) + "," + str(TimeNow.hour) + "," + str(TimeNow.minute) + "," + str(TimeNow.second) + "." + str(TimeNow.microsecond // 1000))  # Write the response on the csv file
                    if TaskType == 'Omission':
                        mOngoingResultVar.set('CorrectOmission:' + str(CorrectNum) + '  Miss:' + str(MissNum) + '  Total:' + str(TouchNum) + '  Correct/Touch:' + str(round(CorrectNum / TouchNum * 100, 1)))
                        Writer_TouchEventTxt.write(str(TrialNum) + '\tCorrectOmission\t' + str(TimeNow.year) + "/" + str(TimeNow.month) + "/" + str(TimeNow.day) + "\t" + str(TimeNow.hour) + ":" + str(TimeNow.minute) + "\t" + str(TimeNow.second) + "." + str(TimeNow.microsecond // 1000) + "\n")  # Write the response on the text file
                        Writer_TouchEventCsv.write(str(TrialNum) + ',1,' + str(TimeNow.year) + "," + str(TimeNow.month) + "," + str(TimeNow.day) + "," + str(TimeNow.hour) + "," + str(TimeNow.minute) + "," + str(TimeNow.second) + "." + str(TimeNow.microsecond // 1000)+ "\n")  # Write the response on the csv file
                    HidePanel(0)
                    Timer_End(0)
                    Timer_End(1)
                    CntResetBook = 1
                    WaterCueTurnOn()
                    Phase2 = 2  # Start reward phase
                if Trg==-1: # If mouse took wrong response
                    NowPunishing = 1
                    WaterPosOutside()
                    MissNum += 1
                    TouchNum += 1
                    if TaskType == 'Train':
                        mOngoingResultVar.set('Correct:' + str(CorrectNum) + '  Miss:'+str(MissNum) + '  Total:' + str(TouchNum) +'  Correct/Touch:' + str(round(CorrectNum/TouchNum*100,1)))
                        Writer_TouchEventTxt.write(str(TrialNum) + '\tMissTouch\t' + str(TimeNow.year) + "/" + str(TimeNow.month) + "/" + str(TimeNow.day) + "\t" + str(TimeNow.hour) + ":" + str(TimeNow.minute) + "\t" + str(TimeNow.second) + "." + str(TimeNow.microsecond//1000)+"\n")  # Write the response on the text file
                        Writer_TouchEventCsv.write(str(TrialNum) + ',0,' + str(TimeNow.year) + "," + str(TimeNow.month) + "," + str(TimeNow.day) + "," + str(TimeNow.hour) + "," + str(TimeNow.minute) + "," + str(TimeNow.second) + "." + str(TimeNow.microsecond//1000))  # Write the response on the csv file
                    if TaskType == 'Devaluation':
                        mOngoingResultVar.set('Miss:'+str(MissNum) )
                        Writer_TouchEventTxt.write(str(TrialNum) + '\tMissTouch\t' + str(TimeNow.year) + "/" + str(TimeNow.month) + "/" + str(TimeNow.day) + "\t" + str(TimeNow.hour) + ":" + str(TimeNow.minute) + "\t" + str(TimeNow.second) + "." + str(TimeNow.microsecond//1000)+"\n")  # Write the response on the text file
                        Writer_TouchEventCsv.write(str(TrialNum) + ',0,' + str(TimeNow.year) + "," + str(TimeNow.month) + "," + str(TimeNow.day) + "," + str(TimeNow.hour) + "," + str(TimeNow.minute) + "," + str(TimeNow.second) + "." + str(TimeNow.microsecond//1000)+ "\n")  # Write the response on the csv file
                    if TaskType == 'Omission':
                        Timer_End(1)
                        Timer_Start(1)
                        CntResetBook = 1
                        mOngoingResultVar.set('CorrectOmission:' + str(CorrectNum) + '  Miss:'+str(MissNum) + '  Total:' + str(TouchNum) +'  Correct/Touch:' + str(round(CorrectNum/TouchNum*100,1)))
                        Writer_TouchEventTxt.write(str(TrialNum) + '\tMissTouch\t' + str(TimeNow.year) + "/" + str(TimeNow.month) + "/" + str(TimeNow.day) + "\t" + str(TimeNow.hour) + ":" + str(TimeNow.minute) + "\t" + str(TimeNow.second) + "." + str(TimeNow.microsecond//1000)+"\n")  # Write the response on the text file
                        Writer_TouchEventCsv.write(str(TrialNum) + ',0,' + str(TimeNow.year) + "," + str(TimeNow.month) + "," + str(TimeNow.day) + "," + str(TimeNow.hour) + "," + str(TimeNow.minute) + "," + str(TimeNow.second) + "." + str(TimeNow.microsecond//1000)+ "\n")  # Write the response on the csv file

                    HidePanel(0)
                    Timer_End(0)    # End timer1
                    Timer_Start(0)  # Start punish timer
                    Phase2 = 5 # Start punishment phase

                if GetTimerSec(5) >= TimeLimit * 60:   # If time limit is exceeded
                    Timer_End(5)
                    Phase2 = 6
            if Phase2 == 2:  # Reward phase
                if NosePoking == 1 and NowDrinking == 0:    # If the mouse initiates nose poke
                    NowDrinking = 1
                    Timer_Start(0)  # Start lick timer
                if NowDrinking == 1:
                    if DoneCorrectResponse == 1 and GetTimerSec(0) >= LickDur:   # If lick time exceed the designated time
                        Timer_End(0) # End lick timer
                        WaterPosMiddle()    # Move water nozzle to the intermediate position
                        WaterCueTurnOff()
                        NowDrinking = 0
                        Timer_Start(0)  # Start ITI timer
                        Phase2 = 3
            if Phase2 == 3:   # ITI
                if GetTimerSec(0) >= Iti:  # If ITI is passed
                    Timer_End(0)
                    Phase2 = 0  # Go to the next trial
                if CorrectNum >= MaxCorrectNum:
                    Timer_End(5)
                    Phase2=6 # Go to the task finish phase
            if Phase2 == 5:   # Punishment phase
                if GetTimerSec(0) >= PunishDur:    # If punishment time is passed
                    NowPunishing = 0
                    WaterPosMiddle()    # Move water nozzle to the intermediate position
                    Timer_End(0)  # End punishment timer1
                    Timer_Start(0)  # Start ITI timer
                    Phase2 = 3
            if Phase2 == 6:
                HidePanel(0)
                if CorrectNum < MaxCorrectNum:    # If mouse didn't achieved the max correct response
                    Timer_Start(0)  # Timer for interval between task and arbitary water supply is started
                    Phase2 = 7
                if (CorrectNum == MaxCorrectNum) or TaskType == "Devaluation":    # If mouse achieved the max correct response
                    Phase2 = -1
            if Phase2 == 7:  # Wait until arbitary water suuply is started
                if GetTimerSec(0) >= AWS_Latency:  # If the interval is past 60 20
                    Timer_End(0)
                    ArbitaryWaterSupplyDur = (MaxCorrectNum - CorrectNum) * LickDur * 1000  # Caliculate duration of complement water supply
                    StartArbitaryWaterSupply(ArbitaryWaterSupplyDur)  # Start complement water supply
                    #print("AWSstart")
                    Phase2 = 8
            if Phase2 == 8:
                if GetArbitaryWaterSupplyStat() == 1:  # If complement water supply is finished
                    Phase2 = -1

            if Phase2 == -1 or Phase2 == -2:  # Task finish phase   #
                DuringTask = 0
                WaterPosMiddle()
                #if Panel!=null:
                ClearPanel()
                InfraredTurnOff()
                NowPunishing = 0
                if NowRecording == 1:
                    SetEndRecordingTimer(60)
                if CorrectNum > 0 or MissNum > 0:
                    if TaskType !="Devaluation":
                        CorrectRate = int(CorrectNum * 100.0 / TouchNum)
                    Writer_TouchEventTxt.write('TotalNum:'+str(TouchNum)+'  Correct num:'+str(CorrectNum)+'  Incorrect num:'+str(MissNum)+'  Correct rate'+str(CorrectRate)+'%'+"\n")	#結果テキストの一番最後に成績のまとめを記入
                Writer_TouchEventTxt.write('TaskStartTime: ' + str(GetTaskStartedMonth()) + '/' + str(GetTaskStartedDay()) + ' ' + str(GetTaskStartedHour()) + ':' + str(GetTaskStartedMinute()) + ':' + str(GetTaskStartedSecond()) + "\n")
                Writer_TouchEventTxt.write('TaskEndTime: ' + str(TimeNow.month) + '/' + str(TimeNow.day) + ' ' + str(TimeNow.hour) + ':' + str(TimeNow.minute) + ':' + str(TimeNow.second + (TimeNow.microsecond // 1000) / 1000) + "\n")
                Writer_TouchEventTxt.write('MaxCorrectNum: '+str(MaxCorrectNum)+"\n")
                Writer_TouchEventTxt.write('TimeLimit: ' + str(TimeLimit) + "\n")
                Writer_TouchEventTxt.write('RandomInterval: ' + str(RandomInterval) + "\n")
                Writer_TouchEventTxt.write('RandomRate: ' + str(RandomRate) + "\n")
                Writer_TouchEventTxt.write('PresentDur: ' + str(PresentDur)+"\n")
                Writer_TouchEventTxt.write('PunishDur: ' + str(PunishDur)+"\n")
                Writer_TouchEventTxt.write('Iti: ' + str(Iti)+"\n")
                Writer_TouchEventTxt.write('LickDur: ' + str(LickDur)+"\n")
                Writer_TouchEventTxt.write('NextTaskTh: ' + str(NextTaskTh)+"\n")
                Writer_TouchEventTxt.write('NextTask: ' + str(NextTask)+"\n")
                Writer_TouchEventTxt.write('TaskType: ' + str(TaskType)+"\n")
                Writer_TouchEventTxt.write('PunishLight: ' + str(PunishLight)+"\n")
                Writer_TouchEventTxt.write('PanelType: ' + str(PanelType)+"\n")
                Writer_TouchEventTxt.write('WaterCueType: ' + str(WaterCueType)+"\n")
                Writer_TouchEventTxt.write('RecordFPS: ' + str(RecordFPS) + "\n")
                Writer_TouchEventTxt.write('AWS_Latency: ' + str(AWS_Latency) + "\n")
                Writer_TouchEventTxt.close()
                Writer_TouchEventCsv.close()
                EndLickRecording()
                if CorrectRate >= NextTaskTh:
                    Task = NextTask
                if TaskType=='Train' or  TaskType=='Devaluation':
                    SendMail(DeviceNameVar.get() + ' finished task ' + str(Task) + '. Correct:' + str(CorrectNum) + ' Miss:' + str(MissNum) + ' Correct/Touch:' + str(CorrectRate) + ' Dur:' + str(round(GetTimerSec(5) / 60, 1)) + ' min', 'The task is finished.')
                if TaskType == 'Omission':
                    SendMail(DeviceNameVar.get() + ' finished task ' + str(Task) + '. CorrectOmission:' + str(CorrectNum) + ' Miss:' + str(MissNum) + ' CorrectOmission/Touch:' + str(CorrectRate) + ' Dur:' + str(round(GetTimerSec(5) / 60, 1)) + ' min', 'The task is finished.')
                TtlDelayStop()

                if IsHousingAnalysis == 1 and Phase2 == -1:  # If it is housing analysis
                    if CorrectRate >= NextTaskTh:  # If the score exceed the criteria to switch the next task
                        SwitchTask(NextTask)  # Onset task switch trigger
                        print("Task is switched to task#" + str(NextTask) + "  " + str(GetTaskStartedMonth()) + '/' + str(GetTaskStartedDay()) + ' ' + str(GetTaskStartedHour()) + ':' + str(GetTaskStartedMinute()) + ':' + str(GetTaskStartedSecond()))

                if IsHousingAnalysis == 0:
                    RoofLightTurnOn()
                Phase2 = 0
                Phase = 1  # Go back to the task-waiting phase
                Phase2_Init = 0
    return

def Task33():   # Probabilistic spatial discrimination task
    global Phase, Phase2, Init, Task, SaveTrg, LoadTrg, NosePoking, DuringTask, NowRecording, RecordFPS
    Task = 33
    Phase0_Init=0
    Phase1_Init=0
    Phase2_Init=0
    while EndFlag==0:
        OperantHouseUpdate()
        if Phase == -1:  # Back to the task select phase
            Phase = 0
            Task = 0
            break
        if Phase == 0:  # Parameter inputs
            if Phase0_Init == 0:
                LoadTrg = 1
                # Make GUI for the setting of the parameters for this task
                RemoveMainRightWidget() # Remove task buttons

                PutStartBackButton()    # Put start/back buttons
                mSpace = ttk.Label(MainWindowRightFrame, text=' ').grid(row=0, column=1)  # Used just as spacer

                mMaxCorrectNum = ttk.Label(MainWindowRightFrame, text='MaxCorrectNum').grid(row=0, column=2, sticky=W)    # Put label
                MaxCorrectNumVar = IntVar(MainWindowRoot)  # Declare variable receiving value from the entry field
                iMaxCorrectNum = ttk.Entry(MainWindowRightFrame, textvariable=MaxCorrectNumVar).grid(row=1, column=2) # Place entry field

                mMaxTrialNum = ttk.Label(MainWindowRightFrame, text='MaxTrialNum').grid(row=0, column=3, sticky=W)
                MaxTrialNumVar = IntVar(MainWindowRoot)
                iMaxTrialNum = ttk.Entry(MainWindowRightFrame, textvariable=MaxTrialNumVar).grid(row=1, column=3)

                mTimeLimit = ttk.Label(MainWindowRightFrame, text='TimeLimit(min)').grid(row=0, column=4, sticky=W)
                TimeLimitVar = IntVar(MainWindowRoot)
                iTimeLimit = ttk.Entry(MainWindowRightFrame, textvariable=TimeLimitVar).grid(row=1, column=4)

                mPunishDur = ttk.Label(MainWindowRightFrame, text='PunishDur(s)').grid(row=0, column=5, sticky=W)
                PunishDurVar = IntVar(MainWindowRoot)
                iPunishDur = ttk.Entry(MainWindowRightFrame, textvariable=PunishDurVar).grid(row=1, column=5)

                mIti = ttk.Label(MainWindowRightFrame, text='ITI(s)').grid(row=0, column=6, sticky=W)
                ItiVar = IntVar(MainWindowRoot)
                iIti = ttk.Entry(MainWindowRightFrame, textvariable=ItiVar).grid(row=1, column=6)

                mLickDur = ttk.Label(MainWindowRightFrame, text='LickDur(s)').grid(row=0, column=7, sticky=W)
                LickDurVar = IntVar(MainWindowRoot)
                iLickDur = ttk.Entry(MainWindowRightFrame, textvariable=LickDurVar).grid(row=1, column=7)

                mNextTaskTh = ttk.Label(MainWindowRightFrame, text='NextTaskTh(Correct%)').grid(row=2, column=2, sticky=W)
                NextTaskThVar = IntVar(MainWindowRoot)
                iNextTaskTh = ttk.Entry(MainWindowRightFrame, textvariable=NextTaskThVar).grid(row=3, column=2)

                mNextTask = ttk.Label(MainWindowRightFrame, text='NextTask#').grid(row=2, column=3, sticky=W)
                NextTaskVar = IntVar(MainWindowRoot)
                iNextTask = ttk.Entry(MainWindowRightFrame, textvariable=NextTaskVar).grid(row=3, column=3)

                mCorrectPos = ttk.Label(MainWindowRightFrame, text='CorrectPos').grid(row=2, column=4, sticky=W)    # Put label
                CorrectPosVar = StringVar(MainWindowRightFrame)  # Declare variable receiving value from the entry field
                tCorrectPos = OptionMenu(MainWindowRightFrame, CorrectPosVar, "0", "1").grid(row=3, column=4) # Place drop-down list

                mRewardRateOfCorrectPos = ttk.Label(MainWindowRightFrame, text='Correct%ofCorrectPos').grid(row=2, column=5, sticky=W)
                RewardRateOfCorrectPosVar = IntVar(MainWindowRoot)
                iRewardRateOfCorrectPos = ttk.Entry(MainWindowRightFrame, textvariable=RewardRateOfCorrectPosVar).grid(row=3, column=5)

                mRewardRateOfWrongPos = ttk.Label(MainWindowRightFrame, text='Correct%ofWrongPos').grid(row=2, column=6, sticky=W)
                RewardRateOfWrongPosVar = IntVar(MainWindowRoot)
                iRewardRateOfWrongPos = ttk.Entry(MainWindowRightFrame, textvariable=RewardRateOfWrongPosVar).grid(row=3, column=6)

                mSeed = ttk.Label(MainWindowRightFrame, text='Seed').grid(row=2, column=7, sticky=W)
                SeedVar = IntVar(MainWindowRoot)
                iSeed = ttk.Entry(MainWindowRightFrame, textvariable=SeedVar).grid(row=3, column=7)

                mPanelType = ttk.Label(MainWindowRightFrame, text='PanelType').grid(row=4, column=2, sticky=W)
                PanelTypeVar = StringVar(MainWindowRightFrame)
                tPanelType = OptionMenu(MainWindowRightFrame, PanelTypeVar, "Normal", "Blink", "Textured").grid(row=5, column=2)

                mWaterCueType = ttk.Label(MainWindowRightFrame, text='WaterCueType').grid(row=4, column=3, sticky=W)
                WaterCueTypeVar = StringVar(MainWindowRightFrame)
                tWaterCueType = OptionMenu(MainWindowRightFrame, WaterCueTypeVar, "Normal", "Blink").grid(row=5, column=3)

                mLitPattern = ttk.Label(MainWindowRightFrame, text='LitPattern').grid(row=4, column=4, sticky=W)
                LitPatternVar = StringVar(MainWindowRightFrame)
                tLitPattern = OptionMenu(MainWindowRightFrame, LitPatternVar, "Random", "All").grid(row=5, column=4)

                mPunishWithLight = ttk.Label(MainWindowRightFrame, text='PunishWithLight').grid(row=4, column=5, sticky=W)
                PunishWithLightVar = StringVar(MainWindowRightFrame)
                tPunishWithLight = OptionMenu(MainWindowRightFrame, PunishWithLightVar, "ON", "OFF").grid(row=5, column=5)

                mAwsOn = ttk.Label(MainWindowRightFrame, text='AWS').grid(row=4, column=6, sticky=W)
                AwsOnVar = StringVar(MainWindowRightFrame)
                tAwsOn = OptionMenu(MainWindowRightFrame, AwsOnVar, "ON", "OFF").grid(row=5, column=6)

                #InitPanel() #
                Phase0_Init = 1

        if LoadTrg == 1:  # If load trigger is on

            Str = "ParametersForTask" + str(Task)
            if os.path.exists(Str+'/MaxCorrectNum.dat') == True:  # If save file exists
                with open(Str+'/MaxCorrectNum.dat', 'rb') as PickleInst[Task]:
                    MaxCorrectNumVar.set(pickle.load(PickleInst[Task]))  # Load
            else:
                MaxCorrectNumVar.set(80)     # Default value

            if os.path.exists(Str+'/MaxTrialNum.dat') == True:  # If save file exists
                with open(Str+'/MaxTrialNum.dat', 'rb') as PickleInst[Task]:
                    MaxTrialNumVar.set(pickle.load(PickleInst[Task]))  # Load
            else:
                MaxTrialNumVar.set(110)     # Default value

            if os.path.exists(Str+'/TimeLimit.dat') == True:  # If save file exists
                with open(Str+'/TimeLimit.dat', 'rb') as PickleInst[Task]:
                    TimeLimitVar.set(pickle.load(PickleInst[Task]))  # Load
            else:
                TimeLimitVar.set(180)     # Default value

            if os.path.exists(Str+'/PunishDur.dat') == True:  # If save file exists
                with open(Str+'/PunishDur.dat', 'rb') as PickleInst[Task]:
                    PunishDurVar.set(pickle.load(PickleInst[Task]))  # Load
            else:
                PunishDurVar.set(15)     # Default value

            if os.path.exists(Str+'/Iti.dat') == True:  # If save file exists
                with open(Str+'/Iti.dat', 'rb') as PickleInst[Task]:
                    ItiVar.set(pickle.load(PickleInst[Task]))  # Load
            else:
                ItiVar.set(1)     # Default value
            if os.path.exists(Str+'/LickDur.dat') == True:  # If save file exists
                with open(Str+'/LickDur.dat', 'rb') as PickleInst[Task]:
                    LickDurVar.set(pickle.load(PickleInst[Task]))  # Load
            else:
                LickDurVar.set(2)     # Default value

            if os.path.exists(Str+'/NextTaskTh.dat') == True:  # If save file exists
                with open(Str+'/NextTaskTh.dat', 'rb') as PickleInst[Task]:
                    NextTaskThVar.set(pickle.load(PickleInst[Task]))  # Load
            else:
                NextTaskThVar.set(100)     # Default value
            if os.path.exists(Str+'/NextTask.dat') == True:  # If save file exists
                with open(Str+'/NextTask.dat', 'rb') as PickleInst[Task]:
                    NextTaskVar.set(pickle.load(PickleInst[Task]))  # Load
            else:
                NextTaskVar.set(33)     # Default value

            if os.path.exists(Str+'/CorrectPos.dat') == True:  # If save file exists
                with open(Str+'/CorrectPos.dat', 'rb') as PickleInst[Task]:
                    CorrectPosVar.set(pickle.load(PickleInst[Task]))  # Load
            else:
                CorrectPosVar.set(1)     # Default value

            if os.path.exists(Str+'/RewardRateOfCorrectPos.dat') == True:  # If save file exists
                with open(Str+'/RewardRateOfCorrectPos.dat', 'rb') as PickleInst[Task]:
                    RewardRateOfCorrectPosVar.set(pickle.load(PickleInst[Task]))  # Load
            else:
                RewardRateOfCorrectPosVar.set(80)     # Default value

            if os.path.exists(Str+'/RewardRateOfWrongPos.dat') == True:  # If save file exists
                with open(Str+'/RewardRateOfWrongPos.dat', 'rb') as PickleInst[Task]:
                    RewardRateOfWrongPosVar.set(pickle.load(PickleInst[Task]))  # Load
            else:
                RewardRateOfWrongPosVar.set(20)     # Default value

            if os.path.exists(Str+'/Seed.dat') == True:  # If save file exists
                with open(Str+'/Seed.dat', 'rb') as PickleInst[Task]:
                    SeedVar.set(pickle.load(PickleInst[Task]))  # Load
            else:
                SeedVar.set(1)     # Default value

            if os.path.exists(Str+'/PanelType.dat') == True:  # If save file exists
                with open(Str+'/PanelType.dat', 'rb') as PickleInst[Task]:
                    PanelTypeVar.set(pickle.load(PickleInst[Task]))  # Load
            else:
                PanelTypeVar.set('Normal')     # Default value

            if os.path.exists(Str+'/WaterCueType.dat') == True:  # If save file exists
                with open(Str+'/WaterCueType.dat', 'rb') as PickleInst[Task]:
                    WaterCueTypeVar.set(pickle.load(PickleInst[Task]))  # Load
            else:
                WaterCueTypeVar.set('Blink')     # Default value

            if os.path.exists(Str+'/LitPattern.dat') == True:  # If save file exists
                with open(Str+'/LitPattern.dat', 'rb') as PickleInst[Task]:
                    LitPatternVar.set(pickle.load(PickleInst[Task]))  # Load
            else:
                LitPatternVar.set('All')     # Default value
            if os.path.exists(Str+'/PunishWithLight.dat') == True:  # If save file exists
                with open(Str+'/PunishWithLight.dat', 'rb') as PickleInst[Task]:
                    PunishWithLightVar.set(pickle.load(PickleInst[Task]))  # Load
            else:
                PunishWithLightVar.set('ON')     # Default value
            if os.path.exists(Str+'/AwsOn.dat') == True:  # If save file exists
                with open(Str+'/AwsOn.dat', 'rb') as PickleInst[Task]:
                    AwsOnVar.set(pickle.load(PickleInst[Task]))  # Load
            else:
                AwsOnVar.set('ON')     # Default value
            LoadTrg = 0

        if SaveTrg == 1:    # If save trigger is on
            # Parameters of each task are saved into different folder
            Str="ParametersForTask"+str(Task)   # Path to the folder for saving of parameters
            if os.path.exists(Str) == False:    # If folder for saving parameters is not exist
                os.mkdir(Str)   # Make folder for saving
            with open(Str+'/MaxCorrectNum.dat', 'wb') as PickleInst[Task]:
                pickle.dump(MaxCorrectNumVar.get(),PickleInst[Task])     # Save
            with open(Str+'/MaxTrialNum.dat', 'wb') as PickleInst[Task]:
                pickle.dump(MaxTrialNumVar.get(),PickleInst[Task])     # Save
            with open(Str + '/TimeLimit.dat', 'wb') as PickleInst[Task]:
                pickle.dump(TimeLimitVar.get(), PickleInst[Task])  # Save
            with open(Str+'/PunishDur.dat', 'wb') as PickleInst[Task]:
                pickle.dump(PunishDurVar.get(), PickleInst[Task])     # Save
            with open(Str+'/Iti.dat', 'wb') as PickleInst[Task]:
                pickle.dump(ItiVar.get(), PickleInst[Task])     # Save
            with open(Str+'/LickDur.dat', 'wb') as PickleInst[Task]:
                pickle.dump(LickDurVar.get(), PickleInst[Task])     # Save
            with open(Str + '/NextTask.dat', 'wb') as PickleInst[Task]:
                pickle.dump(NextTaskVar.get(), PickleInst[Task])  # Save
            with open(Str+'/NextTaskTh.dat', 'wb') as PickleInst[Task]:
                pickle.dump(NextTaskThVar.get(), PickleInst[Task])     # Save
            with open(Str+'/CorrectPos.dat', 'wb') as PickleInst[Task]:
                pickle.dump(CorrectPosVar.get(), PickleInst[Task])     # Save
            with open(Str+'/RewardRateOfCorrectPos.dat', 'wb') as PickleInst[Task]:
                pickle.dump(RewardRateOfCorrectPosVar.get(), PickleInst[Task])     # Save
            with open(Str+'/RewardRateOfWrongPos.dat', 'wb') as PickleInst[Task]:
                pickle.dump(RewardRateOfWrongPosVar.get(), PickleInst[Task])     # Save
            with open(Str+'/Seed.dat', 'wb') as PickleInst[Task]:
                pickle.dump(SeedVar.get(), PickleInst[Task])     # Save
            with open(Str+'/PanelType.dat', 'wb') as PickleInst[Task]:
                pickle.dump(PanelTypeVar.get(), PickleInst[Task])     # Save
            with open(Str+'/WaterCueType.dat', 'wb') as PickleInst[Task]:
                pickle.dump(WaterCueTypeVar.get(), PickleInst[Task])     # Save
            with open(Str+'/LitPattern.dat', 'wb') as PickleInst[Task]:
                pickle.dump(LitPatternVar.get(), PickleInst[Task])     # Save
            with open(Str+'/PunishWithLight.dat', 'wb') as PickleInst[Task]:
                pickle.dump(PunishWithLightVar.get(), PickleInst[Task])     # Save
            with open(Str+'/AwsOn.dat', 'wb') as PickleInst[Task]:
                pickle.dump(AwsOnVar.get(), PickleInst[Task])     # Save
            SaveTrg = 0

        if Phase == 1:  # Wait for starting of task
            if Phase1_Init == 0:
                PutPreTaskButton()
                mStatusVar = StringVar(MainWindowRoot)
                mStatus = ttk.Label(MainWindowRightFrame, textvariable=mStatusVar)
                mStatus.place(x=10, y=0)
                mOngoingResultVar = StringVar(MainWindowRoot)
                Phase1_Init = 1
            mStatusVar.set('Spatial discrimination task (' + str(Task) + ')    Waiting...')
            if IsStartTime() == 1:
                StartNow()
        if Phase == 2:  # During task
            if Phase2_Init == 0: # Initialization of the task
                PutEndTaskNowButton()

                mStatusVar.set('Spatial discrimination task (' + str(Task) + ')    Start time ' + str(TaskStartedMonth) + '/' + str(TaskStartedDay) + ' ' + str(TaskStartedHour) + ':' + str(TaskStartedMinute) + '    Running')
                mOngoingResult = ttk.Label(MainWindowRightFrame, textvariable=mOngoingResultVar)
                mOngoingResult.place(x=10, y=18)

                # Convert StringVars of parameters into integer or normal string to use in the following
                MaxCorrectNum=int(MaxCorrectNumVar.get())
                MaxTrialNum = int(MaxTrialNumVar.get())
                TimeLimit = int(TimeLimitVar.get())
                PunishDur = int(PunishDurVar.get())
                Iti = int(ItiVar.get())
                LickDur = int(LickDurVar.get())
                NextTask = int(NextTaskVar.get())
                NextTaskTh = int(NextTaskThVar.get())
                CorrectPos = CorrectPosVar.get()
                RewardRateOfCorrectPos =  int(RewardRateOfCorrectPosVar.get())
                RewardRateOfWrongPos = int(RewardRateOfWrongPosVar.get())
                Seed = int(SeedVar.get())
                PanelType = PanelTypeVar.get()
                WaterCueType =WaterCueTypeVar.get()
                LitPattern = LitPatternVar.get()
                PunishWithLight = PunishWithLightVar.get()
                AwsOn = AwsOnVar.get()

                StartLickRecording()
                RoofLightTurnOff()
                InfraredTurnOn()
                WaterCueTurnOn()
                WaterPosInside()
                if PanelType=='Normal':
                    CreateNormalPanel(0)
                    CreateNormalPanel(1)
                if PanelType=='Blink':
                    CreateBlinkPanel(0)
                    CreateBlinkPanel(1)
                if PanelType=='Textured':
                    CreateTexturedPanel(0)
                    CreateTexturedPanel(1)
                if WaterCueType == 'Blink':
                    MakeWaterCueBlink() # Make water cue blink

                # Declar local variables for this task
                TotalTouchNum = 0
                RewardNum = 0
                PunishNum = 0
                CorrectNum = 0
                RewardedCorrectNum = 0
                PunishedCorrectNum = 0
                WrongNum = 0
                RewardedWrongNum = 0
                PunishedWrongNum = 0
                CorrectRate = 0
                OnGoingResultUpdate = 0
                Rewarded = 0
                CorrectPanelRewardList = [0] * MaxTrialNum  # Keep which correct touch is rewarded or not
                WrongPanelRewardList = [0] * MaxTrialNum  # Keep which wrong touch is rewarded or not
                TotalRewardNumInCorrectList = int(MaxTrialNum * RewardRateOfCorrectPos /100)   # Rewarding schedule when mouse touches correct panel
                TotalRewardNumInWrongList = int(MaxTrialNum * RewardRateOfWrongPos / 100)   # Rewarding schedule when mouse touches wrong panel
                CurrRewardID_Correct = 0
                CurrRewardID_Wrong = 0

                # Make reward list when mouse touches correct panel
                random.seed(Seed)
                RewardFloatInterval = 1.0/float(RewardRateOfCorrectPos)*100.0
                print("Reward interval: "+str(RewardFloatInterval))
                CurrentTrialFloatNum = 0.0
                FailedNum = 0
                for i in range(TotalRewardNumInCorrectList):
                    for i2 in range(5):
                        r=int(CurrentTrialFloatNum + (random.random()*RewardFloatInterval))
                        if CorrectPanelRewardList[r]==0:
                            CorrectPanelRewardList[r] = 1
                            break
                        if i2 == 4:
                            FailedNum+=1
                    CurrentTrialFloatNum += RewardFloatInterval
                print("FailedNum:"+str(FailedNum))
                for i in range(FailedNum):
                    while True:
                        r = int(random.random()*MaxTrialNum)
                        if CorrectPanelRewardList[r]==0:
                            CorrectPanelRewardList[r] = 1
                            break
                for i in range(MaxTrialNum):
                    print("Correct:"+str(CorrectPanelRewardList[i]))


                # Make reward list when mouse touches wrong panel
                random.seed(Seed)
                RewardFloatInterval = 1.0 / float(RewardRateOfWrongPos) * 100.0
                print("Reward interval: "+str(RewardFloatInterval))
                CurrentTrialFloatNum = 0.0
                FailedNum = 0
                for i in range(TotalRewardNumInWrongList):
                    for i2 in range(5):
                        r = int(CurrentTrialFloatNum + (random.random() * RewardFloatInterval))
                        if WrongPanelRewardList[r] == 0:
                            WrongPanelRewardList[r] = 1
                            break
                        if i2 == 4:
                            FailedNum+=1
                    CurrentTrialFloatNum += RewardFloatInterval
                print("FailedNum:" + str(FailedNum))
                for i in range(FailedNum):
                    while True:
                        r = int(random.random()*MaxTrialNum)
                        if WrongPanelRewardList[r]==0:
                            WrongPanelRewardList[r] = 1
                            break
                for i in range(MaxTrialNum):
                    print("Wrong:"+str(WrongPanelRewardList[i]))

                DuringTask = 1
                DoneCorrectResponse = 1
                NowDrinking = 0
                AWS_Latency=20
                StartRecording()    # Start camera capturing and sending of TTL

                TrialNum=0
                TtlStart()
                Timer_Start(5)  # Task time limit timer start
                Phase2 = 2
                Phase2_Init = 1

                Writer_TouchEventTxt = open(Path + "/" + str(TimeNow.year) + "_" + str(TimeNow.month) + "_" + str(TimeNow.day) + " " + str(TimeNow.hour) + "h" + str(TimeNow.minute) + "m Task" + str(Task) + " Touch.txt",'w')  # Initialize the text exporter
                Writer_TouchEventCsv = open(Path + "/" + str(TimeNow.year) + "_" + str(TimeNow.month) + "_" + str(TimeNow.day) + " " + str(TimeNow.hour) + "h" + str(TimeNow.minute) + "m Task" + str(Task) + " Touch.csv",'w')  # Initialize the text exporter
                Writer_TouchEventTxt.write('TrialNum\tResult\t\t\tyyyy/mm/dd\th:m\ts\n')  # Write item name
                print("Task #" + str(Task) + " is started at " + str(GetTaskStartedMonth()) + '/' + str(GetTaskStartedDay()) + ' ' + str(GetTaskStartedHour()) + ':' + str(GetTaskStartedMinute()) + ':' + str(GetTaskStartedSecond()))

            if Phase2 == 0:   # Initiation of new trial

                DoneCorrectResponse=0
                TrialNum += 1
                if LitPattern=='All':
                    ShowPanel(0)
                    ShowPanel(1)
                if LitPattern=='Random':
                    Rnd=random.random()*2
                    if Rnd < 1:
                        ShowPanel(0)
                    if Rnd >= 1:
                        ShowPanel(1)

                Timer_Start(0)  # Start the latency timer
                Phase2 += 1
            if Phase2 == 1:   # Panel presentation
                TouchedPanelID = DetectPanelTouch() # Examine which panel is touched (return panel ID. If none of the panels touched, return -1)
                if TouchedPanelID != -1:

                    if TouchedPanelID == int(CorrectPos):  # If mouse touchs correct panel
                        CorrectResponse = 1
                        Rewarded = CorrectPanelRewardList[CurrRewardID_Correct]
                    if TouchedPanelID != int(CorrectPos):  # If mouse touchs incorrect panel
                        CorrectResponse = 0
                        Rewarded = WrongPanelRewardList[CurrRewardID_Wrong]

                    if Rewarded == 1: # If mouse touchs correct panel
                        DoneCorrectResponse = 1
                        WaterPosInside()  # Move water nozzle to the inside position
                        NowDrinking = 0
                        TotalTouchNum += 1
                        RewardNum += 1
                        if CorrectResponse == 1:
                            CorrectNum += 1 # Increase the number of correct respon
                            RewardedCorrectNum += 1
                            Writer_TouchEventTxt.write(str(TrialNum) + '\tPanelTouched(RewardedCorrect)\t' +str(TouchedPanelID)+'\t'+ str(TimeNow.year) + "/" + str(TimeNow.month) + "/" + str(TimeNow.day) + "\t" + str(TimeNow.hour) + ":" + str(TimeNow.minute) + "\t" + str(TimeNow.second) + "." + str(TimeNow.microsecond//1000) + "\n")  # Write the response on the text file
                            Writer_TouchEventCsv.write(str(TrialNum) + ',1,' +str(TouchedPanelID)+','+ str(TimeNow.year) + "," + str(TimeNow.month) + "," + str(TimeNow.day) + "," + str(TimeNow.hour) + "," + str(TimeNow.minute) + "," + str(TimeNow.second) + "." + str(TimeNow.microsecond//1000) + "\n")  # Write the response on the csv file
                            CurrRewardID_Correct += 1
                        if CorrectResponse == 0:
                            WrongNum += 1  # Increase the number of wrong respon
                            RewardedWrongNum += 1
                            Writer_TouchEventTxt.write(str(TrialNum) + '\tPanelTouched(RewardedWrong)\t' +str(TouchedPanelID)+'\t'+ str(TimeNow.year) + "/" + str(TimeNow.month) + "/" + str(TimeNow.day) + "\t" + str(TimeNow.hour) + ":" + str(TimeNow.minute) + "\t" + str(TimeNow.second) + "." + str(TimeNow.microsecond//1000) + "\n")  # Write the response on the text file
                            Writer_TouchEventCsv.write(str(TrialNum) + ',2,' +str(TouchedPanelID)+','+ str(TimeNow.year) + "," + str(TimeNow.month) + "," + str(TimeNow.day) + "," + str(TimeNow.hour) + "," + str(TimeNow.minute) + "," + str(TimeNow.second) + "." + str(TimeNow.microsecond//1000) + "\n")  # Write the response on the csv file
                            CurrRewardID_Wrong += 1
                        OnGoingResultUpdate=1
                        HidePanel(0)
                        HidePanel(1)
                        Timer_End(0)
                        WaterCueTurnOn()
                        Phase2 = 2  # Start reward phase
                    if Rewarded == 0: # If mouse touchs wrong panel
                        WaterPosOutside()
                        if PunishWithLight == 'ON':
                            RoofLightTurnOn()  # Turn on roof light
                        TotalTouchNum += 1
                        PunishNum += 1
                        if CorrectResponse == 1:
                            CorrectNum += 1  # Increase the number of correct respon
                            PunishedCorrectNum += 1
                            Writer_TouchEventTxt.write(str(TrialNum) + '\tPanelTouched(PunishedCorrect)\t' +str(TouchedPanelID)+'\t'+ str(TimeNow.year) + "/" + str(TimeNow.month) + "/" + str(TimeNow.day) + "\t" + str(TimeNow.hour) + ":" + str(TimeNow.minute) + "\t" + str(TimeNow.second) + "." + str(TimeNow.microsecond//1000) + "\n")  # Write the response on the text file
                            Writer_TouchEventCsv.write(str(TrialNum) + ',3,' +str(TouchedPanelID)+','+ str(TimeNow.year) + "," + str(TimeNow.month) + "," + str(TimeNow.day) + "," + str(TimeNow.hour) + "," + str(TimeNow.minute) + "," + str(TimeNow.second) + "." + str(TimeNow.microsecond//1000) + "\n")  # Write the response on the csv file
                            CurrRewardID_Correct += 1
                        if CorrectResponse == 0:
                            WrongNum += 1    # Increase the number of wrong respon
                            PunishedWrongNum += 1
                            Writer_TouchEventTxt.write(str(TrialNum) + '\tPanelTouched(PunishedWrong)\t' +str(TouchedPanelID)+'\t'+ str(TimeNow.year) + "/" + str(TimeNow.month) + "/" + str(TimeNow.day) + "\t" + str(TimeNow.hour) + ":" + str(TimeNow.minute) + "\t" + str(TimeNow.second) + "." + str(TimeNow.microsecond//1000) + "\n")  # Write the response on the text file
                            Writer_TouchEventCsv.write(str(TrialNum) + ',4,' +str(TouchedPanelID)+','+ str(TimeNow.year) + "," + str(TimeNow.month) + "," + str(TimeNow.day) + "," + str(TimeNow.hour) + "," + str(TimeNow.minute) + "," + str(TimeNow.second) + "." + str(TimeNow.microsecond//1000) + "\n")  # Write the response on the csv file
                            CurrRewardID_Wrong += 1
                        OnGoingResultUpdate = 1
                        HidePanel(0)
                        HidePanel(1)
                        Timer_End(0)  # End timer1
                        Timer_Start(0)  # Start punish timer
                        Phase2 = 5  # Start punishment phase
                    if OnGoingResultUpdate == 1:
                        mOngoingResultVar.set('CorrectNum:' + str(CorrectNum) +' (Rewarded: '+str(RewardedCorrectNum)+ ', Punished: '+str(PunishedCorrectNum)+')  WrongNum:' + str(WrongNum)  +' (Rewarded: '+str(RewardedWrongNum)+ ', Punished: '+str(PunishedWrongNum) + ')  TotalNum:' + str(TotalTouchNum) + '  Correct:' + str(round(CorrectNum * 100.0 / TotalTouchNum, 2)) + '%')
                if GetTimerSec(5) >= TimeLimit * 60:   # If time limit is exceeded
                    Timer_End(5)
                    Phase2 = 6
            if Phase2 == 2:  # Reward phase
                if NosePoking == 1 and NowDrinking == 0:    # If the mouse initiates nose poke
                    NowDrinking = 1
                    Timer_Start(0)  # Start lick timer
                if NowDrinking == 1:
                    if DoneCorrectResponse == 1 and GetTimerSec(0) >= LickDur:   # If lick time exceed the designated time
                        Timer_End(0) # End lick timer
                        WaterPosMiddle()    # Move water nozzle to the intermediate position
                        WaterCueTurnOff()
                        NowDrinking = 0
                        Timer_Start(0)  # Start ITI timer
                        Phase2 = 3

            if Phase2 == 3:   # ITI
                if GetTimerSec(0) >= Iti:  # If ITI is passed
                    Timer_End(0)
                    Phase2 = 0  # Go to the next trial
                if RewardNum >= MaxCorrectNum or TotalTouchNum >= MaxTrialNum: # If mouse achieved criteria of finishing the task
                    Timer_End(5)
                    WaterPosMiddle()
                    WaterCueTurnOff()
                    Timer_Start(0)  # Timer for interval between task and arbitary water supply is started
                    Phase2 = 6  # Go to the AWS
            if Phase2 == 5:   # Punishment phase
                if GetTimerSec(0) >= PunishDur:    # If punishment time is passed
                    RoofLightTurnOff()
                    WaterPosMiddle()    # Move water nozzle to the intermediate position
                    Timer_End(0)  # End punishment timer1
                    Timer_Start(0)  # Start ITI timer
                    Phase2 = 3
            if Phase2==6:
                HidePanel(0)
                HidePanel(1)
                if RewardNum < MaxCorrectNum and AwsOn=='ON':  # If mouse didn't achieved the max correct response
                    Timer_Start(0)
                    Phase2 = 7
                if RewardNum == MaxCorrectNum or AwsOn=='OFF':  # If mouse achieved the max correct response
                    Phase2 = -1
            if Phase2==7:   # Wait until arbitary water suuply is started
                if GetTimerSec(0) >= 20:   # If the interval is past 60
                    Timer_End(0)
                    ArbitaryWaterSupplyDur=(MaxCorrectNum - RewardNum) * LickDur * 1000    # Caliculate duration of complement water supply
                    StartArbitaryWaterSupply(ArbitaryWaterSupplyDur) # Start complement water supply
                    print("AWSstart")
                    Phase2=8
            if Phase2==8:
                if GetArbitaryWaterSupplyStat()==1: # If complement water supply is finished
                    Phase2 = -1

            if Phase2 == -1 or Phase2 == -2:  # Task finish phase
                DuringTask = 0
                WaterPosMiddle()
                ClearPanel()
                MakeWaterCueNonBlink()
                InfraredTurnOff()
                if NowRecording == 1:
                    SetEndRecordingTimer(60)
                if CorrectNum > 0 or WrongNum > 0:
                    CorrectRate = int(CorrectNum * 100.0 / TotalTouchNum)
                    Writer_TouchEventTxt.write('TotalNum:'+str(TotalTouchNum)+'  Correct num:'+str(CorrectNum) +' (Rewarded: '+str(RewardedCorrectNum)+ ', Punished: '+str(PunishedCorrectNum)+')  WrongNum:' + str(WrongNum)  +' (Rewarded: '+str(RewardedWrongNum)+ ', Punished: '+str(PunishedWrongNum) +')  Correct rate'+str(CorrectRate)+'%'+"\n")	#結果テキストの一番最後に成績のまとめを記入
                Writer_TouchEventTxt.write('TaskStartTime: ' + str(GetTaskStartedMonth()) + '/' + str(GetTaskStartedDay()) + ' ' + str(GetTaskStartedHour()) + ':' + str(GetTaskStartedMinute()) + ':' + str(GetTaskStartedSecond()) + "\n")
                Writer_TouchEventTxt.write('TaskEndTime: ' + str(TimeNow.month) + '/' + str(TimeNow.day) + ' ' + str(TimeNow.hour) + ':' + str(TimeNow.minute) + ':' + str(TimeNow.second + (TimeNow.microsecond // 1000) / 1000) + "\n")
                Writer_TouchEventTxt.write('MaxCorrectNum: '+str(MaxCorrectNum)+"\n")
                Writer_TouchEventTxt.write('MaxTrialNum: ' + str(MaxTrialNum) + "\n")
                Writer_TouchEventTxt.write('TimeLimit: ' + str(TimeLimit) + "\n")
                Writer_TouchEventTxt.write('PunishDur: ' + str(PunishDur) + "\n")
                Writer_TouchEventTxt.write('Iti: ' + str(Iti) + "\n")
                Writer_TouchEventTxt.write('LickDur: ' + str(LickDur) + "\n")
                Writer_TouchEventTxt.write('NextTask: ' + str(NextTask) + "\n")
                Writer_TouchEventTxt.write('NextTaskTh: ' + str(NextTaskTh)+"\n")
                Writer_TouchEventTxt.write('CorrectPos: ' + str(CorrectPos) + "\n")
                Writer_TouchEventTxt.write('RewardRateOfCorrectPos: ' + str(RewardRateOfCorrectPos) + "\n")
                Writer_TouchEventTxt.write('RewardRateOfWrongPos: ' + str(RewardRateOfWrongPos) + "\n")
                Writer_TouchEventTxt.write('Seed: ' + str(Seed) + "\n")
                Writer_TouchEventTxt.write('PanelType: ' + str(PanelType) + "\n")
                Writer_TouchEventTxt.write('WaterCueType: ' + str(WaterCueType) + "\n")
                Writer_TouchEventTxt.write('LitPattern: ' + str(LitPattern) + "\n")
                Writer_TouchEventTxt.write('PunishWithLight: ' + str(PunishWithLight)+"\n")
                Writer_TouchEventTxt.write('RecordFPS: ' + str(RecordFPS) + "\n")
                Writer_TouchEventTxt.write('AWS: ' + AwsOn + "\n")
                Writer_TouchEventTxt.write('AWS_Latency: ' + str(AWS_Latency) + "\n")
                Writer_TouchEventTxt.close()
                Writer_TouchEventCsv.close()
                EndLickRecording()
                if CorrectRate >= NextTaskTh:
                    Task = NextTask
                #SendMail()
                SendMail(DeviceNameVar.get() + ' finished task '+str(Task)+'. Correct:' + str(CorrectNum) +'('+ str(RewardedCorrectNum)+'-'+str(PunishedCorrectNum)+') Wrong:' + str(WrongNum) +'('+str(RewardedWrongNum)+'-'+str(PunishedWrongNum)+') Correct:'+str(CorrectRate)+'% Dur:' + str(round(GetTimerSec(5) / 60,1)) + ' min', 'The task is finished.')
                TtlDelayStop()

                if IsHousingAnalysis == 1 and Phase2 == -1:  # If it is housing analysis
                    if CorrectRate >= NextTaskTh:  # If the score exceed the criteria to switch the next task
                        SwitchTask(NextTask)  # Onset task switch trigger
                        print("Task is switched to task#" + str(NextTask) + "  " + str(GetTaskStartedMonth()) + '/' + str(GetTaskStartedDay()) + ' ' + str(GetTaskStartedHour()) + ':' + str(GetTaskStartedMinute()) + ':' + str(GetTaskStartedSecond()))

                if IsHousingAnalysis == 0:
                    RoofLightTurnOn()
                Phase = 1  # Go back to the task-waiting phase
                Phase2 = 0
                Phase2_Init = 0
    return

def StartRecording():   # Start camera caputring tagg
    global NowRecording, NextShatterTime, SendingTtl, ElapsedTime, ElapsedTimePerFrame, TtlPreTime, TtlCurrTime, TtlPreQuotient, TtlCurrQuotient, TtlCurrRemainder, TtlSquareElapsedTime, TtlCnt, TtlIsFirst, TtlPower, TtlSquareOn, Writer_TtlLogCsv, VideoWriter, PlayBackFPS, MovieWidth, MovieHeight
    if NowRecording==0:
        NowRecording = 1
        #fourcc = cv2.VideoWriter_fourcc(*'MJPG')    #Define the codec and create VideoWriter object
        fourcc = cv2.VideoWriter_fourcc(*'XVID')  # Define the codec and create VideoWriter object
        MovieWidth = int(MovieWidthVar.get())
        MovieHeight = int(MovieHeightVar.get())
        VideoWriter = cv2.VideoWriter(Path + "/" + str(TimeNow.year) + "_" + str(TimeNow.month) + "_" + str(TimeNow.day) + " " + str(TimeNow.hour) + "h" + str(TimeNow.minute) + "m" + str(TimeNow.second) + "s Task" + str(Task) + ".avi",fourcc, PlayBackFPS, (MovieWidth,MovieHeight)) #Prepare to save movie
        SendingTtl = 1
        ElapsedTime = 0
        ElapsedTimePerFrame = 0
        TtlPreTime = TimeNow.day*24*60*60*1000 + TimeNow.hour*60*60*1000 + TimeNow.minute*60*1000 + TimeNow.second*1000 + (TimeNow.microsecond//1000)
        TtlCurrTime = TimeNow.day*24*60*60*1000 + TimeNow.hour*60*60*1000 + TimeNow.minute*60*1000 + TimeNow.second*1000 + (TimeNow.microsecond//1000)
        NextShatterTime=0
        TtlPreQuotient = 0
        TtlCurrQuotient = 0
        TtlCurrRemainder = 0
        TtlSquareElapsedTime = 0
        TtlCnt = 0
        TtlIsFirst = 1
        TtlPower = -1
        TtlSquareOn = 0
        Writer_TtlLogCsv = open(Path + "/" + str(TimeNow.year) + "_" + str(TimeNow.month) + "_" + str(TimeNow.day) + " " + str(TimeNow.hour) + "h" + str(TimeNow.minute) + "m Task" + str(Task) + " TTL.csv", 'w')  # Initialize the text exporter
        Writer_TtlLogCsv.write("No,Hour,Min,Sec\n")  # # Write the timing of TTL onset and offset
    return
def SetEndRecordingTimer(FrameNum): # Start a timer for stopping camera caputring
    global EndRecordTimerOn, EndRecordTimerCnt
    EndRecordTimerOn = 1
    EndRecordTimerCnt=FrameNum
    return
def EndRecording(): # Stop camera caputring
    global NowRecording, SendingTtl, Writer_TtlLogCsv,TtlPower, WinApiForCamera, VideoCapture, CameraID, TargetFPS, VideoWriter, mouseData
    if NowRecording==1:
        NowRecording = 0
        SendingTtl = 0
        TtlPower = -1
        VideoWriter.release()   #Close video save function
        VideoCapture.release()  #Close video capture function
        cv2.destroyAllWindows() #Close window for opencv (Shows captured video)
        Writer_TtlLogCsv.close()

        #Re-create new opencv window
        if WinApiForCamera == 0:
            VideoCapture = cv2.VideoCapture(CameraID, cv2.CAP_DSHOW)  # Make video capture  # VideoCapture = cv2.VideoCapture(1, cv2.CAP_DSHOW)       #Make video capture
        if WinApiForCamera == 1:
            VideoCapture = cv2.VideoCapture(CameraID, cv2.CAP_MSMF)  # Make video capture  # VideoCapture = cv2.VideoCapture(0)

        VideoCapture.set(cv2.CAP_PROP_FPS, TargetFPS)  # Set FPS of camera capturing
        # VideoCapture.set(cv2.CAP_PROP_POS_FRAMES, 0);  # Useless
        # VideoCapture.set(cv2.CAP_PROP_BUFFERSIZE, 3);  # Useless

        cv2.namedWindow("CameraWindow")  # Make video window
        cv2.moveWindow("CameraWindow", 350, 300)
        mouseData = mouseParam("CameraWindow")  # Instantiate class for get mouse cursor coordinates of camera window
    return

def Timer_Start(i): # Start general propose timer tag
    global NowTime, TimerRunning, TimerCounter, TimerSec, TimerPreTime
    TimerRunning[i] = 1
    TimerCounter[i] = 0
    TimerSec[i] = 0
    TimerPreTime[i] = TimeNow.microsecond // 100000
    return
def Timer_End(i):   # End general propose timer
    global TimerRunning
    TimerRunning[i] = 0
    return
def GetTimerSec(id):
    global TimerSec
    return TimerSec[id]
def GetTimerStat(id):   #
    global TimerRunning
    return TimerRunning[id]
def DetectPanelTouch(): # Return number of the touch panel on the monitor
    global TouchX, TouchY, PanelULX, PanelULY, PanelBRX, PanelBRY, Task, TouchDetectionOnCnt, MaxPanelNum
    TouchedPanelID = -1
    #print(TouchDetectionOnCnt)
    if TouchDetectionOnCnt > 0:
        for i in range(0, MaxPanelNum):
            if TouchX >= PanelULX[Task][i] and TouchY >= PanelULY[Task][i] and TouchX <= PanelBRX[Task][i] and TouchY <= PanelBRY[Task][i]:
                TouchedPanelID=i
                print("Panel "+str(i)+" is touched.")
                break
    TouchDetectionOnCnt=0
    return TouchedPanelID

def DetectHoleTouch(Num):   # Return number of the infrared sensor of the hole
    global DebugWithoutArduinoMode
    Value=1000
    TouchedHoleID = -1
    if Num==0:
        if DebugWithoutArduinoMode == 0:
            ser.flushInput()  # Clear input buffer from arduino
            Value=int(ser.readline().decode("utf-8").strip('\n').strip('\r'))  # Read the input value of the infrared sensor (Work when combined with "Serial conection with python 4")
        #print(Value)
        if Value < 500:
            TouchedHoleID=0
            #print("detect")
        else:
            TouchedHoleID=-1
    return TouchedHoleID
def TtlStart():
    return
def TtlDelayStop():
    return
def MeasureDistance():  # general-purpose
    global Distance, Position
    Distance = (Position[0][0] - Position[1][0]) * (Position[0][0] - Position[1][0]) + (Position[0][1] - Position[1][1]) * (Position[0][1] - Position[1][1])
    return
def ToggleManualNosePoke(): # Function of the manual nosepoke button
    global ManualNosePokeOn
    ManualNosePokeOn *= -1
    return
def ToggleManualRoofLightOn():    # Function of the LED test button
    global RoofLightPowerOn
    Trg=0
    if RoofLightPowerOn==0:
        RoofLightTurnOn()
        Trg=1
    if RoofLightPowerOn==1 and Trg==0:
        RoofLightTurnOff()
    return
def ToggleManualIR_LightOn():    # Function of the LED test button
    global InfraredPowerOn
    Trg=0
    if InfraredPowerOn==0:
        InfraredTurnOn()
        Trg=1
    if InfraredPowerOn==1 and Trg==0:
        InfraredTurnOff()
    return
def ToggleManualWaterCueOn():    # Function of the LED test button
    global WaterCueOn
    Trg=0
    if WaterCueOn==0:
        WaterCueTurnOn()
        Trg=1
    if WaterCueOn==1 and Trg==0:
        WaterCueTurnOff()
    return
def ToggleManualPanelOn():    # Show all panels in the task
    global ManualPanelOnTrg, Task, MaxPanelNum, TouchPanelRef_Test
    Trg=0
    if ManualPanelOnTrg==0:
        ManualPanelOnTrg=1
        for i in range(MaxPanelNum):
            if PanelULX[Task][i] != 0:  # If this panel is used in the current task
                TouchPanelRef_Test[i] = CanvasTouchWindow.create_rectangle(PanelULX[Task][i], PanelULY[Task][i], PanelBRX[Task][i], PanelBRY[Task][i], fill='white')  # Create panel
        Trg=1
    if ManualPanelOnTrg==1 and Trg==0:
        ManualPanelOnTrg = 0
        for i in range(MaxPanelNum):
            if TouchPanelRef_Test[i]:  # If this panel is used in the current task
                CanvasTouchWindow.delete(TouchPanelRef_Test[i])
    return

def ButtonAWS():    #
    global ButtonAWS_On
    WaterPosInside()
    WaterCueTurnOn()
    RoofLightTurnOff()
    ButtonAWS_Dur=0
    if ButtonAWS_DurVar.get()!="":
        ButtonAWS_Dur=int(ButtonAWS_DurVar.get())
        StartArbitaryWaterSupply(ButtonAWS_Dur*1000)
    ButtonAWS_On=1
    return
def ButtonAWS_Blink():
    global ButtonAWS_On
    WaterPosInside()
    WaterCueTurnOn()
    RoofLightTurnOff()
    MakeWaterCueBlink()
    ButtonAWS_Dur = 0
    if ButtonAWS_DurVar.get() != "":
        ButtonAWS_Dur = int(ButtonAWS_DurVar.get())
        StartArbitaryWaterSupply(int(ButtonAWS_DurVar.get()) * 1000)
    ButtonAWS_On = 1
    return
def motion(event):  # Get mouse coordinate in tkinter window
    global MxTk, MyTk, PreMxTk, PreMyTk
    PreMxTk = MxTk
    PreMyTk = MyTk
    MxTk = event.x
    MyTk = event.y
    #print(str(MxTk) + "," + str(MyTk))

def create_message(from_addr, to_addr, bcc_addrs, subject, body):   # For email
    msg = MIMEText(body)
    msg['Subject'] = subject
    msg['From'] = from_addr
    msg['To'] = to_addr
    msg['Bcc'] = bcc_addrs
    msg['Date'] = formatdate()
    return msg
def send(from_addr, to_addrs, msg):  # For email
    smtpobj = smtplib.SMTP('smtp.gmail.com', 587)
    smtpobj.ehlo()
    smtpobj.starttls()
    smtpobj.ehlo()
    smtpobj.login(FROM_ADDRESS, MY_PASSWORD)
    smtpobj.sendmail(from_addr, to_addrs, msg.as_string())
    smtpobj.close()
    return
def SendMail(SUBJECT, BODY):  # For email
    #global MailAddress
    if MailAddressVar.get() !='':
        #print("ma")
        to_addr = MailAddressVar.get()
        subject = SUBJECT
        body = BODY
        msg = create_message(FROM_ADDRESS, to_addr, BCC, subject, body)
        send(FROM_ADDRESS, to_addr, msg)
    return


# Summary of menu bar
# File-> SaveParameter
# Setting -> adjustPanelLoc, SetTaskSchedule,RecFPS,PlayFPS,encoder,SetEmail,resetPara, FreezeDetect, Blinder
# Manual -> startRecord, endRecord, ResetMicon, ResetCam
menubar = Menu(MainWindowRoot)
FileMenu = Menu(menubar, tearoff=0)
FileMenu.add_command(label="Save parameters", command=SaveTrgOn)
#FileMenu.add_command(label="Reset parameters", command=donothing)
#FileMenu.add_command(label="Exit", command=EndFlagOn)
menubar.add_cascade(label="File", menu=FileMenu)
SettingMenu = Menu(menubar, tearoff=0)
#SettingMenu.add_command(label="Adjust panel position", command=SetPanel)
#SettingMenu.add_command(label="Set task schedule", command=donothing)
#SettingMenu.add_command(label="Set video recording FPS", command=donothing)
#SettingMenu.add_command(label="Set video playback FPS", command=donothing)
#SettingMenu.add_command(label="Select encoder", command=donothing)
#SettingMenu.add_command(label="Set notification email", command=donothing)
#SettingMenu.add_command(label="Freeze detection mode", command=donothing)
#SettingMenu.add_command(label="Blinder mode", command=donothing)
menubar.add_cascade(label="Setting", menu=SettingMenu)
ManualMenue = Menu(menubar, tearoff=0)
#ManualMenue.add_command(label="Start record", command=donothing)
#ManualMenue.add_command(label="Stop record", command=donothing)
#ManualMenue.add_command(label="Reset microcomputer", command=donothing)
#ManualMenue.add_command(label="Reset camera", command=donothing)
menubar.add_cascade(label="Manual operation", menu=ManualMenue)
MainWindowRoot.config(menu=menubar)

# Make menu GUI
PathForSaving=StringVar(MainWindowRoot)
PathForSaving.set(Path)
mPathForSaving = ttk.Label(MainWindowLeftFrame, textvariable=PathForSaving)
mPathForSaving.place(x=270, y=0)
mName = ttk.Label(MainWindowLeftFrame, text="Animal name:")
mName.place(x=0, y=0)
StrFPS = StringVar(MainWindowRoot)
mFPS = ttk.Label(MainWindowLeftFrame, textvariable=StrFPS)
mFPS.place(x=0, y=165)
CurrStatusDispVar = StringVar(MainWindowRoot)
CurrStatusDispVar.set("")
mCurrStatusDisp = ttk.Label(MainWindowLeftFrame, textvariable=CurrStatusDispVar)
mCurrStatusDisp.place(x=0, y=180)
AWS_DispTimeVar = StringVar(MainWindowRoot)
mAWS_DispTime = ttk.Label(MainWindowLeftFrame, textvariable=AWS_DispTimeVar)
mAWS_DispTime.place(x=0, y=195)
AnimalName = StringVar(MainWindowRoot)
iAnimalName = ttk.Entry(MainWindowLeftFrame, textvariable=AnimalName)
iAnimalName.place(x=100, y=0)
bFolderPath = ttk.Button(MainWindowLeftFrame, text='Folder path', command=SelectPathForSaving)
bFolderPath.place(x=0, y=30)
bSaveTrgOn = ttk.Button(MainWindowLeftFrame, text='SavePara', command=SaveTrgOn)
bSaveTrgOn.place(x=0, y=55)
bSwitch = ttk.Button(MainWindowLeftFrame, text='Setting', command=Setting)
bSwitch.place(x=0, y=80)
bExit = ttk.Button(MainWindowLeftFrame, text='Exit', command=EndFlagOn)
bExit.place(x=0, y=105)
PutTaskButton()

# Make Label
mLightTh = ttk.Label(ControlWindowFrame, text='LightTh:')
mLightTh.grid(row=1, column=1, sticky=E)
mDarkTh = ttk.Label(ControlWindowFrame, text='DarkTh:')
mDarkTh.grid(row=2, column=1, sticky=E)
mNumTh = ttk.Label(ControlWindowFrame, text='NumTh:')
mNumTh.grid(row=3, column=1, sticky=E)
mInAngle = ttk.Label(ControlWindowFrame, text='InAngle:')
mInAngle.grid(row=4, column=1, sticky=E)
mMidAngle = ttk.Label(ControlWindowFrame, text='MidAngle:')
mMidAngle.grid(row=5, column=1, sticky=E)
mOutAngle = ttk.Label(ControlWindowFrame, text='OutAngle:')
mOutAngle.grid(row=6, column=1, sticky=E)

# Make symbol
sTouchCursor=CanvasTouchWindow.create_oval(0, 0, 10, 10, fill = 'orange')  # Draw touch cursor


# Make Input
LightThVar = StringVar(ControlWindowRoot)
iLightTh = ttk.Entry(ControlWindowFrame, textvariable=LightThVar, width=5)
iLightTh.grid(row=1, column=2, sticky=W)
DarkThVar = StringVar(ControlWindowRoot)
iDarkTh = ttk.Entry(ControlWindowFrame, textvariable=DarkThVar, width=5)
iDarkTh.grid(row=2, column=2, sticky=W)
NumThVar = StringVar(ControlWindowRoot)
iNumTh = ttk.Entry(ControlWindowFrame, textvariable=NumThVar, width=5)
iNumTh.grid(row=3, column=2, sticky=W)
InAngleVar = StringVar(ControlWindowRoot)
iInAngle = ttk.Entry(ControlWindowFrame, textvariable=InAngleVar, width=5)
iInAngle.grid(row=4, column=2, sticky=W)
MidAngleVar = StringVar(ControlWindowRoot)
iMidAngle = ttk.Entry(ControlWindowFrame, textvariable=MidAngleVar, width=5)
iMidAngle.grid(row=5, column=2, sticky=W)
OutAngleVar = StringVar(ControlWindowRoot)
iOutAngle = ttk.Entry(ControlWindowFrame, textvariable=OutAngleVar, width=5)
iOutAngle.grid(row=6, column=2, sticky=W)

# Make Button

bInAngle = ttk.Button(ControlWindowFrame, text='InAngle', command=WaterPosInside)
bInAngle.grid(row=9, column=1, sticky=W)
bMidAngle = ttk.Button(ControlWindowFrame, text='MidAngle', command=WaterPosMiddle)
bMidAngle.grid(row=10, column=1, sticky=W)
bOutAngle = ttk.Button(ControlWindowFrame, text='OutAngle', command=WaterPosOutside)
bOutAngle.grid(row=11, column=1, sticky=W)

#bLedBlink = ttk.Button(ControlWindowFrame, text='LED(blink)', command=Start)
#bLedBlink.grid(row=13, column=1, sticky=W)
bManualNosePoke = ttk.Button(ControlWindowFrame, text='ManualNosePoke', command=ToggleManualNosePoke)
bManualNosePoke.grid(row=14, column=1, sticky=W)

ButtonAWS_DurVar = StringVar(ControlWindowRoot)
iButtonAWS_Dur = ttk.Entry(ControlWindowFrame, textvariable=ButtonAWS_DurVar, width=5)
iButtonAWS_Dur.grid(row=15, column=2, sticky=W)

bAWS = ttk.Button(ControlWindowFrame, text='AWS(sec)', command=ButtonAWS)   #
bAWS.grid(row=15, column=1, sticky=W)

bAWS = ttk.Button(ControlWindowFrame, text='AWS(sec,Blink)', command=ButtonAWS_Blink)   #
bAWS.grid(row=16, column=1, sticky=W)

bRoofLight = ttk.Button(ControlWindowFrame, text='Roof light', command=ToggleManualRoofLightOn)
bRoofLight.grid(row=17, column=1, sticky=W)

bIR_Light = ttk.Button(ControlWindowFrame, text='IR light', command=ToggleManualIR_LightOn)
bIR_Light.grid(row=18, column=1, sticky=W)

bWaterCue = ttk.Button(ControlWindowFrame, text='Water cue', command=ToggleManualWaterCueOn)
bWaterCue.grid(row=19, column=1, sticky=W)

bShowPanel = ttk.Button(ControlWindowFrame, text='ShowPanel', command=ToggleManualPanelOn)
bShowPanel.grid(row=20, column=1, sticky=W)

if WinApiForCamera==0:
    VideoCapture = cv2.VideoCapture(CameraID, cv2.CAP_DSHOW)       #Make video capture
    #VideoCapture = cv2.VideoCapture(1, cv2.CAP_DSHOW)       #Make video capture
if WinApiForCamera==1:
    VideoCapture = cv2.VideoCapture(CameraID, cv2.CAP_MSMF)       #Make video capture
    #VideoCapture = cv2.VideoCapture(0)

VideoCapture.set(cv2.CAP_PROP_FPS, TargetFPS)    # Set FPS of camera capturing
#VideoCapture.set(cv2.CAP_PROP_POS_FRAMES, 0);  # Useless
#VideoCapture.set(cv2.CAP_PROP_BUFFERSIZE, 3);  # Useless

cv2.namedWindow("CameraWindow")                     #Make video window
cv2.moveWindow("CameraWindow", 350, 300)
mouseData = mouseParam("CameraWindow") # Instantiate class for get mouse cursor coordinates of camera window

def InitLickWriter():   # Inisiate txt export of lick log function
    global Writer_LickEventTxt, Writer_LickEventCsv, Path
    Writer_LickEventTxt = open(Path + "/" + str(TimeNow.year) + "_" + str(TimeNow.month) + "_" + str(TimeNow.day) + " " + str(TimeNow.hour) + "h" + str(TimeNow.minute) + "m Task" + str(Task) + " Lick.txt", 'w')  # Initialize the text exporter
    Writer_LickEventCsv = open(Path + "/" + str(TimeNow.year) + "_" + str(TimeNow.month) + "_" + str(TimeNow.day) + " " + str(TimeNow.hour) + "h" + str(TimeNow.minute) + "m Task" + str(Task) + " Lick.csv", 'w')  # Initialize the text exporter
    return
def EndLickWriter():   # End txt export of lick log function
    global Writer_LickEventTxt, Writer_LickEventCsv
    Writer_LickEventTxt.close()
    Writer_LickEventCsv.close()
    return

def OperantHouseUpdate():
    global FrameNum, OHCnt, TimeNow, FpsPreSec, FpsSec, NowRecording, RecordFPS, FrameNumPerSec,w,EndFlag, BreakFlag,frame,cv2,VideoWriter,Line, MainWindowRoot, ControlWindowRoot,TouchWindowRoot,ret, Img, frame,cv2,Phase, TimerRunning, TimerNowTime, TimerPreTime, TimerCounter, TimerSec, TouchSymbolCnt, NosePokeRoiULX, NosePokeRoiULY, NosePokeRoiBRX, NosePokeRoiBRY, NosePokeRoiWidth, NosePokeRoiHeight, NosePoking, TouchSymbolCnt, MxCam, MyCam, RoiMovePhase, GrabbedID, Position, Distance, CameraWindowWidth, CameraWindowHeight, NosePokeSamplingDensity, NowPunishing, NosePokeIntTh, LightThVar, RoofLightPowerOn, ManualNosePokeOn, NosePokeDetectionOn, NosePokeHitNum, NosePokeHitNumTh, StartLickRecordingTrg, NowLickRecording, EndLickRecordingTrg, PreNosePoking, NosePokeNum, EndRecordTimerOn, EndRecordTimerCnt, TtlCurrTime, Ttl1stSquareDuration, ElapsedTimePerFrame, ElapsedTime, TtlCurrQuotient, TtlCurrRemainder, TtlSquareElapsedTime, TtlPreQuotient, TtlCnt, TtlSquareOn, TtlSquareElapsedTime, TtlIsFirst, TtlOutputOn, TtlPreTime, TtlPower, SendingTtl, TtlTimeStumpBook, NextShatterTime, CaptureNum, FPS, Writer_LickEventTxt, SerialOutPhase, CurrentChannelID, IndicatedRoofLightPower, RoofLightPowerOn, IndicatedInfraredPower, InfraredPowerOn, IndicatedWaterCue, WaterCueOn, IndicatedValveTtlPower, ValveTtlPowerOn, IndicatedHoleCue, HoleCueOn, IndicatedHoleWaterCue, HoleWaterCueOn, MxDesk, MyDesk, TouchX, TouchY, PreTouchX, PreTouchY,sTouchCursor, ServoWorkTime, Angle, SerialOutType, ServoOutputBook, DigitalPinOutputBook,OutPhase, BlinkPanelNum,IsHiddenPanel,TypeOfPanel, IsWaterCueBlink, WaterCuePower, AWS_On, AWS_IndicatedDur, AWS_Dur, AWS_PreFrameMilliSec, AWS_CurrFrameMilliSec, AWS_Stat, TouchDetectionOnCnt, DebugWithoutArduinoMode, PointedPixelInt, IsThereEndTaskNowButton, DuringCameraReset, VideoCapture, mouseData, WinApiForCamera, TargetFPS, IsLightPhase, AutoTaskSwitchPhase, NextTaskID #tagg

    OHCnt+=1    # Counter
    #print('Phase: '+str(Phase)+'  Phase2: '+str(Phase2)+'  Task: '+str(Task)+' @'+str(CrossFireMoveDistance))
    # Declaration of local variables
    RoiR=255
    RoiG = 0
    RoiB = 0
    Red=0
    Green=0
    Blue=0
    Int=0
    SamplingPosX = 0
    SamplingPosY = 0
    #Angle=90
    TouchXAdjust = 0
    TouchYAdjust = 0
    TtlPowerOn = 0

    # Caliculate FPS
    FrameNum += 1
    TimeNow = datetime.datetime.now()
    FpsPreSec = FpsSec
    FpsSec = TimeNow.second
    if FpsSec != FpsPreSec:
        FPS=FrameNumPerSec
        StrFPS.set("FPS "+str(FPS))
        FrameNumPerSec=0
    else:
        FrameNumPerSec+=1
    #Update current status display
    if RoofLightPowerOn==1:
        RoofLightDisp='ON '
    if RoofLightPowerOn==0:
        RoofLightDisp='OFF'
    if InfraredPowerOn==1:
        IR_Disp='ON '
    if InfraredPowerOn==0:
        IR_Disp='OFF'
    if WaterCuePower==1:
        WaterCueDisp='ON '
    if WaterCuePower==0:
        WaterCueDisp='OFF'
    if NowRecording == 1:
        NowRecordingDisp='ON '
    if NowRecording == 0:
        NowRecordingDisp='OFF'
    PointedPixelIntDisp=int(PointedPixelInt)

    CurrStatusDispVar.set(str(TimeNow.month)+'/'+str(TimeNow.day)+' '+str(TimeNow.hour)+':'+str(TimeNow.minute)+':'+str(TimeNow.second)+'  RoofLight:'+RoofLightDisp+'  IR:'+IR_Disp+'  WaterCue:'+WaterCueDisp+'  ServoAngle:'+str(Angle)+'  Rec:'+NowRecordingDisp+'  Cam('+str(MxCam)+', '+str(MyCam)+')  Touch('+str(TouchX)+', '+str(TouchY)+')  LightInt:'+str(int(PointedPixelIntDisp))+'  Phase:'+str(Phase)+'  Phase2:'+str(Phase2)+' @'+str(1))   #

    TouchWindowRoot.geometry('+' + str(ULXofTouchWindow) + '+' + str(ULYofTouchWindow))  # Move window

    PreTouchX = TouchX
    PreTouchY = TouchY
    if MouseDebugModeVar.get() == 'OFF':
        MxDesk, MyDesk = win32api.GetCursorPos()    # Get mice coordinates
        if TouchX_ShiftVar.get()!="":
            TouchX_Shift=int(TouchX_ShiftVar.get())
        if TouchY_ShiftVar.get()!="":
            TouchY_Shift=int(TouchY_ShiftVar.get())

        if TouchX_ScaleVar.get()!="":
            TouchX_Scale=float(TouchX_ScaleVar.get())
        if TouchY_ScaleVar.get()!="":
            TouchY_Scale=float(TouchY_ScaleVar.get())
        if IsTouchMonitorInvertedVar.get()=="Inverted":
            TouchX = int((795-MyDesk)*15.6/TouchX_Scale+TouchX_Shift)  # Airbar is compatible with 15.6 inches, while monitor is 10 inches
            TouchY = int((MxDesk - 2260)*15.6/TouchY_Scale-TouchY_Shift)
        if IsTouchMonitorInvertedVar.get() == "Normal":
            TouchX = int(((-605 - MyDesk) * 15.6 / TouchX_Scale + TouchX_Shift) * -1)  # Airbar is compatible with 15.6 inches, while monitor is 10 inches
            TouchY = int(((MxDesk - 2162) * 15.6 / TouchY_Scale - TouchY_Shift) * -1)  #
    if MouseDebugModeVar.get() == 'ON':
        TouchX = MxTk
        TouchY = MyTk
    if TouchX != PreTouchX or TouchY != PreTouchY:
        TouchDetectionOnCnt = 2
        TouchSymbolCnt = 30
    CanvasTouchWindow.coords(sTouchCursor, TouchX-5,TouchY-5,TouchX+5,TouchY+5) # Move touch cursor
    #print(str(TouchX)+","+str(TouchY))

    # Update each windows
    MainWindowRoot.update()
    ControlWindowRoot.update()
    TouchWindowRoot.update()

    # Change illumination based on light cycle
    if IsHousingAnalysis==1 and DuringTask==0:
        LightOnsetTime = LightPhaseOnsetHour * 60+LightPhaseOnsetMinute # Substitute light phase onset time as minute
        DarkOnsetTime = DarkPhaseOnsetHour * 60 + DarkPhaseOnsetMinute # Substitute dark phase onset time as minute
        CurrTime= TimeNow.hour*60+TimeNow.minute    # Substitute current time as minute
        Trg=0
        if LightOnsetTime < DarkOnsetTime:
            if CurrTime>=LightOnsetTime and CurrTime<=DarkOnsetTime :   # If the order of phases are "DarkPhase -> LightPhase -> DarkPhase"
                if RoofLightPowerOn==0:
                    RoofLightTurnOn()
                if InfraredPowerOn==1:
                    InfraredTurnOff()
                Trg=1
            if Trg==0:
                if RoofLightPowerOn == 1:
                    RoofLightTurnOff()
                if InfraredPowerOn==0:
                    InfraredTurnOn()
        Trg = 0
        if LightOnsetTime > DarkOnsetTime:
            if CurrTime>=LightOnsetTime or CurrTime<=DarkOnsetTime :   # If the order of phases are "LightPhase -> DarkPhase -> LightPhase"
                if RoofLightPowerOn == 0:
                    RoofLightTurnOn()
                if InfraredPowerOn==1:
                    InfraredTurnOff()
                Trg=1
            if Trg==0:
                if RoofLightPowerOn == 1:
                    RoofLightTurnOff()
                if InfraredPowerOn==0:
                    InfraredTurnOn()
    '''
    if NowRecording==0:
        if DuringCameraReset==0:    # Turn off USB camera (Camera reset function) tagg
            if CamResetDay!=TimeNow.day:
                if CamResetHour==TimeNow.hour and CamResetMinute==TimeNow.minute:
                    VideoCapture.release()
                    cv2.destroyAllWindows()
                    CamResetDay = TimeNow.day
                    DuringCameraReset=1
                    Timer_Start(7)
    if DuringCameraReset==1 and TimerSec[7]>=5: # Turn on USB camera (Camera reset function)
        Timer_End(7)
        cv2.namedWindow("CameraWindow")  # Make video window
        cv2.moveWindow("CameraWindow", 350, 300)
        mouseData = mouseParam("CameraWindow")  # Instantiate class for get mouse cursor coordinates of camera window

        if WinApiForCamera == 0:
            VideoCapture = cv2.VideoCapture(0, cv2.CAP_DSHOW)  # Make video capture  # VideoCapture = cv2.VideoCapture(1, cv2.CAP_DSHOW)       #Make video capture
        if WinApiForCamera == 1:
            VideoCapture = cv2.VideoCapture(0, cv2.CAP_MSMF)  # Make video capture  # VideoCapture = cv2.VideoCapture(0)

        VideoCapture.set(cv2.CAP_PROP_FPS, TargetFPS)  # Set FPS of camera capturing
        ret, Img = VideoCapture.read()  # Capture video frame
        DuringCameraReset = 0
        print("Camera reset "+str(TimeNow.hour)+":"+str(TimeNow.minute))
    '''

    Trg=0
    if AutoTaskSwitchPhase==1:  # If task switch is booked
        BackToPara()
        AutoTaskSwitchPhase = 2
        Trg = 1
    if AutoTaskSwitchPhase==2 and  Trg==0:
        Back()
        AutoTaskSwitchPhase = 3
        Trg = 1
    if AutoTaskSwitchPhase == 3 and  Trg==0:
        if Phase==0:    # When it comes to task selection
            if NextTaskID==2:
                AutoTaskSwitchPhase = 4
                Task2() # Start next task
            if NextTaskID == 4:
                AutoTaskSwitchPhase = 4
                Task4() # Start next task
            if NextTaskID==17:
                AutoTaskSwitchPhase = 4
                Task17() # Start next task
            if NextTaskID==22:
                AutoTaskSwitchPhase = 4
                Task22() # Start next task
            if NextTaskID==23:
                AutoTaskSwitchPhase = 4
                Task23() # Start next task
    if AutoTaskSwitchPhase==4 and Trg==0:
        AutoTaskSwitchPhase = 5
        #print("AutoTaskSwitchPhase is 3")
        Trg=1
    if AutoTaskSwitchPhase==5 and Trg==0:
        Start()
        AutoTaskSwitchPhase = 6
        #print("phase is 1")
        Trg=1


    Captured =0
    if DuringCameraReset==0:
        if CameraCaptureFreqVar.get()!='':
            if OHCnt%int(CameraCaptureFreqVar.get())==0:
                ret, Img = VideoCapture.read()  # Capture camera image
                Captured=1
                #print(VideoCapture.get(cv2.CAP_PROP_FPS))
                #print(VideoCapture.grab())
                #if VideoCapture.grab():
                #    ret, Img = VideoCapture.retrieve()
                #print(VideoCapture.get(7))
            else:
                time.sleep(1. / TargetFPS)  # Wait for keeping target frame rate
    if StartLickRecordingTrg==1:    # If recording of lick onset and offset is activated
        StartLickRecordingTrg = 0
        if NowLickRecording == 0:
            InitLickWriter()        # Init text export object of lick
            NowLickRecording = 1
    if EndLickRecordingTrg == 1:
        EndLickRecordingTrg = 0
        if NowLickRecording == 1:
            EndLickWriter()
            NowLickRecording = 0
    # Process of the movement of the nosepoke ROI
    cv2.waitKey(2)
    MxCam = mouseData.getX()    # Get mouse cursor coordinate
    MyCam = mouseData.getY()
    #print(str(MxCam)+","+str(MyCam))
    if RoiMovePhase == 3 and mouseData.getEvent() == 0: # If left click is released again
        RoiMovePhase = 0    # Get back the ROI phase
        GrabbedID = 0
    for i in range(2):  # Measure distances between mouse cursor and each tab of nose poke ROI
        if RoiMovePhase == 0 and mouseData.getEvent() == 1:
            Position[0][0]=MxCam
            Position[0][1]=MyCam
            if i==0:
                Position[1][0] = NosePokeRoiULX # Substitute upper left tab of the ROI
                Position[1][1] = NosePokeRoiULY
            if i==1:
                Position[1][0] = NosePokeRoiBRX # Substitute bottom right tab of the ROI
                Position[1][1] = NosePokeRoiBRY
            MeasureDistance()   # Measure distance
            if Distance < 128:   # If mouse cursor and tab are close enough
                GrabbedID = i+1 # Keep which tab is selected, 1: upper left  2: botton right
                RoiMovePhase = 1
    if RoiMovePhase==1 or RoiMovePhase==2:  # Move ROI tab according to the mouse cursor
        if GrabbedID==1:    # If upper left tab is selected
            NosePokeRoiULX = MxCam
            NosePokeRoiULY = MyCam
            if NosePokeRoiULX < 5:  # Limit the positions of the ROI tab not to stick out from the window
                NosePokeRoiULX = 5
            if NosePokeRoiULY < 5:
                NosePokeRoiULY = 5
            if NosePokeRoiULX > CameraWindowWidth - 10:
                NosePokeRoiULX = CameraWindowWidth - 10
            if NosePokeRoiULY > CameraWindowHeight - 10:
                NosePokeRoiULY = CameraWindowHeight - 10
            if NosePokeRoiULX > NosePokeRoiBRX: # Limit the positions of the ROI tab not to flip
                NosePokeRoiULX = NosePokeRoiBRX-5
            if NosePokeRoiULY > NosePokeRoiBRY:
                NosePokeRoiULY = NosePokeRoiBRY-5
            with open('data/NosePokeRoiULX.dat', 'wb') as fp:   # Save position of the tabs every frame
                pickle.dump(NosePokeRoiULX, fp)  # Save
            with open('data/NosePokeRoiULY.dat', 'wb') as fp:
                pickle.dump(NosePokeRoiULY, fp)  # Save
        if GrabbedID==2:    # If bottom right tab is selected
            NosePokeRoiBRX = MxCam
            NosePokeRoiBRY = MyCam
            if NosePokeRoiBRX < 10:
                NosePokeRoiBRX = 10
            if NosePokeRoiBRY < 10:
                NosePokeRoiBRY = 10
            if NosePokeRoiBRX > CameraWindowWidth - 5:
                NosePokeRoiBRX = CameraWindowWidth - 5
            if NosePokeRoiBRY > CameraWindowHeight - 5:
                NosePokeRoiBRY = CameraWindowHeight - 5
            if NosePokeRoiBRX < NosePokeRoiULX:
                NosePokeRoiBRX = NosePokeRoiULX+5
            if NosePokeRoiBRY < NosePokeRoiULY:
                NosePokeRoiBRY = NosePokeRoiULY+5
            with open('data/NosePokeRoiBRX.dat', 'wb') as fp:
                pickle.dump(NosePokeRoiBRX, fp)  # Save
            with open('data/NosePokeRoiBRY.dat', 'wb') as fp:
                pickle.dump(NosePokeRoiBRY, fp)  # Save
        if mouseData.getEvent() == 0:   # If left click is released
            RoiMovePhase = 2

        if RoiMovePhase == 2 and mouseData.getEvent() == 1: # If left click again
            RoiMovePhase = 3
    NosePokeRoiWidth = NosePokeRoiBRX - NosePokeRoiULX
    NosePokeRoiHeight = NosePokeRoiBRY - NosePokeRoiULY
    if RoiMovePhase == 0:   # If ROI is not moving
        RoiB = 255  # Change ROI color to blue
        RoiG = 0
        RoiR = 0
    if RoiMovePhase >= 1:   # If ROI is moving
        RoiB = 255  # Change ROI color to light blue
        RoiG = 100
        RoiR = 100
    cv2.line(Img, (NosePokeRoiULX, NosePokeRoiULY), (NosePokeRoiBRX, NosePokeRoiULY), (RoiB, RoiG, RoiR), 1)   # Draw nosepoke ROI line
    cv2.line(Img, (NosePokeRoiULX,NosePokeRoiBRY), (NosePokeRoiULX, NosePokeRoiULY), (RoiB, RoiG, RoiR), 1)   # Draw nosepoke ROI line
    cv2.line(Img, (NosePokeRoiBRX,NosePokeRoiBRY), (NosePokeRoiULX,NosePokeRoiBRY), (RoiB, RoiG, RoiR), 1)   # Draw nosepoke ROI line
    cv2.line(Img, (NosePokeRoiBRX,NosePokeRoiULY), (NosePokeRoiBRX,NosePokeRoiBRY), (RoiB, RoiG, RoiR), 1)   # Draw nosepoke ROI line
    cv2.rectangle(Img, (NosePokeRoiULX-3,NosePokeRoiULY-3), (NosePokeRoiULX+3,NosePokeRoiULY+3), (RoiB, RoiG, RoiR), -1)  # Draw nosepoke ROI tab
    cv2.rectangle(Img, (NosePokeRoiBRX-3,NosePokeRoiBRY-3), (NosePokeRoiBRX+3,NosePokeRoiBRY+3), (RoiB, RoiG, RoiR), -1)  # Draw nosepoke ROI tab
    if NosePoking==1:
        cv2.rectangle(Img, (NosePokeRoiULX, NosePokeRoiBRY+20), (NosePokeRoiULX+40, NosePokeRoiBRY+60), (0, 0, 255), -1)  # Draw dot

    if TouchSymbolCnt > 0:  # Process of touch symbol
        TouchSymbolCnt-=1
        cv2.rectangle(Img, (5,5), (80,80), (255, 255, 255), -1)  # Draw panel touching symbol
    if NosePokeDetectionOn==0:
        if TimerSec[6] > 1:
            Timer_End(6)
            NosePokeDetectionOn=1
    # Measuring the light intensity of the pointed pixel
    if MxCam!=None:
        Blue = Img[MyCam, MxCam, 0]
        Green = Img[MyCam, MxCam, 1]
        Red = Img[MyCam, MxCam, 2]
    PointedPixelInt=(int(Blue)+int(Green)+int(Red))/3

    # Detect nosepoke to the touch window

    NosePoking = 0
    NosePokeSamplingNumX = round(NosePokeRoiWidth / NosePokeSamplingDensity)
    NosePokeSamplingNumY = round(NosePokeRoiHeight / NosePokeSamplingDensity)
    if NosePokeSamplingNumX > 0 and NosePokeSamplingNumY > 0 and Captured==1:
        NosePokeHitNum = 0
        for i in range(NosePokeSamplingNumY - 1):
            Y=i+1
            X=0
            for i2 in range(NosePokeSamplingNumX - 1):
                X = i2 + 1
                SamplingPosX = NosePokeRoiULX+(X*NosePokeSamplingDensity)
                SamplingPosY = NosePokeRoiULY+(Y*NosePokeSamplingDensity)
                Blue = Img[SamplingPosY, SamplingPosX, 0]
                Green = Img[SamplingPosY, SamplingPosX, 1]
                Red = Img[SamplingPosY, SamplingPosX, 2]
                Int = (int(Blue)+int(Green)+int(Red))/3
                CableIsDetected = 0 # 1 is substituted if cable color is detected
                if CableDetectCorrValueVar.get() != "" and CableDetectCorrValueVar.get() != ".":
                    if Blue < Green * float(CableDetectCorrValueVar.get()) and Blue < Red * float(CableDetectCorrValueVar.get()): # If detected color is yellow(Color of cable of miniscope)
                        CableIsDetected=1
                if NowPunishing == 0 and NosePokeDetectionOn == 1:
                    if RoofLightPowerOn==1:
                        if LightThVar.get()!="":    #
                            NosePokeIntTh=int(LightThVar.get())  # Set the threshold of light phase
                    if RoofLightPowerOn==0:
                        if DarkThVar.get() != "":
                            NosePokeIntTh = int(DarkThVar.get()) # Set the threshold of dark phase
                    if Int < NosePokeIntTh:    # If light intensity of sampled pixel exceed the threshold
                        if CableIsDetected==1:
                            cv2.rectangle(Img, (SamplingPosX - 1, SamplingPosY - 1), (SamplingPosX + 1, SamplingPosY + 1), (0, 255, 0), -1)  # Draw blue dot
                        if CableIsDetected==0:
                            NosePokeHitNum +=1  # Increase the positive sampled pixel number
                            cv2.rectangle(Img, (SamplingPosX-1, SamplingPosY-1), (SamplingPosX+1, SamplingPosY+1), (0, 0, 255), -1) # Draw red dot
                    if Int >= NosePokeIntTh:
                        cv2.rectangle(Img, (SamplingPosX-1, SamplingPosY-1), (SamplingPosX+1, SamplingPosY+1), (255, 0, 0), -1) # Draw blue dot
    NosePoking = 0
    if NosePokeDetectionOn == 1:    # If nosepoke detection is functional
        if NumThVar.get()!="":
            NosePokeHitNumTh = int(NumThVar.get())   # Get the threshold number of nosepoke detection
        if NosePokeHitNum >= NosePokeHitNumTh:  # If hit num exceed the threshold for the detection of the nosepoking
            NosePoking = 1
        if NowLickRecording==1:
            if PreNosePoking == 0 and NosePoking == 1:  # if this frame is the onset of nose poke
                Writer_LickEventTxt.write("NosePokeStart\t1\t" + str(TimeNow.year) + " / " + str(TimeNow.month) + " / " + str(TimeNow.day) + "\t" + str(TimeNow.hour) + ":" + str(TimeNow.minute) + "\t" + str(TimeNow.second) + "." + str(TimeNow.microsecond//1000) + "\n")    # Write the onset of the nose poke on the text file
                Writer_LickEventCsv.write("NosePokeStart,1," + str(TimeNow.year) + "," + str(TimeNow.month) + "," + str(TimeNow.day) + "," + str(TimeNow.hour) + "," + str(TimeNow.minute) + "," + str(TimeNow.second) + "." + str(TimeNow.microsecond//1000) + "\n")   # Write the onset of the nose poke on the csv file
                NosePokeNum += 1
    if NowLickRecording == 1:
        if PreNosePoking == 1 and NosePoking == 0:  # if this frame is end of the nose poke
            Writer_LickEventTxt.write('NosePokeEnd\t0\t' + str(TimeNow.year) + " / " + str(TimeNow.month) + " / " + str(TimeNow.day) + "\t" + str(TimeNow.hour) + ":" + str(TimeNow.minute) + "\t" + str(TimeNow.second) + "." + str(TimeNow.microsecond//1000)+"\n")   # Write the offset of the nose poke on the text file
            Writer_LickEventCsv.write('NosePokeEnd,0,' + str(TimeNow.year) + "," + str(TimeNow.month) + "," + str(TimeNow.day) + "," + str(TimeNow.hour) + "," + str(TimeNow.minute) + "," + str(TimeNow.second) + "." + str(TimeNow.microsecond//1000) + "\n")  # Write the offset of the nose poke on the csv file
    PreNosePoking = NosePoking  # Keep the value for the next frame

    if ManualNosePokeOn==1: # In nose poke is positive by pushing manual nosepoke button
        NosePoking=1


    cv2.imshow("CameraWindow", Img)  # Show captured video frame
    if NowRecording==1: #tagg
        if NextShatterTime <= ElapsedTime:

            if ret == True:
                SmallImg=cv2.resize(Img,(MovieWidth, MovieHeight))
                VideoWriter.write(SmallImg)  # Record captured video of the current frame
                ShatterWaitTime = 1000.0 / float(RecordFPS)
                NextShatterTime += ShatterWaitTime
                CaptureNum += 1

            else:
                EndFlag = 1

    # Process of Timers
    for i in range(8):  # There are 7 timers
        if TimerRunning[i]==1:
            TimerNowTime[i]=TimeNow.microsecond//100000
            if TimerNowTime[i] != TimerPreTime[i]:  # If it past 0.1 sec
                TimerCounter[i]+=1
                TimerSec[i]=TimerCounter[i]/10.0  # Caliculate time in sec
                TimerPreTime[i]=TimerNowTime[i]
    # Process of blinking panel
    if BlinkPanelNum > 0:
        if int(TimeNow.microsecond) // 100000 % 2 == 0: # When lit-off
            for i in range(0, MaxPanelNum):
                if TypeOfPanel[i] == 1:  # If this panel is assigned to blink
                    CanvasTouchWindow.itemconfigure(TouchPanelRef[i], state='hidden')  # Hide created panel
        if int(TimeNow.microsecond) // 100000 % 2 == 1: # When lit-on
            for i in range(0, MaxPanelNum):
                if TypeOfPanel[i] == 1:   # If this panel is assigned to blink
                    if IsHiddenPanel[i]==0:     # Hidden panel isn't turned on
                        CanvasTouchWindow.itemconfigure(TouchPanelRef[i], state='normal')  # Show created panel
    # Process of arbitary water supply (AWS)
    if AWS_On==1:   #
        AWS_PreFrameMilliSec=AWS_CurrFrameMilliSec
        AWS_CurrFrameMilliSec = (TimeNow.hour * 60 * 60 * 1000) + (TimeNow.minute * 60 * 1000) + (TimeNow.second * 1000) + (TimeNow.microsecond//1000)   # Get current time in millisec
        AWS_DispTimeVar.set('Arbitary water supply: '+str(AWS_Dur/1000)+' / '+str(round(AWS_IndicatedDur/1000, 2))+' sec')
        if NosePoking==1:
            AWS_Dur += AWS_CurrFrameMilliSec - AWS_PreFrameMilliSec # Caliculate how long does this frame take
        if AWS_IndicatedDur <= AWS_Dur: # When lick duration exceed the indicated duration
            WaterPosMiddle()
            WaterCueTurnOff()
            AWS_Stat=1  # Mean AWS is finished
            AWS_DispTimeVar.set('')
            AWS_On=0
    if EndRecordTimerOn==1: # If record end trigger is on
        EndRecordTimerCnt-=1    # Decrease the counter
        if EndRecordTimerCnt<=0:    # If it's time for stop recording
            EndRecording()  # Stop recording
            EndRecordTimerOn=0  # Change recording status variable

    if SendingTtl==1:   # If TTL sending is on
        TtlCurrTime = TimeNow.day*24*60*60*1000 + TimeNow.hour*60*60*1000 + TimeNow.minute*60*1000 + TimeNow.second*1000 + (TimeNow.microsecond//1000)
        ElapsedTimePerFrame = TtlCurrTime - TtlPreTime

        ElapsedTime += ElapsedTimePerFrame
        TtlCurrQuotient = ElapsedTime // TtlITV     # Quotient
        TtlCurrRemainder = ElapsedTime % TtlITV     # Remainder
        Trg = 0
        if TtlPreQuotient < TtlCurrQuotient:
            TtlSquareElapsedTime = TtlCurrRemainder #
            TtlPower=1 # Turn on TTL output
            TtlPreQuotient = TtlCurrQuotient
            Trg=1
            TtlCnt+=1
        if TtlSquareOn==1 and Trg==0:   #
            TtlSquareElapsedTime += ElapsedTimePerFrame #
            if (TtlIsFirst == 1 and TtlSquareElapsedTime >= Ttl1stSquareDuration) or (TtlIsFirst == 0 and TtlSquareElapsedTime >= TtlSquareDuration):   #
                TtlIsFirst= 0
                TtlPower=-1 # Turn off TTL output
        #print(TtlPreTime)
        #print(TtlCurrTime)
        #print(" ")
        TtlPreTime = TtlCurrTime

    # Reflect indicated variables to the operant device
    if TtlPower==1: # If TTL output is indicated to be turn on
        TtlSquareOn = 1   # Change TTL status variable
        DigitalPinOutputBook = 1
        TtlTimeStumpBook = 1
    if TtlPower==-1: # If TTL output is indicated to be turn off
        TtlSquareOn = 0   # Change TTL status variable
        DigitalPinOutputBook = 1
        TtlTimeStumpBook = 1
    if IndicatedRoofLightPower==1:  # If roof light is indicated to be turn on
        IndicatedRoofLightPower=0
        RoofLightPowerOn=1   # Change roof light status variable

    if IndicatedRoofLightPower==-1: # If roof light is indicated to be turn off
        IndicatedRoofLightPower=0
        RoofLightPowerOn=0  # Change roof light status variable

    if IndicatedInfraredPower==1:  # If infrared light is indicated to be turn on
        IndicatedInfraredPower=0
        InfraredPowerOn=1   # Change infrared status variable
    if IndicatedInfraredPower==-1:  # If infrared light is indicated to be turn off
        IndicatedInfraredPower=0
        InfraredPowerOn=0   # Change infrared status variable

    if IndicatedWaterCue==1:    # If water cue light is indicated to be turn on
        IndicatedWaterCue=0
        WaterCueOn=1   # Change water cue (located beneath the slit) status variable
        WaterCuePower=1
    if IndicatedWaterCue==-1:   # If water cue light is indicated to be turn off
        IndicatedWaterCue=0
        WaterCueOn=0    # Change water cue (located beneath the slit) status variable
        WaterCuePower = 0
    if IndicatedValveTtlPower==1:   # If water valve is indicated to be turn on
        IndicatedValveTtlPower=0
        ValveTtlPowerOn=1   # Change valve TTL status variable
    if IndicatedValveTtlPower==-1:   # If water valve is indicated to be turn off
        IndicatedValveTtlPower=0
        ValveTtlPowerOn=0   # Change valve TTL status variable

    for i in range(5):
        if IndicatedHoleCue[i]==1:   # If hole(panel) cue light is indicated to be turn on
            IndicatedHoleCue[i]=0
            HoleCueOn[i]=1  # Change hole cue status variable
        if IndicatedHoleCue[i]==-1:  # If hole(panel) cue light is indicated to be turn off
            IndicatedHoleCue[i]=0
            HoleCueOn[i]=0  # Change hole cue status variable

        if IndicatedHoleWaterCue[i]==1:  # If water cue light in each hole(panel) is indicated to be turn on
            IndicatedHoleWaterCue[i]=0
            HoleWaterCueOn[i]=1 # Change hole water cue status variable
        if IndicatedHoleWaterCue[i]==-1: # If water cue light in each hole(panel) is indicated to be turn off
            IndicatedHoleWaterCue[i]=0
            HoleWaterCueOn[i]=0 # Change hole water cue status variable

    if WaterCueOn == 1:
        if IsWaterCueBlink==1:
            if int(TimeNow.microsecond) // 100000 % 2 == 0: # Make water cue blink
                WaterCuePower=0
                DigitalPinOutputBook = 1
            if int(TimeNow.microsecond) // 100000 % 2 == 1: # Make water cue blink
                WaterCuePower=1
                DigitalPinOutputBook = 1

    if TimerSec[4] >=ServoWorkTime and TimerRunning[4]==1:    # If servo is not within operation time
        Timer_End(4)
        Angle = 127    # Means make servo is turned off (ValueRange=0-127(0-180 degree))
        ServoOutputBook=1

    if Phase==1 and IsThereEndTaskNowButton==1: #
        RemoveEndTaskNowButton()
        PutPreTaskButton()
        #print("aaaa")
    #print(Angle)
    # Serial connection with arduino (First send type of info (LED or servo). Second send value through character (LED: Status of 7 LEDs are compressed into one decimal num, Servo: Number represent angle (0-127)).)

    #if SerialOutPhase==0:   # Select channel
    #if SerialOutType == 0 and TimerSec[4] < ServoWorkTime:


    #print("digi" + str(DigitalPinOutputBook))
    #print("servo" + str(ServoOutputBook))
    if ServoOutputBook == 1 and OutPhase == 0:
        ServoOutputBook = 0
        OutPhase = 1
        SerialOutType = 2  # Switch to the output of LED info
        if DebugWithoutArduinoMode == 0:
            ser.write(bytes(chr(126), 'utf-8'))  # Send info of servo into arduino
        #print("serv")

    if DigitalPinOutputBook==1 and OutPhase == 0:
        DigitalPinOutputBook = 0
        OutPhase = 1
        SerialOutType = 1  # Switch to the output of servo angle info
        if DebugWithoutArduinoMode == 0:
            ser.write(bytes(chr(125), 'utf-8'))  # Send info of LED into arduino
        #print(DigitalPinOutputBook)

    #if SerialOutPhase==1:    # Send value to regulate switching of the channel
    #print("OutPhas"+str(OutPhase))
    if SerialOutType == 1 and OutPhase == 2:
        DecimalNum = 8*RoofLightPowerOn + 4*InfraredPowerOn + 2*WaterCuePower + TtlSquareOn #+8*TtlSquareOn+4*ValveTtlPowerOn+2*HoleCueOn[0]+1*HoleWaterCueOn[0]    #Compress LED info into decimal number
        TempBinary = bytes(chr(DecimalNum), 'utf-8')  # Transform the LED decimal into character and then transform into binary data
        if DebugWithoutArduinoMode==0:
            ser.write(TempBinary)  # Send information into arduino
        SerialOutType = 0
        #print("led")
        OutPhase = 0
        if EndFlag > 0:
            EndFlag+=1
            #print("e")
        #print(RoofLightPowerOn)
        #print(InfraredPowerOn)
        #print("roof" + str(RoofLightPowerOn))
        #print("inf" + str(InfraredPowerOn))
        #print("water"+str(WaterCueOn))
        #print("dec" + str(DecimalNum))
        #print(chr(32))  #Assigned only between 33(0)-126(127)
        #DecimalNum=128
        #print("here"+str(DecimalNum))
        if TtlTimeStumpBook == 1 and SendingTtl==1:
            TtlTimeStumpBook=0
            if TtlPower != 0:  # If there is any indication for the TTL of synchronization
                if TtlPower == 1 and TtlCnt > 0:  # When TTL for synchronization is indicated to on
                    Writer_TtlLogCsv.write(str(TtlCnt) + "," + str(TimeNow.hour) + "," + str(TimeNow.minute) + "," + str(TimeNow.second) + "." + str(TimeNow.microsecond // 1000) + "\n")  # # Write the timing of TTL onset and offset
                    #Writer_TtlLogCsv.write("a")
                    #print("a")
                if TtlPower == -1 and TtlCnt > 0:  # When TTL for synchronization is indicated to off
                    Writer_TtlLogCsv.write(str(TtlCnt) + "," + str(TimeNow.hour) + "," + str(TimeNow.minute) + "," + str(TimeNow.second) + "." + str(TimeNow.microsecond // 1000) + "\n")
                    #Writer_TtlLogCsv.write("b")
                    #print("b")
                TtlPower = 0  # Clear indication

    if SerialOutType == 2 and OutPhase == 2:
        TempBinary = bytes(chr(Angle), 'utf-8')  # Transform the servo angle decimal into character and then transform into binary data
        if DebugWithoutArduinoMode == 0:
            ser.write(TempBinary)  # Send information into arduino
        SerialOutType = 0
        OutPhase=0
        if EndFlag > 0:
            EndFlag+=1
            #print("e")
        #Angle="90"
        #print(chr(Angle)+chr(Angle))
    if OutPhase==1:
        OutPhase=2

    #SerialOutPhase=SerialOutPhase+1 # Progress phase
    #if SerialOutPhase >=2:
    #    SerialOutPhase = 0

    #For the monitoring of message from arduino
    #abc=ser.readline().decode("utf-8").strip('\n').strip('\r')  # Read the input value of the infrared sensor (Work when combined with "Serial conection with python 3")
    #print("back"+str(abc))

    #if OHCnt%7==7:
    #   ser.flushInput()    # Clear input buffer from arduino


    if TouchDetectionOnCnt > 0:
        TouchDetectionOnCnt -= 1

    return



MainWindowRoot.update()
ControlWindowRoot.update()
TouchWindowRoot.update()

if os.path.exists('data/Path.dat') == True: # Upper left X coordinate of touch panel on the window
   with open('data/Path.dat', 'rb') as fp:
       Path = pickle.load(fp)
else:
    Path = 'C:\\'   # Default path for saving
PathForSaving.set(Path)
# Load parameters of control window
if os.path.exists('data/LightTh.dat') == True: # Upper left X coordinate of touch panel on the window
   with open('data/LightTh.dat', 'rb') as fp:
       LightThVar.set(pickle.load(fp))  # Load
else:
    LightThVar.set('50')    # Default path for saving

if os.path.exists('data/DarkTh.dat') == True: # Upper left X coordinate of touch panel on the window
   with open('data/DarkTh.dat', 'rb') as fp:
       DarkThVar.set(pickle.load(fp))  # Load
else:
    DarkThVar.set('50')    # Default path for saving

if os.path.exists('data/NumTh.dat') == True:  # Upper left X coordinate of touch panel on the window
    with open('data/NumTh.dat', 'rb') as fp:
        NumThVar.set(pickle.load(fp))  # Load
else:
    NumThVar.set('3')  # Default path for saving

if os.path.exists('data/InAngle.dat') == True:  # Upper left X coordinate of touch panel on the window
    with open('data/InAngle.dat', 'rb') as fp:
        InAngleVar.set(pickle.load(fp))  # Load
else:
    InAngleVar.set('0')  # Default path for saving

if os.path.exists('data/MidAngle.dat') == True:  # Upper left X coordinate of touch panel on the window
    with open('data/MidAngle.dat', 'rb') as fp:
        MidAngleVar.set(pickle.load(fp))  # Load
else:
    MidAngleVar.set('90')  # Default path for saving

if os.path.exists('data/OutAngle.dat') == True:  # Upper left X coordinate of touch panel on the window
    with open('data/OutAngle.dat', 'rb') as fp:
        OutAngleVar.set(pickle.load(fp))  # Load
else:
    OutAngleVar.set('180')  # Default path for saving

if os.path.exists('data/TouchX_Shift.dat') == True:  # Upper left X coordinate of touch panel on the window
    with open('data/TouchX_Shift.dat', 'rb') as fp:
        TouchX_ShiftVar.set(pickle.load(fp))  # Load
else:
    TouchX_ShiftVar.set('0')  # Default path for saving

if os.path.exists('data/TouchY_Shift.dat') == True:  # Upper left X coordinate of touch panel on the window
    with open('data/TouchY_Shift.dat', 'rb') as fp:
        TouchY_ShiftVar.set(pickle.load(fp))  # Load
else:
    TouchY_ShiftVar.set('0')  # Default path for saving


if os.path.exists('data/TouchX_Scale.dat') == True:  # Upper left X coordinate of touch panel on the window
    with open('data/TouchX_Scale.dat', 'rb') as fp:
        TouchX_ScaleVar.set(pickle.load(fp))  # Load
else:
    TouchX_ScaleVar.set('10')  # Default path for saving

if os.path.exists('data/TouchY_Scale.dat') == True:  # Upper left X coordinate of touch panel on the window
    with open('data/TouchY_Scale.dat', 'rb') as fp:
        TouchY_ScaleVar.set(pickle.load(fp))  # Load
else:
    TouchY_ScaleVar.set('10')  # Default path for saving

if os.path.exists('data/IsTouchMonitorInverted.dat') == True:  # Upper left X coordinate of touch panel on the window
    with open('data/IsTouchMonitorInverted.dat', 'rb') as fp:
        IsTouchMonitorInvertedVar.set(pickle.load(fp))  # Load
else:
    IsTouchMonitorInvertedVar.set('Inverted')  # Default path for saving

if os.path.exists('data/ButtonAWS_DurVar.dat') == True:  # Upper left X coordinate of touch panel on the window
    with open('data/ButtonAWS_DurVar.dat', 'rb') as fp:
        ButtonAWS_DurVar.set(pickle.load(fp))  # Load
else:
    ButtonAWS_DurVar.set("0")  # Default path for saving

if os.path.exists('data/PanelUsed.dat') == True: # Whether each panel is used or not
   with open('data/PanelUsed.dat', 'rb') as fp:
       PanelUsed = pickle.load(fp)
else:
    PanelUsed =  [[0 for i in range(MaxPanelNum)] for j in range(MaxTaskNum)]

if os.path.exists('data/PanelULX.dat') == True: # Upper left X coordinate of touch panel on the window
   with open('data/PanelULX.dat', 'rb') as fp:
       PanelULX = pickle.load(fp)
else:
    PanelULX =  [[0 for i in range(MaxPanelNum)] for j in range(MaxTaskNum)]
if os.path.exists('data/PanelULY.dat') == True: # Upper left Y coordinate of touch panel on the window
    with open('data/PanelULY.dat', 'rb') as fp:
        PanelULY = pickle.load(fp)
else:
    PanelULY =  [[0 for i in range(MaxPanelNum)] for j in range(MaxTaskNum)]

if os.path.exists('data/PanelBRX.dat') == True: # Lower right X coordinate of touch panel on the window
    with open('data/PanelBRX.dat', 'rb') as fp:
        PanelBRX = pickle.load(fp)
else:
    PanelBRX = [[0 for i in range(MaxPanelNum)] for j in range(MaxTaskNum)]
if os.path.exists('data/PanelBRY.dat') == True: # Lower right Y coordinate of touch panel on the window
    with open('data/PanelBRY.dat', 'rb') as fp:
        PanelBRY = pickle.load(fp)
else:
    PanelBRY = [[0 for i in range(MaxPanelNum)] for j in range(MaxTaskNum)]

if os.path.exists('data/NosePokeRoiULX.dat') == True: # Upper left X coordinate of nose poke detection ROI
    with open('data/NosePokeRoiULX.dat', 'rb') as fp:
        NosePokeRoiULX = pickle.load(fp)
else:
    NosePokeRoiULX = 100

if os.path.exists('data/NosePokeRoiULY.dat') == True: # Upper left Y coordinate of nose poke detection ROI
    with open('data/NosePokeRoiULY.dat', 'rb') as fp:
        NosePokeRoiULY = pickle.load(fp)
else:
    NosePokeRoiULY = 100

if os.path.exists('data/NosePokeRoiBRX.dat') == True: # Bottom right X coordinate of nose poke detection ROI
    with open('data/NosePokeRoiBRX.dat', 'rb') as fp:
        NosePokeRoiBRX = pickle.load(fp)
else:
    NosePokeRoiBRX = 200

if os.path.exists('data/NosePokeRoiBRY.dat') == True: # Bottom right Y coordinate of nose poke detection ROI
    with open('data/NosePokeRoiBRY.dat', 'rb') as fp:
        NosePokeRoiBRY = pickle.load(fp)
else:
    NosePokeRoiBRY = 200

if os.path.exists('data/MailAddress.dat') == True: # Bottom right Y coordinate of nose poke detection ROI
    with open('data/MailAddress.dat', 'rb') as fp:
        MailAddressVar.set(pickle.load(fp))
else:
    MailAddressVar.set('')

if os.path.exists('data/DeviceName.dat') == True: # Bottom right Y coordinate of nose poke detection ROI
    with open('data/DeviceName.dat', 'rb') as fp:
        DeviceNameVar.set(pickle.load(fp))
else:
    DeviceNameVar.set('NO1')
if os.path.exists('data/ArduinoConnection.dat') == True: # Bottom right Y coordinate of nose poke detection ROI
    with open('data/ArduinoConnection.dat', 'rb') as fp:
        ArduinoConnectionVar.set(pickle.load(fp))
else:
    ArduinoConnectionVar.set('ON')
if os.path.exists('data/MouseDebugMode.dat') == True: # Bottom right Y coordinate of nose poke detection ROI
    with open('data/MouseDebugMode.dat', 'rb') as fp:
        MouseDebugModeVar.set(pickle.load(fp))
else:
    MouseDebugModeVar.set('OFF')
if os.path.exists('data/CameraCaptureFreq.dat') == True: # Bottom right Y coordinate of nose poke detection ROI
    with open('data/CameraCaptureFreq.dat', 'rb') as fp:
        CameraCaptureFreqVar.set(pickle.load(fp))
else:
    CameraCaptureFreqVar.set('1')

if os.path.exists('data/PanelTexturePath.dat') == True:  # Bottom right Y coordinate of nose poke detection ROI
    with open('data/PanelTexturePath.dat', 'rb') as fp:
        PanelTexturePath = pickle.load(fp)
else:
    PanelTexturePath = ['']*4

if os.path.exists('data/TaskStartTime1.dat') == True: # Bottom right Y coordinate of nose poke detection ROI
    with open('data/TaskStartTime1.dat', 'rb') as fp:
        TaskStartTime1Var.set(pickle.load(fp))
else:
    TaskStartTime1Var.set('0:00')
if os.path.exists('data/TaskStartTime2.dat') == True: # Bottom right Y coordinate of nose poke detection ROI
    with open('data/TaskStartTime2.dat', 'rb') as fp:
        TaskStartTime2Var.set(pickle.load(fp))
else:
    TaskStartTime2Var.set('')
if os.path.exists('data/TaskStartTime3.dat') == True: # Bottom right Y coordinate of nose poke detection ROI
    with open('data/TaskStartTime3.dat', 'rb') as fp:
        TaskStartTime3Var.set(pickle.load(fp))
else:
    TaskStartTime3Var.set('')
if os.path.exists('data/TaskStartTime4.dat') == True: # Bottom right Y coordinate of nose poke detection ROI
    with open('data/TaskStartTime4.dat', 'rb') as fp:
        TaskStartTime4Var.set(pickle.load(fp))
else:
    TaskStartTime4Var.set('')

if os.path.exists('data/LightPhaseOnsetTime.dat') == True: # Bottom right Y coordinate of nose poke detection ROI
    with open('data/LightPhaseOnsetTime.dat', 'rb') as fp:
        LightPhaseOnsetTimeVar.set(pickle.load(fp))
else:
    LightPhaseOnsetTimeVar.set('9:00')
if os.path.exists('data/DarkPhaseOnsetTime.dat') == True: # Bottom right Y coordinate of nose poke detection ROI
    with open('data/DarkPhaseOnsetTime.dat', 'rb') as fp:
        DarkPhaseOnsetTimeVar.set(pickle.load(fp))
else:
    DarkPhaseOnsetTimeVar.set('21:00')

if os.path.exists('data/MovieWidth.dat') == True: # Bottom right Y coordinate of nose poke detection ROI
    with open('data/MovieWidth.dat', 'rb') as fp:
        MovieWidthVar.set(pickle.load(fp))
else:
    MovieWidthVar.set('320')

if os.path.exists('data/MovieHeight.dat') == True: # Bottom right Y coordinate of nose poke detection ROI
    with open('data/MovieHeight.dat', 'rb') as fp:
        MovieHeightVar.set(pickle.load(fp))
else:
    MovieHeightVar.set('240')

if os.path.exists('data/CableDetectCorrValue.dat') == True: # Bottom right Y coordinate of nose poke detection ROI
    with open('data/CableDetectCorrValue.dat', 'rb') as fp:
        CableDetectCorrValueVar.set(pickle.load(fp))
else:
    CableDetectCorrValueVar.set('0')

SetLightCycleTime()
TouchWindowRoot.bind('<Motion>', motion)
ret, Img = VideoCapture.read()    #Capture video frame
cv2.imshow("CameraWindow", Img)  # Show captured video frame
#mouseData = mouseParam("CameraWindow") # Instantiate class for get mouse cursor coordinates of camera window
Timer_Start(4)  # Timer for servo power

while EndFlag<=4: # Main roop of non-task period 3
    #Phase = 0
    OperantHouseUpdate()

    if OHCnt==30:    # If it takes a while after running (Serial connection doesn't establish at the 1st frame)
        RoofLightTurnOn()
        InfraredTurnOn()
        WaterPosMiddle()  # Move water nozzle to the intermediate position
    if ButtonAWS_On==1: # If button activated AWS is turned on
        if AWS_Stat==1:
            WaterPosMiddle()
            WaterCueTurnOff()
            RoofLightTurnOn()
            IsWaterCueBlink = 0
            ButtonAWS_On=0
    if EndFlag==3:  # If LEDs are turned off and water nozzle move to neutral position, turn off the switch of servo
        Angle = 127  # Means make servo is turned off (ValueRange=0-127(0-180 degree))
        ServoOutputBook = 1

SaveGeneralParameter()
time.sleep(0.5) # Wait to make sure to torun of servo
if DebugWithoutArduinoMode==0:
    ser.close()


#VideoWriter.release()
if DuringCameraReset==0:
    VideoCapture.release()
cv2.destroyAllWindows()

